// MANITO 바탕화면 배치 — 처음 로그인할 때 KDE Plasma가 한 번 실행한다.
// (모양 꾸러미 org.manito.desktop 의 contents/layouts/org.kde.plasma.desktop-layout.js 로 설치됨)
//
//  위쪽 막대 : [MANITO 버튼(메신저 대화창, Meta+Space)] [지금 프로그램의 메뉴] ……… [시스템 트레이] [시계]
//  바탕화면  : 가운데에 살아 있는 오브 + 입력칸 (답변은 시스템 알림)
//  아래쪽 막대: 떠 있는 프로그램 막대 — [프로그램 목록] [자주 쓰는 프로그램…]

// ── 위쪽 막대 ──
var top = new Panel
top.location = "top"
top.height = 2 * Math.ceil(gridUnit * 1.7 / 2)
top.floating = false          // 화면 위 끝에 붙임 (KDE 새 막대 기본값은 떠 있음)

var manito = top.addWidget("org.manito.assistant")
manito.globalShortcut = "Meta+Space"
top.addWidget("org.kde.plasma.appmenu")
top.addWidget("org.kde.plasma.panelspacer")
top.addWidget("org.kde.plasma.systemtray")
var clock = top.addWidget("org.kde.plasma.digitalclock")
clock.currentConfigGroup = ["Appearance"]
clock.writeConfig("showDate", true)
clock.writeConfig("dateDisplayFormat", "BesideTime")
clock.writeConfig("dateFormat", "custom")
clock.writeConfig("customDateFormat", "M월 d일 (ddd)")

// ── 아래쪽 프로그램 막대 (가운데 정렬, 내용만큼 길이, 떠 있음) ──
var dock = new Panel
dock.location = "bottom"
dock.height = 2 * Math.ceil(gridUnit * 3.4 / 2)
dock.alignment = "center"
dock.lengthMode = "fit"
dock.floating = true

var apps = dock.addWidget("org.kde.plasma.kickoff")
apps.currentConfigGroup = ["General"]
apps.writeConfig("icon", "view-app-grid-symbolic")
var tasks = dock.addWidget("org.kde.plasma.icontasks")
tasks.currentConfigGroup = ["General"]
// 체험 모드(설치 프로그램이 있을 때)에만 맨 앞에 "MANITO 설치" — 설치된 PC에서는 설치 프로그램이 지워져 나타나지 않음
var installer = applicationExists("calamares") ? ["applications:manito-install.desktop"] : []
tasks.writeConfig("launchers", installer.concat([
    "applications:org.kde.dolphin.desktop",
    "applications:microsoft-edge.desktop",
    "applications:org.kde.konsole.desktop",
    "applications:org.kde.kate.desktop",
    "applications:org.kde.discover.desktop",
    "applications:systemsettings.desktop"
]).join(","))

// ── 바탕화면: 오브 + 입력칸 위젯을 화면 가운데에 ──
var desktopsArray = desktopsForActivity(currentActivity())
for (var j = 0; j < desktopsArray.length; j++) {
    var d = desktopsArray[j]
    d.wallpaperPlugin = "org.kde.image"
    var geo = screenGeometry(d.screen)
    var w = Math.round(gridUnit * 34), h = Math.round(gridUnit * 25)
    d.addWidget("org.manito.search",
                Math.round((geo.width - w) / 2),
                Math.round(geo.height * 0.56 - h * 0.75),
                w, h)
}
