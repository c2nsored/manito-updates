"""OpenAI 호환 AI 서버 클라이언트 (llama-server, Ollama, LM Studio, vLLM 공통).

특정 AI 엔진에 묶이지 않도록 이 표준 API만 사용한다.
"""
from __future__ import annotations

import json
import urllib.error
import urllib.request


class LLMError(Exception):
    pass


def _post(url: str, body: dict, timeout: float) -> dict:
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:500]
        raise LLMError(f"HTTP {e.code}: {detail}") from e
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise LLMError(f"AI 서버에 연결할 수 없습니다: {e}") from e
    except json.JSONDecodeError as e:
        raise LLMError("AI 서버 응답을 해석할 수 없습니다") from e


def chat(base_url: str, model: str, messages: list[dict], tools: list[dict] | None = None,
         timeout: float = 300.0, temperature: float = 0.3) -> dict:
    """assistant 메시지(dict)를 돌려준다. tool_calls가 들어있을 수 있다."""
    body: dict = {"model": model, "messages": messages, "temperature": temperature, "stream": False}
    if tools:
        body["tools"] = tools
    url = base_url.rstrip("/") + "/chat/completions"
    try:
        resp = _post(url, body, timeout)
    except LLMError as e:
        # 도구 호출을 지원하지 않는 서버/모델이면 도구 없이 한 번 더 시도
        if tools and str(e).startswith("HTTP 4"):
            body.pop("tools")
            resp = _post(url, body, timeout)
        else:
            raise
    try:
        return resp["choices"][0]["message"]
    except (KeyError, IndexError, TypeError) as e:
        raise LLMError(f"예상하지 못한 응답 형식: {str(resp)[:200]}") from e


def health(base_url: str, timeout: float = 2.0) -> bool:
    """서버가 요청을 받을 준비가 되었는지 확인."""
    root = base_url.rstrip("/")
    if root.endswith("/v1"):
        root = root[:-3]
    for path in ("/health", "/v1/models"):
        try:
            with urllib.request.urlopen(root + path, timeout=timeout) as r:
                if r.status == 200:
                    return True
        except Exception:
            continue
    return False
