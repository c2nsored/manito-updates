"""AI와 규칙 라우터가 사용하는 도구 모음.

각 도구는 MCP 도구 형식(이름·설명·입력 스키마)과 호환되는 정보 + 위험도를 가진다.
AI는 여기 등록된 도구만 호출할 수 있다 (임의 셸 명령 불가).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

RISK_LEVELS = ("read", "launch", "workspace", "trash", "write", "system")


@dataclass
class ToolResult:
    ok: bool
    text: str                       # 사용자에게 보여줄 한국어 요약
    data: Any = None                # 구조화된 결과 (UI·AI용)
    needs_choice: bool = False      # 후보가 여러 개라 사용자가 골라야 함


@dataclass
class Tool:
    name: str
    description: str
    parameters: dict
    risk: str
    func: Callable[..., ToolResult]

    def schema(self) -> dict:
        """OpenAI 호환 tool 정의 (MCP의 inputSchema와 같은 구조)."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }


@dataclass
class ToolContext:
    platform: Any
    config: dict
    catalog: Any = None
    models: Any = None
    memory: Any = None
    extra: dict = field(default_factory=dict)


class Registry:
    def __init__(self):
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        assert tool.risk in RISK_LEVELS, tool.risk
        self._tools[tool.name] = tool

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def all(self) -> list[Tool]:
        return list(self._tools.values())

    def schemas(self) -> list[dict]:
        return [t.schema() for t in self._tools.values()]


def default_registry() -> Registry:
    from . import apps, coding, files, system, trash, web

    reg = Registry()
    for mod in (apps, files, system, trash, web, coding):
        for t in mod.TOOLS:
            reg.register(t)
    return reg
