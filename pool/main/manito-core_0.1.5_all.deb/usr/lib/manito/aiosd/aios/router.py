"""규칙 기반 명령 판단 (한국어).

자주 쓰는 명령은 AI 모델 없이 즉시·정확하게 처리한다.
AI 모델이 완전히 꺼져 있어도 이 명령들은 동작한다.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass
class Intent:
    tool: str                      # 도구 이름 또는 내부 명령(_unload_models 등)
    args: dict = field(default_factory=dict)


# 호출어: "AI야", "컴퓨터야", "AI," — 뒤에 '야/아' 또는 쉼표가 있을 때만 (그냥 "컴퓨터 상태"는 호출어 아님)
_WAKE = re.compile(r"^\s*(?:(?:ai|에이아이|컴퓨터)\s*(?:야|아)\s*[,!.]?|ai\s*[,!])\s*", re.I)
_POLITE_TAIL = re.compile(r"\s*(?:좀\s*)?(?:해\s*줘|해\s*주세요|해\s*줄래|줘|주세요|해|할래|하자)?\s*[.!?~]*\s*$")

_LAUNCH_VERB = re.compile(r"(?:을|를)?\s*(?:좀\s*)?(실행|켜|열어|시작|띄워|틀어)(?!지)")
_STEAM_PREFIX = re.compile(r"^(?:스팀|steam)\s*(?:에서|으로|로)?\s+", re.I)

_FIND_VERB = re.compile(r"(찾아|검색|어디\s*있|어딨|보여)")
_FILE_WORDS = re.compile(r"(파일|문서|사진|그림|폴더|동영상|영상|음악)")
_EXTS = ("pdf", "txt", "md", "doc", "docx", "hwp", "hwpx", "xls", "xlsx", "csv", "ppt", "pptx",
         "jpg", "jpeg", "png", "gif", "webp", "svg", "mp4", "mkv", "avi", "mov", "mp3", "flac",
         "wav", "zip", "7z", "rar", "tar", "gz", "iso", "py", "js", "html", "json", "stl", "obj",
         "step", "exe", "deb", "appimage")
_EXT_RE = re.compile(r"(?<![a-z0-9])\.?(" + "|".join(_EXTS) + r")(?![a-z0-9])", re.I)
_QUOTED = re.compile(r"[\"'“‘「]([^\"'”’」]+)[\"'”’」]")
_NAMED = re.compile(r"(\S+)\s*(?:이?라는|이란)\s*(?:이름의?\s*)?(?:파일|문서)")

_STATUS_WORDS = re.compile(r"(시스템|컴퓨터|pc|cpu|씨피유|메모리|램|ram|vram|gpu|그래픽|자원|리소스)", re.I)
_STATUS_ASK = re.compile(r"(상태|사용량|얼마|확인|어때|점유)")

_UNLOAD = re.compile(r"(ai|모델|에이아이)\s*(?:을|를)?\s*(?:모두|전부|다)?\s*(꺼|종료|언로드|내려)", re.I)


def clean(text: str) -> str:
    t = _WAKE.sub("", text.strip())
    t = _POLITE_TAIL.sub("", t)
    return t.strip()


def route(text: str, folder_names: list[str] | None = None) -> Intent | None:
    t = clean(text)
    if not t:
        return None
    low = t.lower()

    # 1) AI 모델 끄기
    if _UNLOAD.search(low):
        return Intent("_unload_models")

    # 2) 시스템 상태
    if (_STATUS_WORDS.search(low) and _STATUS_ASK.search(low)) or low in ("상태", "시스템 상태"):
        return Intent("system_status")

    # 3) 파일 검색
    ext_m = _EXT_RE.search(t)
    if _FIND_VERB.search(t) and (_FILE_WORDS.search(t) or ext_m):
        args: dict = {}
        for name in sorted(folder_names or [], key=len, reverse=True):
            if name in t:
                args["folder"] = name
                break
        if ext_m:
            args["extension"] = ext_m.group(1).lower()
        q = _QUOTED.search(t) or _NAMED.search(t)
        if q:
            args["query"] = q.group(1)
        return Intent("search_files", args)

    # 4) 프로그램 / 게임 실행
    m = _LAUNCH_VERB.search(t)
    if m:
        target = t[: m.start()].strip()
        source = ""
        sm = _STEAM_PREFIX.match(target)
        if sm:
            source = "steam"
            target = target[sm.end():]
        target = re.sub(r"\s*(?:게임|프로그램|앱)$", "", target).strip()
        target = re.sub(r"(?:을|를)$", "", target).strip()
        if target:
            return Intent("launch_app", {"query": target, "source": source})
        if source:  # "스팀 실행해줘"
            return Intent("launch_app", {"query": "steam"})

    return None


_ORDINALS = {"첫": 1, "두": 2, "세": 3, "네": 4, "다섯": 5, "한": 1}


def parse_choice(text: str, n: int) -> int | None:
    """'2', '2번', '두 번째' 같은 답을 0부터 시작하는 번호로. 해당 없으면 None."""
    t = clean(text)
    m = re.fullmatch(r"(\d+)\s*(?:번|번째)?(?:\s*(?:거|것|으로|로))?", t)
    if m:
        i = int(m.group(1))
    else:
        m = re.fullmatch(r"(첫|두|세|네|다섯|한)\s*(?:번째|번)(?:\s*(?:거|것|으로|로))?", t)
        if not m:
            return None
        i = _ORDINALS[m.group(1)]
    return i - 1 if 1 <= i <= n else None
