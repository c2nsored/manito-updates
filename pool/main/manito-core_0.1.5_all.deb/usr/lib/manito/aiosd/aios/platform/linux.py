"""Linux (KDE Plasma 우선) 구현.

⚠️ 이 파일은 Windows에서 작성되어 실제 Linux에서는 아직 검증되지 않았다.
   (단위 테스트는 가짜 파일로 파싱 로직만 확인)
"""
from __future__ import annotations

import os
import shlex
import shutil
import subprocess
import time
from configparser import ConfigParser
from pathlib import Path

from .base import App, GpuInfo, Platform

_FIELD_CODES = {"%f", "%F", "%u", "%U", "%d", "%D", "%n", "%N", "%i", "%c", "%k", "%v", "%m"}


# 로그인한 화면 세션에서 받아 와야 하는 값 (프로그램 창을 띄울 화면·D-Bus 주소 등)
_SESSION_KEYS = ("WAYLAND_DISPLAY", "DISPLAY", "XAUTHORITY", "DBUS_SESSION_BUS_ADDRESS",
                 "XDG_CURRENT_DESKTOP", "XDG_SESSION_TYPE", "XDG_SESSION_DESKTOP",
                 "XDG_DATA_DIRS", "XDG_CONFIG_DIRS", "KDE_FULL_SESSION", "KDE_SESSION_VERSION",
                 "QT_QPA_PLATFORMTHEME", "LANG", "LANGUAGE", "XMODIFIERS", "QT_IM_MODULE",
                 "GTK_IM_MODULE", "SDL_IM_MODULE")


def parse_environment(text: str) -> dict[str, str]:
    """`systemctl --user show-environment` 출력(KEY=VALUE 줄)을 사전으로."""
    out: dict[str, str] = {}
    for line in text.splitlines():
        k, sep, v = line.partition("=")
        if sep and k.replace("_", "").isalnum():
            out[k] = v
    return out


def session_environment() -> dict[str, str]:
    """프로그램을 띄울 때 쓸 환경.

    MANITO의 aiosd는 로그인 전(부팅 직후)부터 켜져 있어서, 시작할 때의 환경에는 화면 정보가 없다.
    KDE는 로그인하면 화면 정보를 사용자 서비스 관리자(systemd --user)에 알려 주므로,
    프로그램을 띄울 때마다 거기서 최신 값을 읽어 온다.
    """
    env = dict(os.environ)
    try:
        r = subprocess.run(["systemctl", "--user", "show-environment"],
                           capture_output=True, text=True, timeout=3)
        if r.returncode == 0:
            fresh = parse_environment(r.stdout)
            env.update({k: fresh[k] for k in _SESSION_KEYS if k in fresh})
    except (OSError, subprocess.SubprocessError):
        pass
    return env


class NoSessionError(RuntimeError):
    pass


def _spawn(argv: list[str]) -> None:
    env = session_environment()
    if not (env.get("WAYLAND_DISPLAY") or env.get("DISPLAY")):
        raise NoSessionError("아직 로그인된 화면이 없어 프로그램을 띄울 수 없습니다. 로그인한 뒤 다시 말씀해 주세요.")
    subprocess.Popen(
        argv,
        env=env,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,   # aiosd가 꺼져도 실행한 프로그램은 계속 동작
        close_fds=True,
    )


def application_dirs() -> list[Path]:
    home = Path.home()
    data_home = Path(os.environ.get("XDG_DATA_HOME", home / ".local/share"))
    data_dirs = os.environ.get("XDG_DATA_DIRS", "/usr/local/share:/usr/share").split(":")
    dirs = [data_home / "applications"]
    dirs += [Path(d) / "applications" for d in data_dirs if d]
    dirs += [
        home / ".local/share/flatpak/exports/share/applications",
        Path("/var/lib/flatpak/exports/share/applications"),
        Path("/var/lib/snapd/desktop/applications"),
    ]
    out = []
    for d in dirs:
        if d not in out:
            out.append(d)
    return out


def parse_desktop_file(path: Path, lang: str = "ko") -> App | None:
    cp = ConfigParser(interpolation=None, strict=False)
    cp.optionxform = str  # 대소문자 유지
    try:
        cp.read(path, encoding="utf-8")
    except Exception:
        return None
    if "Desktop Entry" not in cp:
        return None
    e = cp["Desktop Entry"]
    if e.get("Type", "Application") != "Application":
        return None
    if e.get("NoDisplay", "false").lower() == "true" or e.get("Hidden", "false").lower() == "true":
        return None
    if not e.get("Exec"):
        return None
    name = e.get(f"Name[{lang}]") or e.get("Name") or path.stem
    names = {name, e.get("Name", ""), path.stem}
    for key in ("GenericName", f"GenericName[{lang}]", "Keywords", f"Keywords[{lang}]"):
        for part in (e.get(key) or "").split(";"):
            if part.strip():
                names.add(part.strip())
    return App(id=path.name, name=name, names=sorted(n for n in names if n), target=str(path))


def exec_to_argv(exec_line: str) -> list[str]:
    """.desktop Exec 줄에서 %U 같은 자리표시를 지우고 인자 목록으로 바꾼다."""
    argv = []
    for tok in shlex.split(exec_line):
        if tok in _FIELD_CODES:
            continue
        argv.append(tok.replace("%%", "%"))
    return argv


class LinuxPlatform(Platform):
    name = "linux"

    def __init__(self):
        self._cpu_prev: tuple[int, int] | None = None

    # ── 앱 ──
    def list_apps(self) -> list[App]:
        apps: dict[str, App] = {}
        for d in application_dirs():
            if not d.is_dir():
                continue
            for f in d.rglob("*.desktop"):
                if f.name in apps:  # 앞쪽(사용자) 폴더가 우선
                    continue
                app = parse_desktop_file(f)
                if app:
                    apps[f.name] = app
        return sorted(apps.values(), key=lambda a: a.name.lower())

    def launch_app(self, app: App) -> str:
        path = app.target
        if shutil.which("gio"):
            _spawn(["gio", "launch", path])
            return f"gio launch {app.id}"
        if shutil.which("kioclient"):
            _spawn(["kioclient", "exec", path])
            return f"kioclient exec {app.id}"
        cp = ConfigParser(interpolation=None, strict=False)
        cp.optionxform = str
        cp.read(path, encoding="utf-8")
        argv = exec_to_argv(cp["Desktop Entry"]["Exec"])
        if not argv:
            raise RuntimeError("실행 명령을 찾을 수 없습니다")
        _spawn(argv)
        return " ".join(argv)

    # ── Steam ──
    def steam_roots(self) -> list[Path]:
        home = Path.home()
        cands = [
            home / ".local/share/Steam",
            home / ".steam/steam",
            home / ".var/app/com.valvesoftware.Steam/.local/share/Steam",  # Flatpak
            home / "snap/steam/common/.local/share/Steam",
        ]
        out = []
        for c in cands:
            try:
                r = c.resolve()
            except OSError:
                continue
            if r.is_dir() and r not in out:
                out.append(r)
        return out

    def launch_steam_game(self, appid: str) -> str:
        if not appid.isdigit():
            raise ValueError("잘못된 Steam 게임 번호")
        url = f"steam://rungameid/{appid}"
        opener = shutil.which("xdg-open") or shutil.which("steam")
        if not opener:
            raise RuntimeError("xdg-open 또는 steam 명령을 찾을 수 없습니다")
        _spawn([opener, url])
        return url

    # ── 휴지통·웹 ──
    def trash(self, path: Path) -> str:
        from . import fdtrash
        try:
            return str(fdtrash.trash_path(path))
        except OSError as e:
            # 다른 디스크(USB 등)의 파일: 그 디스크의 휴지통을 다루는 KDE/GLib 도구에 맡긴다
            for argv in (["gio", "trash", "--", str(path)], ["kioclient", "move", str(path), "trash:/"]):
                if shutil.which(argv[0]):
                    r = subprocess.run(argv, capture_output=True, text=True, timeout=30,
                                       env=session_environment())
                    if r.returncode == 0:
                        return f"휴지통 ({argv[0]})"
            raise RuntimeError(f"휴지통으로 옮기지 못했습니다: {e}") from e

    def empty_trash(self) -> int:
        from . import fdtrash
        return fdtrash.empty()

    def trash_dir(self) -> Path | None:
        from . import fdtrash
        return fdtrash.home_trash()

    def open_url(self, url: str) -> str:
        opener = shutil.which("xdg-open") or shutil.which("kde-open")
        if not opener:
            raise RuntimeError("웹 주소를 열 프로그램(xdg-open)을 찾을 수 없습니다")
        _spawn([opener, url])
        return url

    # ── 코딩 모드: 격리 실행 (bubblewrap) ──
    @property
    def sandboxed(self) -> bool:
        return shutil.which("bwrap") is not None

    def _program_env(self, project_dir: Path) -> dict:
        env = {k: v for k, v in session_environment().items()
               if k in ("PATH", "LANG", "LANGUAGE", "LC_ALL", "TERM") or k in _SESSION_KEYS}
        env.setdefault("PATH", "/usr/local/bin:/usr/bin:/bin")
        env.update({"HOME": str(project_dir), "PYTHONDONTWRITEBYTECODE": "1", "PYTHONIOENCODING": "utf-8"})
        return env

    def _sandbox(self, argv: list[str], project_dir: Path, gui: bool) -> list[str]:
        """작업 폴더만 쓸 수 있고, 홈 폴더의 다른 파일은 보이지 않으며, 인터넷이 막힌 상태로 실행."""
        bwrap = shutil.which("bwrap")
        if not bwrap:
            raise RuntimeError("격리 실행 도구(bubblewrap)가 없어 실행하지 않습니다. 'sudo apt install bubblewrap' 필요")
        home = str(Path.home())
        p = str(project_dir)
        args = [bwrap, "--ro-bind", "/", "/", "--dev", "/dev", "--proc", "/proc", "--tmpfs", "/tmp",
                "--tmpfs", home, "--bind", p, p,
                "--unshare-net", "--unshare-pid", "--unshare-ipc", "--die-with-parent", "--new-session",
                "--chdir", p]
        if gui:
            # 창을 띄우려면 화면 연결(Wayland 소켓 등)이 있는 실행 폴더가 필요
            run_dir = session_environment().get("XDG_RUNTIME_DIR") or f"/run/user/{os.getuid()}"
            args += ["--bind", run_dir, run_dir]
        return args + ["--"] + argv

    def run_program(self, argv: list[str], project_dir: Path, timeout: float) -> tuple[int, str]:
        return super().run_program(self._sandbox(argv, project_dir, gui=False), project_dir, timeout)

    def open_program(self, argv: list[str], project_dir: Path) -> str:
        env = self._program_env(project_dir)
        if not (env.get("WAYLAND_DISPLAY") or env.get("DISPLAY")):
            raise NoSessionError("아직 로그인된 화면이 없어 창을 띄울 수 없습니다.")
        subprocess.Popen(self._sandbox(argv, project_dir, gui=True), cwd=project_dir, env=env,
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True, close_fds=True)
        return " ".join(argv)

    # ── 시스템 상태 ──
    @staticmethod
    def _read_cpu() -> tuple[int, int]:
        with open("/proc/stat") as f:
            parts = [int(x) for x in f.readline().split()[1:]]
        idle = parts[3] + (parts[4] if len(parts) > 4 else 0)
        return idle, sum(parts)

    def cpu_percent(self) -> float | None:
        try:
            i1, t1 = self._read_cpu()
            time.sleep(0.2)
            i2, t2 = self._read_cpu()
        except OSError:
            return None
        dt = t2 - t1
        return round(100.0 * (1 - (i2 - i1) / dt), 1) if dt > 0 else None

    def memory_mb(self) -> tuple[int, int] | None:
        try:
            info = {}
            with open("/proc/meminfo") as f:
                for line in f:
                    k, v = line.split(":", 1)
                    info[k] = int(v.split()[0])  # kB
            total = info["MemTotal"] // 1024
            avail = info.get("MemAvailable", info.get("MemFree", 0)) // 1024
            return total, total - avail
        except (OSError, KeyError, ValueError):
            return None

    def gpus(self) -> list[GpuInfo]:
        return read_amdgpu_sysfs(Path("/sys/class/drm"))

    def user_dirs(self) -> dict[str, Path]:
        d = super().user_dirs()
        # ~/.config/user-dirs.dirs (한국어 설치 시 '다운로드' 같은 실제 폴더명이 여기 있음)
        cfg = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "user-dirs.dirs"
        mapping = {
            "XDG_DOWNLOAD_DIR": ["다운로드"],
            "XDG_DOCUMENTS_DIR": ["문서"],
            "XDG_PICTURES_DIR": ["사진", "그림"],
            "XDG_DESKTOP_DIR": ["바탕화면"],
            "XDG_MUSIC_DIR": ["음악"],
            "XDG_VIDEOS_DIR": ["동영상", "비디오"],
        }
        if cfg.is_file():
            for line in cfg.read_text(encoding="utf-8", errors="replace").splitlines():
                if "=" not in line or line.lstrip().startswith("#"):
                    continue
                k, v = line.split("=", 1)
                v = v.strip().strip('"').replace("$HOME", str(Path.home()))
                for kor in mapping.get(k.strip(), []):
                    d[kor] = Path(v)
        return d


def read_amdgpu_sysfs(drm: Path) -> list[GpuInfo]:
    """AMD GPU의 VRAM 사용량을 관리자 권한 없이 읽는다."""
    out = []
    if not drm.is_dir():
        return out
    for card in sorted(drm.glob("card[0-9]*")):
        if "-" in card.name:  # card0-DP-1 같은 출력 포트 항목 제외
            continue
        dev = card / "device"
        total_f, used_f = dev / "mem_info_vram_total", dev / "mem_info_vram_used"
        if not total_f.exists():
            continue
        try:
            total = int(total_f.read_text().strip()) // (1024 * 1024)
            used = int(used_f.read_text().strip()) // (1024 * 1024)
        except (OSError, ValueError):
            continue
        name = "AMD GPU"
        pn = dev / "product_name"
        if pn.exists():
            try:
                name = pn.read_text().strip() or name
            except OSError:
                pass
        out.append(GpuInfo(name=f"{name} ({card.name})", vram_total_mb=total, vram_used_mb=used))
    return out
