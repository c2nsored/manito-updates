// MANITO 버튼 + 메신저 대화창 (위쪽 막대 왼쪽 끝).
// - 막대에는 작은 오브와 MANITO 글자. 누르거나 Meta+Space로 대화창이 열린다.
// - 대화창: 왼쪽은 지난 대화 목록(+ 새 대화), 오른쪽은 말풍선과 입력칸. 오른쪽 위 버튼으로 별도 창(웹 화면)으로 열기.
// - AI 서비스(aiosd, http://127.0.0.1:8765)의 대화 기록을 그대로 보여 주므로, 바탕화면 입력칸·알림 답장에서
//   나눈 대화도 여기에 함께 쌓인다. 서비스가 꺼져 있어도 바탕화면은 정상 동작 (설계 원칙 1).
import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.components as PlasmaComponents
import org.kde.kirigami as Kirigami
import "file:///usr/share/manito/qml/Manito"

PlasmoidItem {
    id: root

    readonly property string api: "http://127.0.0.1:8765"
    readonly property var stateText: ({ idle: "대기 중", thinking: "생각 중…", working: "작업 중…",
                                        complete: "완료", error: "문제가 생겼어요", disabled: "AI 서비스 꺼짐" })
    property string conversationId: ""
    property bool busy: false
    property var pendingApprovals: ({})

    ListModel { id: conversations }   // { cid, title, when }
    ListModel { id: messages }        // { who: "user"|"ai"|"note", text, approvalId }
    ManitoAiLink { id: link; active: true; interval: 800 }

    Plasmoid.icon: "manito"
    toolTipMainText: "마니또"
    toolTipSubText: stateText[link.state] || ""
    preferredRepresentation: compactRepresentation

    onExpandedChanged: if (expanded) refresh()

    // ── AI 서비스와 주고받기 ──
    function request(method, path, body, done) {
        var xhr = new XMLHttpRequest()
        xhr.onreadystatechange = function () {
            if (xhr.readyState !== XMLHttpRequest.DONE) return
            var out = null
            try { out = JSON.parse(xhr.responseText) } catch (e) {}
            done(xhr.status === 200 ? out : null)
        }
        xhr.open(method, api + path)
        if (body !== undefined) xhr.setRequestHeader("Content-Type", "application/json")
        xhr.send(body !== undefined ? JSON.stringify(body) : null)
    }

    function when(sec) {
        var d = new Date(sec * 1000), now = new Date()
        if (d.toDateString() === now.toDateString()) return Qt.formatTime(d, "hh:mm")
        var y = new Date(now); y.setDate(now.getDate() - 1)
        if (d.toDateString() === y.toDateString()) return "어제"
        return (d.getMonth() + 1) + "월 " + d.getDate() + "일"
    }

    function refresh() {
        request("GET", "/api/approvals", undefined, function (list) {
            var p = {}
            for (var i = 0; list && i < list.length; i++) p[list[i].id] = true
            pendingApprovals = p
            request("GET", "/api/conversations", undefined, function (convs) {
                conversations.clear()
                for (var j = 0; convs && j < convs.length; j++)
                    conversations.append({ cid: convs[j].id, title: convs[j].title || "대화", when: when(convs[j].updated) })
                if (!conversationId && conversations.count > 0) conversationId = conversations.get(0).cid
                loadMessages()
            })
        })
    }

    function loadMessages() {
        messages.clear()
        if (!conversationId) return
        request("GET", "/api/conversations/" + conversationId + "/messages", undefined, function (list) {
            messages.clear()
            for (var i = 0; list && i < list.length; i++) {
                var m = list[i], aid = (m.meta && m.meta.approval_id) || ""
                messages.append({ who: m.role === "user" ? "user" : "ai", text: m.content,
                                  approvalId: pendingApprovals[aid] ? aid : "" })
            }
        })
    }

    function newConversation() { conversationId = ""; messages.clear() }

    function send(text) {
        text = text.trim()
        if (!text || busy) return
        messages.append({ who: "user", text: text, approvalId: "" })
        busy = true
        request("POST", "/api/chat", { message: text, conversation_id: conversationId || null }, function (out) {
            busy = false
            if (out) {
                conversationId = out.conversation_id || conversationId
                messages.append({ who: "ai", text: out.reply || "", approvalId: out.approval_id || "" })
                request("GET", "/api/conversations", undefined, function (convs) {
                    conversations.clear()
                    for (var j = 0; convs && j < convs.length; j++)
                        conversations.append({ cid: convs[j].id, title: convs[j].title || "대화", when: when(convs[j].updated) })
                })
            } else {
                messages.append({ who: "note", approvalId: "", text: "AI 서비스에 연결할 수 없어요. 잠시 뒤 다시 시도해 주세요." })
            }
        })
    }

    function decide(index, approve) {
        var id = messages.get(index).approvalId
        messages.setProperty(index, "approvalId", "")
        request("POST", "/api/approvals/" + id, { approve: approve }, function (out) {
            // 코딩 모드에서는 실행 결과를 본 AI가 이어서 작업하고, 다음 허락을 또 물을 수 있다
            messages.append({ who: "ai", approvalId: (out && out.approval_id) || "",
                              text: out ? out.reply : "처리하지 못했어요." })
        })
    }

    // ── 위쪽 막대의 MANITO 버튼 ──
    compactRepresentation: MouseArea {
        id: compact
        Layout.minimumWidth: btnRow.implicitWidth + Kirigami.Units.largeSpacing * 2
        Layout.preferredWidth: Layout.minimumWidth
        hoverEnabled: true
        onClicked: root.expanded = !root.expanded
        Accessible.name: "마니또 대화창 열기"
        Accessible.role: Accessible.Button

        Rectangle {
            anchors.fill: parent
            anchors.topMargin: 2; anchors.bottomMargin: 2
            radius: height / 2
            color: Qt.alpha(Kirigami.Theme.textColor, root.expanded ? 0.12 : (compact.containsMouse ? 0.07 : 0))
        }
        Row {
            id: btnRow
            anchors.centerIn: parent
            spacing: 2
            ManitoOrb {
                width: compact.height * 1.05; height: width
                anchors.verticalCenter: parent.verticalCenter
                aiState: root.busy && link.state === "idle" ? "thinking" : link.state
                dark: Kirigami.Theme.textColor.hslLightness > 0.5
            }
            ManitoWordmark {
                anchors.verticalCenter: parent.verticalCenter
                size: Math.max(10, Math.round(compact.height * 0.40))
                color: Kirigami.Theme.textColor
                width: implicitWidth; height: implicitHeight
            }
        }
    }

    // ── 메신저 대화창 ──
    fullRepresentation: Item {
        id: full
        Layout.preferredWidth: Kirigami.Units.gridUnit * 40
        Layout.preferredHeight: Kirigami.Units.gridUnit * 30
        Layout.minimumWidth: Kirigami.Units.gridUnit * 28
        Layout.minimumHeight: Kirigami.Units.gridUnit * 18

        readonly property color ink: Kirigami.Theme.textColor
        readonly property color hair: Qt.alpha(ink, 0.10)
        readonly property color accent: Kirigami.Theme.textColor.hslLightness > 0.5 ? "#C99478" : "#C98E70"

        Connections {
            target: root
            function onExpandedChanged() { if (root.expanded) input.forceActiveFocus() }
        }

        // 불투명 배경 (KDE 팝업 기본 배경은 반투명이라 뒤 창 글자가 비쳐 보임)
        Rectangle {
            anchors.fill: parent
            anchors.margins: -Kirigami.Units.smallSpacing
            radius: Kirigami.Units.cornerRadius * 2
            color: Kirigami.Theme.backgroundColor
        }

        // 왼쪽: 대화 목록
        Rectangle {
            id: side
            width: Kirigami.Units.gridUnit * 12
            height: parent.height
            color: Qt.alpha(full.ink, 0.03)
            radius: Kirigami.Units.cornerRadius * 2
            Rectangle { anchors.right: parent.right; width: 1; height: parent.height; color: full.hair }

            Item {
                id: sideHead
                x: Kirigami.Units.largeSpacing; width: parent.width - Kirigami.Units.largeSpacing * 2
                height: Kirigami.Units.gridUnit * 2.4
                Kirigami.Heading { level: 4; text: "대화"; anchors.verticalCenter: parent.verticalCenter }
                PlasmaComponents.ToolButton {
                    anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter
                    icon.name: "list-add"
                    PlasmaComponents.ToolTip.text: "새 대화"
                    PlasmaComponents.ToolTip.visible: hovered
                    onClicked: { root.newConversation(); input.forceActiveFocus() }
                }
            }
            ListView {
                anchors.top: sideHead.bottom; anchors.bottom: parent.bottom
                anchors.left: parent.left; anchors.right: parent.right
                anchors.margins: Kirigami.Units.smallSpacing
                clip: true
                spacing: 2
                model: conversations
                delegate: MouseArea {
                    required property string cid
                    required property string title
                    required property string when
                    width: ListView.view.width
                    height: Kirigami.Units.gridUnit * 2.8
                    hoverEnabled: true
                    onClicked: { root.conversationId = cid; root.loadMessages() }
                    Rectangle {
                        anchors.fill: parent
                        radius: Kirigami.Units.cornerRadius * 2
                        color: cid === root.conversationId ? Qt.alpha(full.accent, 0.18)
                                                           : (parent.containsMouse ? Qt.alpha(full.ink, 0.05) : "transparent")
                    }
                    Column {
                        x: Kirigami.Units.largeSpacing; anchors.verticalCenter: parent.verticalCenter
                        width: parent.width - Kirigami.Units.largeSpacing * 2
                        PlasmaComponents.Label { text: title; width: parent.width; elide: Text.ElideRight }
                        PlasmaComponents.Label { text: when; opacity: 0.55; font: Kirigami.Theme.smallFont }
                    }
                }
                PlasmaComponents.Label {
                    anchors.centerIn: parent
                    visible: conversations.count === 0
                    text: "아직 대화가 없어요"
                    opacity: 0.5
                }
            }
        }

        // 오른쪽: 대화 내용
        Item {
            anchors.left: side.right; anchors.leftMargin: Kirigami.Units.largeSpacing
            anchors.right: parent.right
            height: parent.height

            RowLayout {
                id: head
                width: parent.width
                spacing: Kirigami.Units.smallSpacing
                ManitoOrb {
                    Layout.preferredWidth: Kirigami.Units.gridUnit * 2.6
                    Layout.preferredHeight: Layout.preferredWidth
                    aiState: root.busy && link.state === "idle" ? "thinking" : link.state
                    dark: Kirigami.Theme.textColor.hslLightness > 0.5
                }
                ColumnLayout {
                    spacing: 0
                    Kirigami.Heading { level: 4; text: "마니또" }
                    PlasmaComponents.Label { text: root.stateText[link.state] || ""; opacity: 0.55; font: Kirigami.Theme.smallFont }
                }
                Item { Layout.fillWidth: true }
                PlasmaComponents.ToolButton {
                    icon.name: "window-new"
                    PlasmaComponents.ToolTip.text: "창으로 열기"
                    PlasmaComponents.ToolTip.visible: hovered
                    onClicked: { Qt.openUrlExternally(root.api + "/"); root.expanded = false }
                }
            }
            Rectangle { id: headLine; anchors.top: head.bottom; anchors.topMargin: Kirigami.Units.smallSpacing; width: parent.width; height: 1; color: full.hair }

            ListView {
                id: list
                anchors.top: headLine.bottom; anchors.topMargin: Kirigami.Units.largeSpacing
                anchors.bottom: inputBox.top; anchors.bottomMargin: Kirigami.Units.largeSpacing
                width: parent.width
                clip: true
                spacing: Kirigami.Units.largeSpacing
                model: messages
                onCountChanged: Qt.callLater(positionViewAtEnd)

                PlasmaComponents.Label {
                    parent: list
                    anchors.centerIn: parent
                    width: list.width * 0.8
                    visible: messages.count === 0
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.WordWrap
                    opacity: 0.55
                    text: link.state === "disabled" ? "AI 서비스가 아직 켜지지 않았어요."
                          : "무엇을 도와드릴까요?\n예) 엣지 켜줘 · 다운로드에서 pdf 찾아줘 · 시스템 상태 알려줘"
                }

                delegate: Item {
                    id: entry
                    required property int index
                    required property string who
                    required property string text
                    required property string approvalId
                    width: ListView.view.width
                    height: bubble.height + (buttons.visible ? buttons.height + Kirigami.Units.smallSpacing : 0)

                    Rectangle {
                        id: bubble
                        readonly property bool mine: entry.who === "user"
                        anchors.right: mine ? parent.right : undefined
                        width: Math.min(msg.implicitWidth, parent.width * 0.78 - Kirigami.Units.largeSpacing * 2) + Kirigami.Units.largeSpacing * 2
                        height: msg.implicitHeight + Kirigami.Units.smallSpacing * 3
                        radius: Kirigami.Units.gridUnit
                        color: mine ? Qt.alpha(full.accent, 0.22) : Qt.alpha(full.ink, entry.who === "note" ? 0.03 : 0.06)
                        PlasmaComponents.Label {
                            id: msg
                            x: Kirigami.Units.largeSpacing
                            anchors.verticalCenter: parent.verticalCenter
                            width: Math.min(implicitWidth, entry.width * 0.78 - Kirigami.Units.largeSpacing * 2)
                            text: entry.text
                            wrapMode: Text.Wrap
                            textFormat: Text.PlainText
                            opacity: entry.who === "note" ? 0.7 : 1
                        }
                    }
                    Row {
                        id: buttons
                        visible: entry.approvalId !== ""
                        anchors.top: bubble.bottom
                        anchors.topMargin: Kirigami.Units.smallSpacing
                        spacing: Kirigami.Units.smallSpacing
                        PlasmaComponents.Button { text: "허락"; onClicked: root.decide(entry.index, true) }
                        PlasmaComponents.Button { text: "거절"; onClicked: root.decide(entry.index, false) }
                    }
                }
            }

            Rectangle {
                id: inputBox
                anchors.bottom: parent.bottom
                width: parent.width
                height: Kirigami.Units.gridUnit * 2.4
                radius: height / 2
                color: "transparent"
                border.width: 1
                border.color: input.activeFocus ? Qt.alpha(full.accent, 0.6) : full.hair

                MouseArea { anchors.fill: parent; cursorShape: Qt.IBeamCursor; onClicked: input.forceActiveFocus() }
                TextInput {
                    id: input
                    anchors.left: parent.left; anchors.leftMargin: Kirigami.Units.gridUnit
                    anchors.right: sendBtn.left; anchors.rightMargin: Kirigami.Units.smallSpacing
                    anchors.verticalCenter: parent.verticalCenter
                    color: full.ink
                    font: Kirigami.Theme.defaultFont
                    clip: true
                    enabled: !root.busy
                    onAccepted: { root.send(text); text = "" }
                    Keys.onEscapePressed: root.expanded = false
                    Accessible.role: Accessible.EditableText
                    Accessible.name: "마니또에게 말하기"
                    PlasmaComponents.Label {
                        anchors.fill: parent
                        verticalAlignment: Text.AlignVCenter
                        visible: input.text === ""
                        opacity: 0.5
                        text: root.busy ? "마니또가 생각하는 중…" : "마니또에게 말하기"
                    }
                }
                Rectangle {
                    id: sendBtn
                    anchors.right: parent.right; anchors.rightMargin: 5
                    anchors.verticalCenter: parent.verticalCenter
                    width: parent.height - 10; height: width; radius: width / 2
                    color: Qt.alpha(full.accent, input.text ? 0.35 : 0.15)
                    Kirigami.Icon { anchors.centerIn: parent; width: Kirigami.Units.iconSizes.small; height: width; source: "go-up" }
                    MouseArea { anchors.fill: parent; onClicked: { root.send(input.text); input.text = "" } }
                }
            }
        }
    }
}
