// MANITO 바탕화면 위젯: 살아 있는 오브 + 그 아래 미니멀한 입력칸.
// 입력하면 AI 서비스(aiosd)에 보내고, 마니또의 답변은 시스템 알림으로 띄운다.
// 바탕화면에서 나눈 말은 하나의 대화로 이어지고, 위쪽 MANITO 버튼의 대화 목록에도 남는다.
// AI 서비스가 꺼져 있으면 오브는 "꺼짐", 입력칸은 안내만 보여 주고 바탕화면은 정상 동작 (설계 원칙 1).
import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.kirigami as Kirigami
import org.kde.notification
import "file:///usr/share/manito/qml/Manito"

PlasmoidItem {
    id: root

    readonly property string api: "http://127.0.0.1:8765"
    property string conversationId: ""       // 바탕화면에서 나눈 말은 하나의 대화로 이어 간다
    property bool busy: false
    property string lastAsk: ""

    Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground
    preferredRepresentation: fullRepresentation

    ManitoAiLink { id: link; active: true; interval: 800 }

    function send(text) {
        text = text.trim()
        if (!text || busy) return
        busy = true
        lastAsk = text
        var xhr = new XMLHttpRequest()
        xhr.onreadystatechange = function () {
            if (xhr.readyState !== XMLHttpRequest.DONE) return
            busy = false
            var out = null
            try { out = JSON.parse(xhr.responseText) } catch (e) {}
            if (xhr.status === 200 && out) {
                conversationId = out.conversation_id || conversationId
                var reply = out.reply || ""
                if (out.approval_id)
                    reply += "\n\n허락이 필요한 작업이에요. 위쪽 MANITO 버튼을 눌러 확인해 주세요."
                notify(reply)
            } else {
                notify("AI 서비스에 연결할 수 없어요. 잠시 뒤 다시 시도해 주세요.")
            }
            fadeAsk.restart()
        }
        xhr.open("POST", api + "/api/chat")
        xhr.setRequestHeader("Content-Type", "application/json")
        xhr.send(JSON.stringify({ message: text, conversation_id: conversationId || null }))
    }

    function notify(text) {
        var n = noteComponent.createObject(root, { text: text })
        n.sendEvent()
    }

    Component {
        id: noteComponent
        Notification {
            componentName: "manito"          // /usr/share/knotifications6/manito.notifyrc
            eventId: "reply"
            title: "마니또"
            iconName: "manito"
            autoDelete: true
            // (알림 안 "답장" 칸은 KDE가 위젯에서 만들 수 없게 막아 둠 — 2026-11-15 확인. 이어 말하기는 바탕화면 입력칸·MANITO 버튼에서)
        }
    }

    Timer { id: fadeAsk; interval: 6000; onTriggered: root.lastAsk = "" }

    fullRepresentation: Item {
        id: full
        Layout.minimumWidth: Kirigami.Units.gridUnit * 20
        Layout.minimumHeight: Kirigami.Units.gridUnit * 16
        Layout.preferredWidth: Kirigami.Units.gridUnit * 34
        Layout.preferredHeight: Kirigami.Units.gridUnit * 25

        readonly property color ink: ManitoTheme.textColor
        readonly property color hair: ManitoTheme.withAlpha(ink, ManitoTheme.dark ? 0.14 : 0.10)
        readonly property color accent: ManitoTheme.dark ? "#C99478" : "#C98E70"

        ManitoOrb {
            id: orb
            width: Math.min(full.width, full.height - pill.height - 40)
            height: width
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.bottom: pill.top
            anchors.bottomMargin: -width * 0.07     // 아우라 바깥쪽은 비어 있으므로 입력칸과 살짝 겹친다
            aiState: root.busy && link.state === "idle" ? "thinking" : link.state
        }

        Text {   // 방금 보낸 말 (몇 초 뒤 사라짐)
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.bottom: pill.top
            anchors.bottomMargin: 10
            text: root.lastAsk ? "“" + root.lastAsk + "”" : ""
            opacity: root.lastAsk ? 0.55 : 0
            Behavior on opacity { NumberAnimation { duration: 600 } }
            color: full.ink
            font.pixelSize: 13
            elide: Text.ElideMiddle
            width: Math.min(implicitWidth, pill.width)
        }

        Rectangle {
            id: pill
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.bottom: parent.bottom
            anchors.bottomMargin: 8
            width: Math.min(full.width - 16, 560)
            height: 54
            radius: height / 2
            color: ManitoTheme.dark ? Qt.rgba(1, 1, 1, 0.06) : Qt.rgba(1, 1, 1, 0.72)
            border.width: 1
            border.color: input.activeFocus ? ManitoTheme.withAlpha(full.accent, 0.55) : full.hair
            Behavior on border.color { ColorAnimation { duration: 250 } }

            Rectangle {   // 아주 옅은 그림자
                z: -1
                anchors.fill: parent; anchors.topMargin: 5; anchors.margins: -2
                radius: parent.radius + 2
                color: ManitoTheme.withAlpha("#5A4A43", ManitoTheme.dark ? 0.18 : 0.03)
            }

            MouseArea {
                anchors.fill: parent
                cursorShape: Qt.IBeamCursor
                onClicked: input.forceActiveFocus()
            }

            TextInput {
                id: input
                anchors.left: parent.left; anchors.leftMargin: 26
                anchors.right: parent.right; anchors.rightMargin: 26
                anchors.verticalCenter: parent.verticalCenter
                color: full.ink
                selectionColor: ManitoTheme.withAlpha(full.accent, 0.35)
                font.pixelSize: 16
                clip: true
                maximumLength: 2000
                enabled: !root.busy
                onAccepted: { root.send(text); text = "" }
                Keys.onEscapePressed: { text = ""; focus = false }
                Accessible.role: Accessible.EditableText
                Accessible.name: "마니또에게 말하기"

                Text {
                    anchors.fill: parent
                    verticalAlignment: Text.AlignVCenter
                    visible: input.text === ""
                    color: full.ink
                    opacity: 0.5
                    font.pixelSize: 16
                    elide: Text.ElideRight
                    text: root.busy ? "마니또가 생각하는 중…"
                          : link.state === "disabled" ? "AI 서비스가 아직 켜지지 않았어요"
                          : "마니또에게 무엇이든 말해 보세요"
                }
            }
        }
    }
}
