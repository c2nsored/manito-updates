// 잠금 화면·로그인 화면용 마니또 입력칸.
// 비밀번호를 모르는 사람도 볼 수 있는 화면이므로 AI 서비스의 "제한 대화"(/api/locked-chat)만 사용한다.
// (상태 확인·AI 끄기 같은 몇 가지 명령만 되고, 대화 기록은 저장·표시하지 않음)
// Plasma 부품 없이 QtQuick만 써서 SDDM(로그인 화면)과 KDE 잠금 화면 양쪽에서 그대로 동작한다.
import QtQuick

Item {
    id: chat

    property url endpoint: "http://127.0.0.1:8765/api/locked-chat"
    property string reply: ""
    property bool busy: false
    property color textColor: "#EFE5DE"

    implicitWidth: 380
    implicitHeight: column.implicitHeight

    ManitoAiLink { id: link; active: chat.visible; interval: 1500 }

    function send() {
        var text = input.text.trim()
        if (!text || busy) return
        busy = true
        var xhr = new XMLHttpRequest()
        xhr.onreadystatechange = function () {
            if (xhr.readyState !== XMLHttpRequest.DONE) return
            busy = false
            var out = null
            try { out = JSON.parse(xhr.responseText) } catch (e) {}
            chat.reply = (xhr.status === 200 && out) ? out.reply : "AI 서비스에 연결할 수 없어요."
            clearTimer.restart()
        }
        xhr.open("POST", endpoint)
        xhr.setRequestHeader("Content-Type", "application/json")
        xhr.send(JSON.stringify({ message: text }))
        input.text = ""
    }

    Timer { id: clearTimer; interval: 20000; onTriggered: chat.reply = "" }

    Column {
        id: column
        width: parent.width
        spacing: 10

        Rectangle {
            width: parent.width
            height: 46
            radius: height / 2
            color: Qt.rgba(1, 1, 1, input.activeFocus ? 0.14 : 0.07)
            border.width: 1
            border.color: Qt.rgba(1, 1, 1, input.activeFocus ? 0.30 : 0.16)

            ManitoOrb {
                id: orb
                width: 46; height: 46
                anchors.left: parent.left
                anchors.leftMargin: 4
                anchors.verticalCenter: parent.verticalCenter
                aiState: chat.busy ? "thinking" : link.state
                dark: true
            }
            TextInput {
                id: input
                anchors.left: orb.right
                anchors.leftMargin: 2
                anchors.right: parent.right
                anchors.rightMargin: 18
                anchors.verticalCenter: parent.verticalCenter
                color: chat.textColor
                selectionColor: Qt.rgba(1, 1, 1, 0.3)
                font.pixelSize: 15
                clip: true
                maximumLength: 300
                activeFocusOnTab: true          // 마우스 없이 Tab 키로도 들어올 수 있게
                enabled: link.connected && !chat.busy
                onAccepted: chat.send()
                Keys.onEscapePressed: { text = ""; focus = false }
                Accessible.role: Accessible.EditableText
                Accessible.name: "마니또에게 말하기 (잠금 상태: 일부 명령만)"

                Text {
                    anchors.fill: parent
                    verticalAlignment: Text.AlignVCenter
                    visible: input.text === ""
                    color: chat.textColor
                    opacity: 0.55
                    font.pixelSize: 15
                    elide: Text.ElideRight
                    text: !link.connected ? "AI 서비스 꺼짐"
                          : chat.busy ? "마니또가 생각하는 중…"
                          : "마니또에게 말하기 · 잠금 중엔 상태 확인만"
                }
            }
            MouseArea {
                anchors.fill: parent
                cursorShape: Qt.IBeamCursor
                onClicked: input.forceActiveFocus()
                z: -1
            }
        }

        Text {
            width: parent.width
            visible: chat.reply !== ""
            text: chat.reply
            color: chat.textColor
            opacity: 0.85
            font.pixelSize: 14
            wrapMode: Text.Wrap
            textFormat: Text.PlainText
            leftPadding: 18
            rightPadding: 18
        }
    }
}
