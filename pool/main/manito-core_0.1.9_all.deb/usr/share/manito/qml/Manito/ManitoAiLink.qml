// AI 서비스(aiosd)와 오브를 잇는 연결부.
// aiosd의 GET /api/ai-state 를 주기적으로 읽어 state 를 갱신한다.
// 서비스에 연결되지 않으면 state 는 "disabled" (AI가 꺼져 있어도 화면은 정상 동작).
//
// 사용 예:
//   ManitoAiLink { id: link; active: true }
//   ManitoOrb { aiState: link.state }
import QtQuick

QtObject {
    id: link

    property bool active: false
    property url endpoint: "http://127.0.0.1:8765/api/ai-state"
    property int interval: 600
    property string state: "disabled"
    property bool connected: false

    property Timer _timer: Timer {
        interval: link.interval
        repeat: true
        running: link.active
        triggeredOnStart: true
        onTriggered: link.poll()
    }
    onActiveChanged: if (!active) { connected = false; state = "disabled" }

    function poll() {
        var xhr = new XMLHttpRequest()
        xhr.timeout = Math.max(300, link.interval * 2)
        xhr.onreadystatechange = function () {
            if (xhr.readyState !== XMLHttpRequest.DONE) return
            if (xhr.status === 200) {
                try {
                    var s = JSON.parse(xhr.responseText).state
                    if (ManitoTheme.validStates.indexOf(s) >= 0) { link.state = s; link.connected = true; return }
                } catch (e) {}
            }
            link.connected = false
            link.state = "disabled"
        }
        xhr.open("GET", link.endpoint)
        xhr.send()
    }
}
