// MANITO AI 오브: 얇고 깔끔한 선 하나 + 그 주위로 은은하게 퍼지는 아우라.
//
// 외부 연결 API
//   aiState        : "idle" | "thinking" | "working" | "complete" | "error" | "disabled"
//   paused         : true면 움직임 정지 (기본: 테마 설정)
//   motionScale    : 0~1, 움직임 크기·속도 배율 (기본: 테마 설정, 접근성 반영)
//   notifyComplete(): 상태와 관계없이 "완료" 빛을 한 번 보여 준다
//   signal completeFinished() : 완료 빛이 끝나 기본 상태로 돌아왔을 때
//
// 원칙: 회전하지 않는다(스피너처럼 보이지 않게). 선의 윤곽과 아우라의 밝기만 아주 천천히 변한다.
import QtQuick
import QtQuick.Shapes

Item {
    id: orb

    property string aiState: "idle"
    property bool paused: ManitoTheme.motionPaused
    property real motionScale: ManitoTheme.motionScale
    property bool dark: ManitoTheme.dark

    signal completeFinished()
    function notifyComplete() { completePulse.restart() }

    implicitWidth: 240
    implicitHeight: 240

    Accessible.role: Accessible.Animation
    Accessible.name: ({ idle: "AI 대기 중", thinking: "AI 생각 중", working: "AI 작업 중",
                        complete: "AI 작업 완료", error: "AI 오류", disabled: "AI 꺼짐" })[visualState] || "AI"

    // 선의 반지름. 바깥쪽은 아우라가 퍼질 자리
    readonly property real baseRadius: Math.min(width, height) * 0.5 / 2.5
    readonly property real cx: width / 2
    readonly property real cy: height / 2

    // ── 상태 → 시각 파라미터 ─────────────────────────────
    property string visualState: "idle"
    onAiStateChanged: applyState()
    onDarkChanged: applyState()
    Component.onCompleted: applyState()

    function applyState() {
        var s = ManitoTheme.validStates.indexOf(aiState) >= 0 ? aiState : "idle"
        if (s === "complete") {
            setParams("idle")
            visualState = "complete"
            completePulse.restart()
            return
        }
        completePulse.stop(); pulse = 0
        visualState = s
        setParams(s)
    }
    function setParams(s) {
        var p = ManitoTheme.orbStates[s]
        breathPeriod = p.breathPeriod
        breathAmp = p.breathAmp
        wobbleAmp = p.wobbleAmp
        wobbleSpeed = p.wobbleSpeed
        flowAmp = p.flowAmp
        flowSpeed = p.flowSpeed
        auraLevel = p.aura
        lineLevel = p.line
        var c = ManitoTheme.orbColor(p.colors)
        lineColor = c.line
        auraColor = c.aura
    }

    // 상태가 바뀌어도 튀지 않도록 모든 값이 부드럽게 이동한다
    property real breathPeriod: 7.5
    property real breathAmp: 0
    property real wobbleAmp: 0
    property real wobbleSpeed: 0
    property real flowAmp: 0
    property real flowSpeed: 0
    property real auraLevel: 0
    property real lineLevel: 0.6
    property real pulse: 0                    // 완료 빛 (0~1)
    property color lineColor: ManitoTheme.textColor
    property color auraColor: "#EDB09B"

    readonly property int tms: ManitoTheme.stateTransitionMs
    Behavior on breathAmp { NumberAnimation { duration: orb.tms; easing.type: Easing.InOutSine } }
    Behavior on wobbleAmp { NumberAnimation { duration: orb.tms; easing.type: Easing.InOutSine } }
    Behavior on wobbleSpeed { NumberAnimation { duration: orb.tms; easing.type: Easing.InOutSine } }
    Behavior on flowAmp { NumberAnimation { duration: orb.tms; easing.type: Easing.InOutSine } }
    Behavior on flowSpeed { NumberAnimation { duration: orb.tms; easing.type: Easing.InOutSine } }
    Behavior on breathPeriod { NumberAnimation { duration: orb.tms; easing.type: Easing.InOutSine } }
    Behavior on auraLevel { NumberAnimation { duration: orb.tms; easing.type: Easing.InOutSine } }
    Behavior on lineLevel { NumberAnimation { duration: orb.tms; easing.type: Easing.InOutSine } }
    Behavior on lineColor { ColorAnimation { duration: orb.tms; easing.type: Easing.InOutSine } }
    Behavior on auraColor { ColorAnimation { duration: orb.tms; easing.type: Easing.InOutSine } }

    // 완료: 아우라가 한 번 부드럽게 퍼졌다가 돌아온다
    SequentialAnimation {
        id: completePulse
        NumberAnimation { target: orb; property: "pulse"; to: 1; duration: 600; easing.type: Easing.OutSine }
        NumberAnimation { target: orb; property: "pulse"; to: 0; duration: 1300; easing.type: Easing.InOutSine }
        ScriptAction {
            script: {
                if (orb.visualState === "complete") orb.visualState = "idle"
                orb.completeFinished()
            }
        }
    }

    // ── 시간 흐름: 위상을 누적해 주기가 바뀌어도 모양이 튀지 않게 한다 ──
    property real breathPhase: 0
    property real wobblePhase: 0
    property real flowPhase: 0
    readonly property bool animating: !paused && motionScale > 0 && visible && opacity > 0
                                      && (visualState !== "disabled" || breathAmp > 0.0005 || wobbleAmp > 0.0005)

    Timer {
        id: clock
        interval: (orb.visualState === "thinking" || orb.visualState === "working" || orb.pulse > 0)
                  ? ManitoTheme.orbFrameMs : ManitoTheme.orbCalmFrameMs
        repeat: true
        running: orb.animating
        property double last: 0
        onRunningChanged: last = 0
        onTriggered: {
            var now = Date.now()
            var dt = last > 0 ? Math.min((now - last) / 1000, 0.1) : interval / 1000
            last = now
            var k = orb.motionScale
            orb.breathPhase = (orb.breathPhase + dt * k * 2 * Math.PI / orb.breathPeriod) % (2 * Math.PI * 1000)
            orb.wobblePhase += dt * k * orb.wobbleSpeed * 2 * Math.PI
            orb.flowPhase += dt * k * orb.flowSpeed * 2 * Math.PI
        }
    }

    // ── 윤곽 계산 ────────────────────────────────────────
    // 반지름을 각도마다 낮은 주파수의 사인파로 아주 조금 바꾸고, 점들을 부드러운 곡선(Catmull-Rom)으로 잇는다.
    readonly property real breath: Math.sin(breathPhase)
    readonly property string outline: buildOutline(baseRadius, breath, wobblePhase, flowPhase,
                                                   breathAmp, wobbleAmp, flowAmp)

    function buildOutline(R, br, wp, fp, bAmp, wAmp, fAmp) {
        var N = 18
        var r0 = R * (1 + bAmp * br)
        // 작업 중일 때의 리듬: 숨과 함께 방향성이 살짝 커졌다 작아진다
        var flowGain = fAmp * (0.75 + 0.25 * br)
        var pts = []
        for (var i = 0; i < N; i++) {
            var t = i / N * 2 * Math.PI
            var w = 0.55 * Math.sin(2 * t + wp + 0.4)
                  + 0.35 * Math.sin(3 * t - wp * 0.71 + 1.9)
                  + 0.20 * Math.sin(5 * t + wp * 0.43 + 4.1)
            var r = r0 * (1 + wAmp * w + flowGain * Math.cos(t - fp))
            pts.push([cx + r * Math.cos(t), cy + r * Math.sin(t)])
        }
        var f = function (v) { return v.toFixed(2) }
        var d = "M " + f(pts[0][0]) + " " + f(pts[0][1])
        for (i = 0; i < N; i++) {
            var p0 = pts[(i - 1 + N) % N], p1 = pts[i], p2 = pts[(i + 1) % N], p3 = pts[(i + 2) % N]
            d += " C " + f(p1[0] + (p2[0] - p0[0]) / 6) + " " + f(p1[1] + (p2[1] - p0[1]) / 6)
               + " " + f(p2[0] - (p3[0] - p1[0]) / 6) + " " + f(p2[1] - (p3[1] - p1[1]) / 6)
               + " " + f(p2[0]) + " " + f(p2[1])
        }
        return d + " Z"
    }

    // ── 그리기 ───────────────────────────────────────────
    // 1) 아우라: 선 바깥으로 경계 없이 퍼지는 빛. 원 안은 맑게 비워 둔다.
    //    숨에 맞춰 아주 조금 밝아졌다 어두워진다
    readonly property real auraAlpha: (auraLevel * (1 + 0.18 * breath * (breathAmp > 0 ? 1 : 0)) + 0.3 * pulse)
                                      * (dark ? 0.8 : 1)
    readonly property real auraReach: 2.3 + 0.2 * pulse      // 반지름의 몇 배까지 퍼지는지
    readonly property real lineAt: 1 / auraReach             // 그라데이션에서 선이 놓인 위치
    Shape {
        anchors.fill: parent
        preferredRendererType: Shape.CurveRenderer
        ShapePath {
            strokeWidth: -1
            fillGradient: RadialGradient {
                centerX: orb.cx; centerY: orb.cy; focalX: orb.cx; focalY: orb.cy
                centerRadius: orb.baseRadius * orb.auraReach; focalRadius: 0
                GradientStop { position: 0.0;                    color: ManitoTheme.withAlpha(orb.auraColor, orb.auraAlpha * 0.12) }
                GradientStop { position: orb.lineAt * 0.8;       color: ManitoTheme.withAlpha(orb.auraColor, orb.auraAlpha * 0.35) }
                GradientStop { position: orb.lineAt;             color: ManitoTheme.withAlpha(orb.auraColor, orb.auraAlpha) }
                GradientStop { position: orb.lineAt + (1 - orb.lineAt) * 0.35; color: ManitoTheme.withAlpha(orb.auraColor, orb.auraAlpha * 0.38) }
                GradientStop { position: 1.0;                    color: ManitoTheme.withAlpha(orb.auraColor, 0) }
            }
            PathAngleArc {
                centerX: orb.cx; centerY: orb.cy
                radiusX: orb.baseRadius * orb.auraReach; radiusY: radiusX
                startAngle: 0; sweepAngle: 360
            }
        }
    }

    // 2) 선: 속을 채우지 않은 얇은 윤곽 하나
    Shape {
        anchors.fill: parent
        preferredRendererType: Shape.CurveRenderer
        ShapePath {
            fillColor: "transparent"
            strokeColor: ManitoTheme.withAlpha(orb.lineColor, Math.min(1, orb.lineLevel + 0.2 * orb.pulse))
            strokeWidth: Math.max(1.0, orb.baseRadius * 0.012)
            joinStyle: ShapePath.RoundJoin
            capStyle: ShapePath.RoundCap
            PathSvg { path: orb.outline }
        }
    }
}
