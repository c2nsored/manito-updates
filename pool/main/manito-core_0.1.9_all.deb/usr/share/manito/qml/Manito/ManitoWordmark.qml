// MANITO 워드마크. 움직이지 않으며, 배경·오브 없이도 단독으로 쓸 수 있다.
import QtQuick

Item {
    id: root

    property real size: 72                      // 글자 크기(px). 화면 배율은 Qt가 자동 처리
    property color color: ManitoTheme.textColor
    property bool showTagline: false
    property string tagline: "Human and AI, together."

    // 작은 크기에서는 자간을 줄여 글자가 흩어져 보이지 않게 한다
    readonly property real tracking: size * (size < 28 ? 0.16 : 0.26)
    readonly property real taglineSize: Math.max(11, size * 0.2)

    implicitWidth: Math.max(wordBox.width, taglineText.visible ? taglineText.implicitWidth : 0)
    implicitHeight: wordBox.height + (taglineText.visible ? taglineText.anchors.topMargin + taglineText.implicitHeight : 0)

    Accessible.role: Accessible.StaticText
    Accessible.name: "MANITO"

    // 자간은 마지막 글자 뒤에도 붙기 때문에, 그만큼 빼서 정확히 가운데에 놓는다
    Item {
        id: wordBox
        anchors.horizontalCenter: parent.horizontalCenter
        width: word.implicitWidth - root.tracking
        height: word.implicitHeight
        Text {
            id: word
            text: "MANITO"
            color: root.color
            font.family: ManitoTheme.wordmarkFamily
            font.weight: Font.Normal
            font.pixelSize: root.size
            font.letterSpacing: root.tracking
            font.kerning: true
            renderType: Text.QtRendering
        }
    }

    Text {
        id: taglineText
        visible: root.showTagline
        anchors.top: wordBox.bottom
        anchors.topMargin: root.size * 0.5
        anchors.horizontalCenter: parent.horizontalCenter
        text: root.tagline
        color: ManitoTheme.withAlpha(root.color, ManitoTheme.dark ? 0.55 : 0.58)
        font.family: ManitoTheme.lightFamily
        font.weight: Font.Light
        font.pixelSize: root.taglineSize
        font.letterSpacing: root.taglineSize * 0.08
    }
}
