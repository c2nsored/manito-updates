// MANITO 배경: 거의 단색인 따뜻한 아이보리. 위에서 아래로 아주 미세하게만 짙어진다.
// 무늬·움직임 없이 그 자체로 완성된 화면이어야 한다.
import QtQuick

Rectangle {
    id: root

    property bool dark: ManitoTheme.dark

    property color topColor: dark ? ManitoTheme.nightBase : ManitoTheme.warmIvory
    property color bottomColor: dark ? Qt.darker(ManitoTheme.nightBase, 1.12)
                                     : Qt.tint(ManitoTheme.warmIvory, ManitoTheme.withAlpha(ManitoTheme.softBeige, 0.35))
    Behavior on topColor { ColorAnimation { duration: 900; easing.type: Easing.InOutSine } }
    Behavior on bottomColor { ColorAnimation { duration: 900; easing.type: Easing.InOutSine } }

    gradient: Gradient {
        GradientStop { position: 0.0; color: root.topColor }
        GradientStop { position: 1.0; color: root.bottomColor }
    }
}
