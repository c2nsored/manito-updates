// MANITO 디자인 시스템: 색상·글꼴·움직임 설정을 한곳에서 관리한다.
// 다른 컴포넌트는 값을 직접 쓰지 않고 이 테마를 참조한다.
pragma Singleton
import QtQuick

QtObject {
    id: theme

    // ── 외부에서 바꾸는 설정 ─────────────────────────────
    // 어두운 화면. 기본값은 시스템(KDE) 밝기 설정을 따른다
    // (Qt 6.5+ 런타임에는 있는 속성이지만 검사 도구가 형식을 몰라 경고를 내므로 이 줄만 검사 제외)
    property bool dark: Qt.styleHints.colorScheme === Qt.ColorScheme.Dark // qmllint disable missing-property
    property bool motionPaused: false    // 모든 움직임 일시정지 (접근성 "움직임 끄기" 포함)
    property bool reducedMotion: false   // 접근성 "움직임 줄이기": 진폭·속도를 크게 낮춤

    // 움직임 배율 (0 = 정지, 1 = 기본)
    readonly property real motionScale: motionPaused ? 0 : (reducedMotion ? 0.3 : 1)

    // ── 팔레트 ───────────────────────────────────────────
    readonly property color warmIvory: "#F8F3EF"
    readonly property color softBeige: "#EDE1D8"
    readonly property color mutedPeach: "#E8C8BC"
    readonly property color dustyRose: "#DCC4C1"
    readonly property color warmCharcoal: "#403631"

    // 어두운 화면용 (같은 색온도를 유지한 짙은 톤)
    readonly property color nightDeep: "#1C1715"
    readonly property color nightBase: "#26201D"
    readonly property color nightPeach: "#4A3530"
    readonly property color nightRose: "#3E3033"
    readonly property color nightText: "#EFE5DE"

    readonly property color textColor: dark ? nightText : warmCharcoal
    readonly property color subtleTextColor: withAlpha(textColor, dark ? 0.55 : 0.58)

    function withAlpha(c, a) { return Qt.rgba(c.r, c.g, c.b, a) }

    // ── 글꼴 (Montserrat, SIL OFL 1.1 — fonts/Montserrat-LICENSE.txt) ──
    readonly property FontLoader regularFont: FontLoader { source: Qt.resolvedUrl("../fonts/Montserrat-Regular.otf") }
    readonly property FontLoader lightFont: FontLoader { source: Qt.resolvedUrl("../fonts/Montserrat-Light.otf") }
    readonly property string wordmarkFamily: regularFont.status === FontLoader.Ready ? regularFont.name : "Montserrat"
    readonly property string lightFamily: lightFont.status === FontLoader.Ready ? lightFont.name : "Montserrat"

    // ── 움직임 기본값 ────────────────────────────────────
    readonly property int stateTransitionMs: 1600     // 상태가 바뀔 때 부드럽게 넘어가는 시간
    readonly property int orbFrameMs: 33              // 활발한 상태의 오브 갱신 간격 (약 30fps)
    readonly property int orbCalmFrameMs: 50          // 대기·오류 상태 (약 20fps — 아주 느린 움직임엔 충분)

    // ── AI 오브 색 ───────────────────────────────────────
    // line: 얇은 윤곽선, aura: 주위로 퍼지는 빛
    // normal: 워드마크와 같은 계열의 따뜻한 차콜 선 + 피치 빛
    // error: 차분한 흙빛 (붉은 경고색 쓰지 않음), disabled: 옅은 회갈색, 빛 없음
    function orbColor(kind) {
        if (kind === "error")
            return dark ? { line: "#C9AE9A", aura: "#8A6E5E" } : { line: "#8C7466", aura: "#CDB5A3" }
        if (kind === "disabled")
            return dark ? { line: "#6E625C", aura: "#3A312D" } : { line: "#B3A8A1", aura: "#DDD4CE" }
        return dark ? { line: "#EFE2D8", aura: "#C99478" } : { line: "#5A4A43", aura: "#EDBFA4" }
    }

    // ── AI 오브 상태별 움직임 ─────────────────────────────
    // breathPeriod: 숨 한 번(초), breathAmp: 크기 변화 비율, wobbleAmp/Speed: 윤곽 변형,
    // flowAmp/Speed: 한쪽으로 흐르는 방향성(작업 중), aura: 빛의 세기, line: 선의 진하기
    readonly property var orbStates: ({
        idle:     { breathPeriod: 7.5, breathAmp: 0.020, wobbleAmp: 0.014, wobbleSpeed: 0.045, flowAmp: 0.000, flowSpeed: 0.00, aura: 0.34, line: 0.50, colors: "normal" },
        thinking: { breathPeriod: 4.6, breathAmp: 0.024, wobbleAmp: 0.030, wobbleSpeed: 0.120, flowAmp: 0.000, flowSpeed: 0.00, aura: 0.44, line: 0.58, colors: "normal" },
        working:  { breathPeriod: 3.4, breathAmp: 0.016, wobbleAmp: 0.020, wobbleSpeed: 0.085, flowAmp: 0.036, flowSpeed: 0.16, aura: 0.44, line: 0.58, colors: "normal" },
        error:    { breathPeriod: 9.0, breathAmp: 0.010, wobbleAmp: 0.008, wobbleSpeed: 0.025, flowAmp: 0.000, flowSpeed: 0.00, aura: 0.26, line: 0.50, colors: "error" },
        disabled: { breathPeriod: 9.0, breathAmp: 0.000, wobbleAmp: 0.000, wobbleSpeed: 0.000, flowAmp: 0.000, flowSpeed: 0.00, aura: 0.00, line: 0.42, colors: "disabled" }
    })
    readonly property var validStates: ["idle", "thinking", "working", "complete", "error", "disabled"]
}
