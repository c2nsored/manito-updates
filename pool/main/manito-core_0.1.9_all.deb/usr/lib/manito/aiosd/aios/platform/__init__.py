"""현재 OS에 맞는 플랫폼 구현을 고른다."""
from __future__ import annotations

import sys

from .base import App, Game, GpuInfo, Platform


def get_platform() -> Platform:
    if sys.platform.startswith("linux"):
        from .linux import LinuxPlatform
        return LinuxPlatform()
    if sys.platform == "win32":
        from .windows import WindowsPlatform
        return WindowsPlatform()
    return Platform()


__all__ = ["App", "Game", "GpuInfo", "Platform", "get_platform"]
