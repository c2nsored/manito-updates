"""프로그램 관리 도구 (설치된 프로그램 보기 · 지우기 · 업데이트).

AI는 목록을 읽거나 '프로그램 관리' 창을 열어 줄 뿐이다. 실제로 지우거나 업데이트하는 것은
그 창에서 사용자가 확인 버튼을 누르고 관리자 암호를 넣어야만 일어난다 (원칙 3·4).
그래서 위험도는 read(목록) / launch(창 열기).
"""
from __future__ import annotations

from . import Tool, ToolContext, ToolResult


def _programs(ctx: ToolContext):
    return ctx.platform.list_programs()


def _match(progs, query: str, ctx: ToolContext | None = None):
    q = query.strip().lower()
    if not q:
        return []
    exact = [p for p in progs if q in (p.name.lower(), p.package.lower())]
    if exact:
        return exact
    found = [p for p in progs if q in " ".join([p.name, p.package, *p.apps]).lower()]
    if found or ctx is None or ctx.catalog is None:
        return found
    # 한국어 이름·별칭('클로드' → Claude)은 프로그램 실행용 목록(catalog)으로 찾는다
    app, _ = ctx.catalog.resolve(query)
    if app:
        return [p for p in progs if app.name in p.apps or app.name == p.name]
    return []


def list_programs(ctx: ToolContext, query: str = "") -> ToolResult:
    progs = _programs(ctx)
    if query:
        progs = _match(progs, query, ctx)
        if not progs:
            return ToolResult(True, f"'{query}'에 해당하는 설치된 프로그램이 없습니다.", [])
    lines = [f"- {p.name}" + (" (지울 수 없음: " + p.protected + ")" if p.protected else "")
             for p in progs]
    data = [{"name": p.name, "package": p.package, "kind": p.kind, "protected": p.protected,
             "size_kb": p.size_kb} for p in progs]
    return ToolResult(True, f"설치된 프로그램 {len(progs)}개:\n" + "\n".join(lines), data)


def open_program_manager(ctx: ToolContext, action: str = "", program: str = "") -> ToolResult:
    args: list[str] = []
    if action == "updates":
        args = ["--updates"]
    elif action == "remove":
        progs = _match(_programs(ctx), program, ctx)
        if not progs:
            return ToolResult(False, f"'{program}'에 해당하는 설치된 프로그램을 찾지 못했습니다.")
        if len(progs) > 1:
            lines = [f"{i+1}. {p.name}" for i, p in enumerate(progs[:10])]
            return ToolResult(True, "어느 프로그램을 지울까요?\n" + "\n".join(lines),
                              [{"name": p.name, "package": p.package} for p in progs[:10]], needs_choice=True)
        p = progs[0]
        if p.protected:
            return ToolResult(False, f"'{p.name}'은(는) {p.protected}에 필요해서 지울 수 없습니다.")
        if p.kind == "deb":
            args = ["--remove", p.package]
    try:
        how = ctx.platform.open_program_manager(args)
    except Exception as e:   # noqa: BLE001
        return ToolResult(False, f"프로그램 관리 창을 열지 못했습니다: {e}")
    if action == "remove" and args:
        msg = f"프로그램 관리 창을 열었어요. '{progs[0].name}' 제거를 확인해 주세요 (관리자 암호를 물어봐요)."
    elif action == "remove":
        msg = f"프로그램 관리 창을 열었어요. 목록에서 '{progs[0].name}'을(를) 골라 '제거'를 눌러 주세요."
    elif action == "updates":
        msg = "프로그램 관리 창의 업데이트 탭을 열었어요. 확인이 끝나면 '모두 업데이트'를 눌러 주세요."
    else:
        msg = "프로그램 관리 창을 열었어요."
    return ToolResult(True, msg, {"how": how})


TOOLS = [
    Tool(
        name="list_programs",
        description="이 컴퓨터에 설치된 프로그램 목록을 본다 (이름으로 좁히기 가능). 라이브러리 같은 부품은 빠져 있다.",
        parameters={
            "type": "object",
            "properties": {"query": {"type": "string", "description": "찾을 프로그램 이름 (비우면 전체)"}},
        },
        risk="read",
        func=list_programs,
    ),
    Tool(
        name="open_program_manager",
        description=("'프로그램 관리' 창을 연다. 프로그램을 지우거나(action=remove, program=이름) "
                     "업데이트하려면(action=updates) 이 도구를 쓴다. 실제 제거·업데이트는 사용자가 창에서 확인한다."),
        parameters={
            "type": "object",
            "properties": {
                "action": {"type": "string", "enum": ["", "remove", "updates"],
                           "description": "remove=지우기, updates=업데이트, 비우면 창만 열기"},
                "program": {"type": "string", "description": "지울 프로그램 이름 (action=remove일 때)"},
            },
        },
        risk="launch",
        func=open_program_manager,
    ),
]
