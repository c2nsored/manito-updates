"""freedesktop.org 휴지통 규격 구현 (KDE Dolphin·GNOME 파일 관리자가 쓰는 그 휴지통).

~/.local/share/Trash/files/ 에 파일을 옮기고, info/<이름>.trashinfo 에 원래 위치와 버린 시각을 적는다.
그래서 Dolphin의 휴지통에서 "되살리기"로 원래 자리에 돌려놓을 수 있다.
같은 디스크(파일시스템) 안에서만 옮긴다 — 다른 디스크의 파일은 호출한 쪽이 다른 방법을 쓴다.
OS 공통 파이썬 코드라 Windows 테스트에서도 동작을 확인할 수 있다.
"""
from __future__ import annotations

import os
import shutil
import time
import urllib.parse
from pathlib import Path


def home_trash() -> Path:
    data = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    return data / "Trash"


def same_device(a: Path, b: Path) -> bool:
    try:
        return a.stat().st_dev == b.stat().st_dev
    except OSError:
        return False


def trash_path(path: Path, trash: Path | None = None) -> Path:
    """path 를 휴지통으로 옮기고, 휴지통 안의 새 위치를 돌려준다."""
    trash = trash or home_trash()
    files, info = trash / "files", trash / "info"
    files.mkdir(parents=True, exist_ok=True)
    info.mkdir(parents=True, exist_ok=True)
    if not same_device(path, files):
        raise OSError("다른 디스크에 있는 파일이라 이 방법으로는 휴지통에 넣을 수 없습니다")
    base = path.name
    name, n = base, 1
    while True:
        try:
            # 같은 이름이 있으면 "이름.2" 처럼 바꾼다. info 파일을 먼저 만들어 이름을 '예약'한다 (규격 권장)
            fd = os.open(info / f"{name}.trashinfo", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            break
        except FileExistsError:
            n += 1
            name = f"{base}.{n}"
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write("[Trash Info]\n")
        f.write(f"Path={urllib.parse.quote(str(path.resolve()))}\n")
        f.write(f"DeletionDate={time.strftime('%Y-%m-%dT%H:%M:%S')}\n")
    dest = files / name
    try:
        os.rename(path, dest)
    except OSError:
        (info / f"{name}.trashinfo").unlink(missing_ok=True)
        raise
    return dest


def empty(trash: Path | None = None) -> int:
    trash = trash or home_trash()
    count = 0
    for sub in ("files", "info", "expunged"):
        d = trash / sub
        if not d.is_dir():
            continue
        for p in d.iterdir():
            if sub == "files":
                count += 1
            if p.is_dir() and not p.is_symlink():
                shutil.rmtree(p, ignore_errors=True)
            else:
                p.unlink(missing_ok=True)
    (trash / "directorysizes").unlink(missing_ok=True)
    return count
