"""AI OS 서비스 구성 요소를 한곳에서 조립한다."""
from __future__ import annotations

from .agent import Agent
from .ai_status import AiStatus
from .catalog import Catalog
from .config import data_dir, load_config
from .memory import Memory
from .models import ModelManager
from .platform import Platform, get_platform
from .tools import ToolContext, default_registry


class AIOS:
    def __init__(self, config: dict | None = None, platform: Platform | None = None,
                 db_path: str | None = None):
        self.config = config or load_config()
        self.platform = platform or get_platform()
        self.memory = Memory(db_path or (data_dir() / "memory.db"))
        self.catalog = Catalog(self.platform, self.config.get("aliases", {}))
        self.models = ModelManager(self.config, self.platform, self.memory)
        self.registry = default_registry()
        self.ctx = ToolContext(platform=self.platform, config=self.config, catalog=self.catalog,
                               models=self.models, memory=self.memory)
        self.status = AiStatus()
        self.agent = Agent(self.config, self.memory, self.registry, self.ctx, self.models, self.status)

    def emergency_stop(self) -> dict:
        """비상 정지: 모든 AI 모델 종료 + 대기 중인 승인 전부 취소."""
        stopped = self.models.unload_all()
        cancelled = self.memory.cancel_all_approvals()
        self.status.set("idle")
        return {"stopped_models": stopped, "cancelled_approvals": cancelled}

    def close(self) -> None:
        self.models.shutdown()
        self.memory.close()
