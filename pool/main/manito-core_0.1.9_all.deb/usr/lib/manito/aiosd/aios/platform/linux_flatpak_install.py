"""Flatpak 설치 파일(.flatpak 묶음, .flatpakref 안내 파일) 더블클릭 설치 — 판단·명령 만들기 (표준 라이브러리).

Discover를 뺀 뒤 이 파일들을 열 프로그램이 없어짐(2026-11-16 실기기: ArtCraft 런처) → 마니또 설치 창이 맡는다.
- 설치는 '나만 쓰기'(--user): 관리자 암호가 필요 없고, 묶음 파일이 저장소를 추가하려 해도 막히지 않는다.
- 실행에 필요한 공통 부품은 사용자용 Flathub에서 받는다 (없으면 등록).
- .flatpakref는 '어느 서버에서 받는지'를 설치 전에 사용자에게 보여 준다 (낯선 서버면 사용자가 판단).
화면: ui/flatpak/manito_flatpak.py
"""
from __future__ import annotations

from configparser import ConfigParser
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

FLATHUB_REPO_URL = "https://dl.flathub.org/repo/flathub.flatpakrepo"
TRUSTED_HOSTS = {"dl.flathub.org", "flathub.org"}


@dataclass
class FlatpakFile:
    path: Path
    kind: str            # bundle / ref
    name: str            # 보여 줄 이름
    app_id: str = ""
    source: str = ""     # 받아 오는 서버 주소 (ref)
    trusted: bool = True # Flathub 공식 서버인지


def parse_ref(text: str) -> dict[str, str]:
    cp = ConfigParser(interpolation=None, strict=False)
    cp.optionxform = str
    cp.read_string(text)
    return dict(cp["Flatpak Ref"]) if "Flatpak Ref" in cp else {}


def inspect(path: Path) -> FlatpakFile:
    """파일을 보고 무엇을 설치하는지 정리한다. 알 수 없는 파일이면 ValueError."""
    suffix = path.suffix.lower()
    if suffix == ".flatpakref":
        ref = parse_ref(path.read_text(encoding="utf-8", errors="replace"))
        if not ref.get("Name"):
            raise ValueError("Flatpak 안내 파일이 아니거나 내용이 비어 있어요")
        url = ref.get("Url", "")
        host = urlparse(url).hostname or ""
        return FlatpakFile(path=path, kind="ref", name=ref.get("Title") or ref["Name"], app_id=ref["Name"],
                           source=url, trusted=host in TRUSTED_HOSTS)
    if suffix == ".flatpak":
        stem = path.stem
        # 'artcraft-launcher-0.19.2-linux-x86_64' → 'artcraft-launcher'
        parts = [p for p in stem.replace("_", "-").split("-")
                 if p and not p[0].isdigit() and p.lower() not in ("linux", "x86", "64", "amd64", "x86-64")]
        name = " ".join(parts) or stem
        return FlatpakFile(path=path, kind="bundle", name=name, source="(파일 안에 들어 있음)", trusted=True)
    raise ValueError("Flatpak 설치 파일(.flatpak, .flatpakref)이 아니에요")


def flathub_remote_command() -> list[str]:
    return ["flatpak", "remote-add", "--user", "--if-not-exists", "flathub", FLATHUB_REPO_URL]


def install_command(f: FlatpakFile) -> list[str]:
    how = "--bundle" if f.kind == "bundle" else "--from"
    return ["flatpak", "install", "--user", "--noninteractive", "-y", how, str(f.path)]


def new_apps(before: set[str], after: set[str]) -> list[str]:
    return sorted(after - before)
