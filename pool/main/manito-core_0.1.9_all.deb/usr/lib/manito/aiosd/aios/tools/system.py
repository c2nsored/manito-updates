"""시스템 상태 확인 도구."""
from __future__ import annotations

from . import Tool, ToolContext, ToolResult


def collect_status(ctx: ToolContext) -> dict:
    p = ctx.platform
    mem = p.memory_mb()
    st = {
        "platform": p.name,
        "cpu_percent": p.cpu_percent(),
        "ram_total_mb": mem[0] if mem else None,
        "ram_used_mb": mem[1] if mem else None,
        "gpus": [
            {"name": g.name, "vram_total_mb": g.vram_total_mb, "vram_used_mb": g.vram_used_mb,
             "vram_free_mb": g.vram_free_mb}
            for g in p.gpus()
        ],
    }
    if ctx.models is not None:
        st["models"] = ctx.models.status()
        st["game_mode"] = ctx.models.game_mode
    return st


def system_status(ctx: ToolContext) -> ToolResult:
    st = collect_status(ctx)
    lines = []
    if st["cpu_percent"] is not None:
        lines.append(f"CPU 사용률: {st['cpu_percent']}%")
    if st["ram_total_mb"]:
        lines.append(f"RAM: {st['ram_used_mb'] / 1024:.1f} / {st['ram_total_mb'] / 1024:.1f} GB 사용 중")
    for g in st["gpus"]:
        if g["vram_total_mb"]:
            lines.append(f"{g['name']} VRAM: {g['vram_used_mb'] / 1024:.1f} / {g['vram_total_mb'] / 1024:.1f} GB 사용 중")
    if not st["gpus"]:
        lines.append("GPU VRAM: 이 환경에서는 측정할 수 없습니다 (Linux + AMD GPU에서 지원)")
    for m in st.get("models", []):
        state = "실행 중" if m["running"] else "꺼짐"
        lines.append(f"AI 모델 {m['name']}: {state}" + (" (GPU)" if m["uses_gpu"] else " (CPU)"))
    if st.get("game_mode"):
        lines.append("게임 모드: 켜짐 (GPU AI 모델 사용 중지)")
    return ToolResult(True, "\n".join(lines), st)


TOOLS = [
    Tool(
        name="system_status",
        description="CPU, RAM, GPU VRAM 사용량과 AI 모델 상태를 확인한다.",
        parameters={"type": "object", "properties": {}},
        risk="read",
        func=system_status,
    ),
]
