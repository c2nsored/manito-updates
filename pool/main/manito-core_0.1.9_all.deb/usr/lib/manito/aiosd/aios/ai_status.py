"""AI가 지금 무엇을 하는지 알려 주는 상태 (화면의 AI 오브가 읽어 간다).

상태: idle(대기) / thinking(생각 중) / working(작업 중) / complete(완료) / error(오류) / disabled(꺼짐)
complete·error 는 잠깐만 유지된 뒤 자동으로 idle 로 돌아간다.
"""
from __future__ import annotations

import threading
import time

STATES = ("idle", "thinking", "working", "complete", "error", "disabled")

# 잠깐만 보여 주는 상태의 기본 유지 시간(초)
DEFAULT_HOLD = {"complete": 2.0, "error": 5.0}


class AiStatus:
    def __init__(self, clock=time.monotonic):
        self._clock = clock
        self._lock = threading.Lock()
        self._state = "idle"
        self._until = 0.0
        self._after = "idle"
        self._changed = clock()

    def set(self, state: str, hold: float | None = None, after: str = "idle") -> None:
        if state not in STATES:
            raise ValueError(f"알 수 없는 상태: {state}")
        if after not in STATES:
            raise ValueError(f"알 수 없는 상태: {after}")
        if hold is None:
            hold = DEFAULT_HOLD.get(state, 0.0)
        with self._lock:
            self._state = state
            self._until = self._clock() + hold if hold > 0 else 0.0
            self._after = after
            self._changed = self._clock()

    def get(self) -> str:
        with self._lock:
            if self._until and self._clock() >= self._until:
                self._state, self._until = self._after, 0.0
                self._changed = self._clock()
            return self._state

    def snapshot(self) -> dict:
        state = self.get()
        with self._lock:
            return {"state": state, "since": round(self._clock() - self._changed, 1)}
