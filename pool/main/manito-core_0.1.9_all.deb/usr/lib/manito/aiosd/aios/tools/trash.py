"""파일 지우기 도구.

사용자 결정(2026-11-14): 휴지통으로 옮기기는 묻지 않고 처리, 영구 삭제만 확인.
- move_to_trash      : 휴지통으로 (되돌릴 수 있음) — 위험도 trash, 묻지 않음
- delete_permanently : 완전히 지우기 (되돌릴 수 없음) — 위험도 write, 사용자 허락 필요
- empty_trash        : 휴지통 비우기 (되돌릴 수 없음) — 위험도 write, 사용자 허락 필요
어느 경우든 파일 검색이 허용된 폴더(기본: 홈) 안에서만, 그 폴더 자체·숨김 파일·휴지통 안은 거부한다.
"""
from __future__ import annotations

import shutil
from pathlib import Path

from ..config import expand
from . import Tool, ToolContext, ToolResult
from .files import _allowed_roots

MAX_ITEMS = 50


def _check(ctx: ToolContext, raw: str) -> Path:
    p = Path(expand(str(raw).strip()))
    if not p.is_absolute():
        raise ValueError(f"'{raw}': 전체 경로가 필요합니다 (먼저 파일 찾기로 위치를 확인하세요)")
    if not (p.exists() or p.is_symlink()):
        raise ValueError(f"'{raw}' 이(가) 없습니다")
    real = p.resolve() if not p.is_symlink() else p.parent.resolve() / p.name
    roots = _allowed_roots(ctx)
    if real in roots:
        raise ValueError(f"'{real}'는 최상위 폴더라 지울 수 없습니다")
    if not any(real.is_relative_to(r) for r in roots):
        raise ValueError(f"'{real}'는 지우기가 허용된 폴더 밖입니다")
    rel_parts = next(real.relative_to(r).parts for r in roots if real.is_relative_to(r))
    if any(part.startswith(".") for part in rel_parts):
        raise ValueError(f"'{real}'는 숨김 파일·설정 폴더라 지우지 않습니다")
    tdir = ctx.platform.trash_dir()
    if tdir and real.is_relative_to(tdir.resolve()):
        raise ValueError(f"'{real}'는 이미 휴지통 안에 있습니다")
    return p


def _each(ctx: ToolContext, paths, action) -> ToolResult:
    if isinstance(paths, str):
        paths = [paths]
    paths = [x for x in (paths or []) if str(x).strip()]
    if not paths:
        return ToolResult(False, "지울 파일 경로가 없습니다.")
    if len(paths) > MAX_ITEMS:
        return ToolResult(False, f"한 번에 {MAX_ITEMS}개까지만 지울 수 있습니다 ({len(paths)}개 요청).")
    done, failed = [], []
    for raw in paths:
        try:
            p = _check(ctx, raw)
            action(p)
            done.append(str(p))
        except Exception as e:
            failed.append(f"{raw}: {e}")
    return done, failed


def move_to_trash(ctx: ToolContext, paths=None) -> ToolResult:
    res = _each(ctx, paths, lambda p: ctx.platform.trash(p))
    if isinstance(res, ToolResult):
        return res
    done, failed = res
    lines = [f"휴지통으로 옮김 {len(done)}개 (휴지통에서 되살릴 수 있어요)"] + [f"- {d}" for d in done]
    if failed:
        lines += ["옮기지 못함:"] + [f"- {f}" for f in failed]
    return ToolResult(bool(done) and not failed, "\n".join(lines), {"trashed": done, "failed": failed})


def _remove(p: Path) -> None:
    if p.is_dir() and not p.is_symlink():
        shutil.rmtree(p)
    else:
        p.unlink()


def delete_permanently(ctx: ToolContext, paths=None) -> ToolResult:
    res = _each(ctx, paths, _remove)
    if isinstance(res, ToolResult):
        return res
    done, failed = res
    lines = [f"완전히 지움 {len(done)}개 (되돌릴 수 없음)"] + [f"- {d}" for d in done]
    if failed:
        lines += ["지우지 못함:"] + [f"- {f}" for f in failed]
    return ToolResult(bool(done) and not failed, "\n".join(lines), {"deleted": done, "failed": failed})


def empty_trash(ctx: ToolContext) -> ToolResult:
    try:
        n = ctx.platform.empty_trash()
    except Exception as e:
        return ToolResult(False, f"휴지통을 비우지 못했습니다: {e}")
    return ToolResult(True, "휴지통을 비웠습니다." + (f" ({n}개)" if n >= 0 else ""), {"count": n})


_PATHS = {"paths": {"type": "array", "items": {"type": "string"}, "description": "지울 파일·폴더의 전체 경로 목록"}}

TOOLS = [
    Tool("move_to_trash", "파일·폴더를 휴지통으로 옮긴다 (나중에 되살릴 수 있음). 사용자가 '지워줘', '버려줘'라고 하면 이것을 쓴다.",
         {"type": "object", "properties": dict(_PATHS), "required": ["paths"]}, "trash", move_to_trash),
    Tool("delete_permanently", "파일·폴더를 되살릴 수 없게 완전히 지운다. 사용자가 '영구 삭제', '완전히 지워'라고 분명히 말할 때만 쓴다 (허락 필요).",
         {"type": "object", "properties": dict(_PATHS), "required": ["paths"]}, "write", delete_permanently),
    Tool("empty_trash", "휴지통을 비운다 (되살릴 수 없음, 허락 필요).",
         {"type": "object", "properties": {}}, "write", empty_trash),
]
