"""윈도우 프로그램(.exe) — 사용자가 Wine을 몰라도 되게 마니또가 알아서 관리한다.

- 프로그램마다 따로 공간(Wine prefix)을 만든다: ~/.local/share/manito/windows/<이름>/
  → 하나가 꼬여도 다른 프로그램은 멀쩡, 지울 때는 그 공간만 지우면 끝
- 한국어 표시: 한국어 로케일 + 윈도우 기본 글꼴(맑은 고딕·굴림 등)을 Noto Sans CJK KR로 대신
- 한/영 입력: fcitx5 (XIM)
- 설치 프로그램이 만든 시작 메뉴 바로가기는 Wine이 자동으로 만든다(~/.local/share/applications/wine)

판단·경로·기록은 표준 라이브러리만 쓰고 테스트가 있다. 화면은 ui/winapps/manito_exe.py.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import time
from dataclasses import asdict, dataclass
from pathlib import Path

from .base import Program

# 설치 파일 이름 → 알아보기 쉬운 이름 (소문자 비교)
KNOWN = {"kakaotalk": "카카오톡", "line": "LINE", "lineinst": "LINE", "linesetup": "LINE"}
_NOISE = re.compile(r"(?i)[ _.\-]*(setup|installer|install|inst|x64|x86|win64|win32|win|amd64|full|latest|"
                    r"v?\d+(?:[._]\d+)*)$")

# 프로그램별로 미리 넣어야 하는 진짜 윈도우 부품 (winetricks 이름) — 실제로 효과를 확인한 것만 적는다
FIXES: dict[str, list[str]] = {}

# 지금 리눅스(Wine)에서 안 되는 것으로 확인된 프로그램 → 설치 전에 미리 알려 준다 (시도는 막지 않음)
#   line: 최신 LINE은 윈도우 시스템 부품(gdiplus.dll 등)의 Microsoft 서명을 검사함. Wine 부품은 서명이 없어
#         "Security verification failed … NO_SIGNATURE"로 설치 거부. 진짜 gdiplus를 넣어도 같음
#         (2026-11-15 실기기 확인, Wine 버그 59813·59275 — 쉬운 해결책 없음)
KNOWN_BROKEN = {"line": "LINE은 최근 버전부터 윈도우 시스템 부품의 서명을 검사해서, 지금은 리눅스에서 설치되지 않아요."}


def broken_reason(slug: str) -> str:
    return KNOWN_BROKEN.get(re.sub(r"\d+$", "", slug).lower(), "")


def fixes_for(slug: str) -> list[str]:
    base = re.sub(r"\d+$", "", slug).lower()     # Line2 같은 두 번째 설치도 같은 처방
    return list(FIXES.get(base, []))


def winetricks_command(verbs: list[str]) -> list[str]:
    return ["winetricks", "-q", "--unattended", *verbs]


# 윈도우 프로그램이 찾는 글꼴 → 마니또에 있는 한국어 글꼴
FONT_FOR = "Noto Sans CJK KR"
FONT_NAMES = ["Malgun Gothic", "맑은 고딕", "Gulim", "굴림", "GulimChe", "굴림체", "Dotum", "돋움", "DotumChe",
              "Batang", "바탕", "Gungsuh", "궁서", "MS Shell Dlg", "MS Shell Dlg 2", "Tahoma", "Segoe UI",
              "Microsoft Sans Serif", "MS UI Gothic", "Meiryo", "Yu Gothic", "Arial"]

# Wine이 처음 준비될 때 묻는 추가 부품(.NET 대체 Mono, IE 대체 Gecko) 다운로드 창을 띄우지 않게
QUIET_BOOT_OVERRIDES = "mscoree=;mshtml="


@dataclass
class WinApp:
    slug: str            # 공간 이름 (폴더 이름)
    name: str            # 보여 줄 이름
    installer: str = ""  # 설치에 쓴 파일 이름
    installed: float = 0.0


def root() -> Path:
    return Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local/share")) / "manito" / "windows"


def apps_dir() -> Path:
    return Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local/share")) / "applications"


def menu_dir() -> Path:
    return apps_dir() / "wine"


def menus_merged_dir() -> Path:
    return Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "menus" / "applications-merged"


# 시작 메뉴 분류 (없으면 '유틸리티')
CATEGORIES = {"kakaotalk": "Network;InstantMessaging;", "line": "Network;InstantMessaging;"}


def names_from_installer(filename: str) -> tuple[str, str]:
    """'KakaoTalk_Setup.exe' → ('KakaoTalk', '카카오톡'). 폴더 이름에 쓸 수 없는 글자는 뺀다."""
    stem = Path(filename).stem
    prev = None
    while prev != stem:
        prev = stem
        stem = _NOISE.sub("", stem).strip(" _.-")
    stem = stem or Path(filename).stem
    slug = re.sub(r"[^A-Za-z0-9가-힣]+", "", stem) or "WindowsApp"
    return slug, KNOWN.get(slug.lower(), stem)


def unique_slug(slug: str, existing: set[str]) -> str:
    if slug not in existing:
        return slug
    n = 2
    while f"{slug}{n}" in existing:
        n += 1
    return f"{slug}{n}"


def font_reg() -> str:
    """regedit용 파일 내용: 윈도우 글꼴 이름을 한국어 글꼴로 대신."""
    lines = ["REGEDIT4", "", r"[HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion\FontSubstitutes]"]
    lines += [f'"{n}"="{FONT_FOR}"' for n in FONT_NAMES]
    lines += ["", r"[HKEY_CURRENT_USER\Software\Wine\Fonts\Replacements]"]
    lines += [f'"{n}"="{FONT_FOR}"' for n in FONT_NAMES]
    return "\r\n".join(lines) + "\r\n"


def wine_env(prefix: Path, base: dict | None = None, quiet_boot: bool = False) -> dict:
    env = dict(base if base is not None else os.environ)
    env.update({"WINEPREFIX": str(prefix), "WINEDEBUG": "-all", "LANG": "ko_KR.UTF-8", "LC_ALL": "ko_KR.UTF-8",
                "XMODIFIERS": "@im=fcitx"})
    if quiet_boot:
        env["WINEDLLOVERRIDES"] = QUIET_BOOT_OVERRIDES
    # Ubuntu는 wineserver를 PATH 밖에 둔다 → winetricks가 못 찾아 아무것도 못 함 (2026-11-15 실기기)
    for ws in ("/usr/lib/x86_64-linux-gnu/wine/wineserver", "/usr/lib/wine/wineserver"):
        if "WINESERVER" not in env and Path(ws).exists():
            env["WINESERVER"] = ws
    return env


def install_command(installer: Path) -> list[str]:
    if installer.suffix.lower() == ".msi":
        return ["wine", "msiexec", "/i", str(installer)]
    return ["wine", str(installer)]


def prefix_of(path: Path) -> Path | None:
    """이 파일이 마니또가 만든 어느 공간 안에 있으면 그 공간."""
    try:
        rel = path.resolve().relative_to(root().resolve())
    except ValueError:
        return None
    return root() / rel.parts[0] if rel.parts else None


# ── 기록 (어떤 공간이 어떤 프로그램인지) ──
def _registry_file() -> Path:
    return root() / "apps.json"


def load_apps() -> list[WinApp]:
    try:
        data = json.loads(_registry_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    out = []
    for d in data if isinstance(data, list) else []:
        try:
            out.append(WinApp(**d))
        except TypeError:
            continue
    return out


def save_apps(apps: list[WinApp]) -> None:
    root().mkdir(parents=True, exist_ok=True)
    _registry_file().write_text(json.dumps([asdict(a) for a in apps], ensure_ascii=False, indent=1), encoding="utf-8")


def add_app(app: WinApp) -> None:
    apps = [a for a in load_apps() if a.slug != app.slug]
    apps.append(app)
    save_apps(apps)


def new_app(installer_name: str) -> WinApp:
    slug, name = names_from_installer(installer_name)
    existing = {a.slug for a in load_apps()} | ({p.name for p in root().iterdir()} if root().is_dir() else set())
    return WinApp(slug=unique_slug(slug, existing), name=name, installer=installer_name, installed=time.time())


# ── 시작 메뉴 바로가기 (Wine이 만든 것) ──
def desktop_folder() -> Path:
    """바탕화면 폴더 (설치 프로그램이 바탕화면 바로가기를 만들기도 함)."""
    try:
        for line in (Path.home() / ".config/user-dirs.dirs").read_text(encoding="utf-8").splitlines():
            if line.startswith("XDG_DESKTOP_DIR="):
                return Path(line.split("=", 1)[1].strip('"').replace("$HOME", str(Path.home())))
    except OSError:
        pass
    return Path.home() / "Desktop"


def shortcuts(prefix: Path, mdir: Path | None = None, desktop: Path | None = None,
              include_desktop: bool = False) -> list[Path]:
    """이 공간을 쓰는 바로가기(.desktop). Wine은 Exec 줄에 WINEPREFIX="…"를 적어 둔다."""
    mdir = mdir or menu_dir()
    key = f'WINEPREFIX="{prefix}"'
    files = sorted(mdir.rglob("*.desktop")) if mdir.is_dir() else []
    if mdir == menu_dir() and apps_dir().is_dir():
        files += sorted(apps_dir().glob("manito-win-*.desktop"))     # adopt_shortcuts로 옮긴 것
    if include_desktop:
        d = desktop or desktop_folder()
        files += sorted(d.glob("*.desktop")) if d.is_dir() else []
    out = []
    for f in files:
        try:
            text = f.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if key in text and "Uninstall" not in f.name and "제거" not in f.name:
            out.append(f)
    return out


def adopt_shortcuts(slug: str) -> list[Path]:
    """Wine이 만든 바로가기('Wine > Programs' 하위 폴더)를 일반 프로그램처럼 시작 메뉴 바로 아래로 옮긴다.
    사용자에게 'Wine'이라는 말이 보이지 않게 (2026-11-15 실기기: 카카오톡이 모든 앱에서 안 보임)."""
    prefix = root() / slug
    cat = CATEGORIES.get(re.sub(r"\d+$", "", slug).lower(), "Utility;")
    out = []
    wine_links = [f for f in shortcuts(prefix) if f.is_relative_to(menu_dir())] if menu_dir().is_dir() else []
    for i, f in enumerate(wine_links):
        lines = [l for l in f.read_text(encoding="utf-8", errors="replace").splitlines()
                 if not l.startswith(("Categories=", "X-Manito-"))]
        idx = lines.index("[Desktop Entry]") + 1 if "[Desktop Entry]" in lines else 0
        lines[idx:idx] = [f"Categories={cat}", f"X-Manito-WindowsApp={slug}"]
        new = apps_dir() / f"manito-win-{slug}-{i}.desktop"
        new.write_text("\n".join(lines) + "\n", encoding="utf-8")
        f.unlink()
        out.append(new)
    _tidy_wine_menus()
    return out


def _tidy_wine_menus() -> None:
    """Wine 바로가기가 하나도 안 남으면 빈 'Wine' 메뉴 폴더·메뉴 정의·폴더 설명 파일을 지운다."""
    mdir = menu_dir()
    if mdir.is_dir():
        if any(mdir.rglob("*.desktop")):
            return
        shutil.rmtree(mdir, ignore_errors=True)
    merged = menus_merged_dir()
    for m in merged.glob("wine-*.menu") if merged.is_dir() else []:
        m.unlink(missing_ok=True)
    dirs = apps_dir().parent / "desktop-directories"
    for d in dirs.glob("wine-*.directory") if dirs.is_dir() else []:
        d.unlink(missing_ok=True)


def desktop_field(path: Path, key: str) -> str:
    try:
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            if line.startswith(key + "="):
                return line.split("=", 1)[1]
    except OSError:
        pass
    return ""


def dir_size_kb(path: Path) -> int:
    total = 0
    for dirpath, _dirs, files in os.walk(path):
        for f in files:
            try:
                total += os.lstat(os.path.join(dirpath, f)).st_size
            except OSError:
                continue
    return total // 1024


def list_windows_programs(with_size: bool = True) -> list[Program]:
    progs = []
    for a in load_apps():
        prefix = root() / a.slug
        if not prefix.is_dir():
            continue
        links = shortcuts(prefix)
        icon = desktop_field(links[0], "Icon") if links else ""
        progs.append(Program(id=f"windows:{a.slug}", name=a.name, kind="windows", package=a.slug, icon=icon,
                             comment="윈도우용 프로그램", size_kb=dir_size_kb(prefix) if with_size else None,
                             installed=a.installed or None, apps=[desktop_field(l, "Name") for l in links],
                             desktop_ids=[l.name for l in links if l.parent == apps_dir()]))
    return progs


def remove_app(slug: str) -> None:
    """프로그램 공간·바로가기·기록을 지운다 (되돌릴 수 없음 — 화면에서 확인을 받은 뒤 호출)."""
    if not re.fullmatch(r"[A-Za-z0-9가-힣]+", slug):
        raise ValueError("잘못된 프로그램 이름")
    prefix = root() / slug
    for f in shortcuts(prefix, include_desktop=True):
        f.unlink(missing_ok=True)
    if prefix.is_dir():
        shutil.rmtree(prefix)
    save_apps([a for a in load_apps() if a.slug != slug])
    _tidy_wine_menus()
