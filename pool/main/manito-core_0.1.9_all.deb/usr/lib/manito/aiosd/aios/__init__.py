"""AI Native OS — 핵심 서비스(aiosd)."""
__version__ = "0.1.0"
