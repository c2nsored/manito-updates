"""프로그램 관리(목록·제거 계획) — Linux(Debian/Ubuntu 패키지) 구현.

윈도우의 "프로그램 추가/제거"처럼, 깔린 방식과 상관없이 '사용자가 쓰는 프로그램'만 보여 준다.
- 패키지(deb): 프로그램 목록(.desktop)에 이름이 있는 것만 → 라이브러리 수천 개는 숨김
              (Discover와 달리 앱 스토어 정보(AppStream)가 없어도 보임: Claude 앱 등)
- Flatpak(Flathub 앱): `flatpak list --app` (Bambu Studio 등)
- 윈도우 프로그램: 마니또가 .exe를 설치할 때 만든 전용 공간 (linux_winapps.py, 카카오톡 등)
- 직접 받은 파일: ~/.local/bin 안의 실행 파일 (rclone 등) → 휴지통으로 (되살릴 수 있음)

이 파일은 표준 라이브러리만 쓴다 (설계 원칙 8). 실제 제거·업데이트는 화면 프로그램이
PackageKit(관리자 암호 창)으로 한다 — 여기서는 '무엇이 지워지는지' 계산과 안전 판단만 (원칙 2).
"""
from __future__ import annotations

import os
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path

from .base import Program
from .linux import application_dirs, parse_desktop_file

DPKG_STATUS = Path("/var/lib/dpkg/status")
DPKG_INFO = Path("/var/lib/dpkg/info")

# OS가 돌아가는 데 꼭 필요해서 지우지 못하게 막는 패키지 (이것을 함께 지우게 되는 제거도 막는다)
PROTECTED = {
    "manito-core": "마니또 AI 서비스",
    "plasma-workspace": "바탕화면(KDE)", "plasma-desktop": "바탕화면(KDE)",
    "kwin-wayland": "화면 관리자", "kwin-x11": "화면 관리자", "sddm": "로그인 화면",
    "systemsettings": "시스템 설정", "dolphin": "파일 관리자", "konsole": "터미널",
    "network-manager": "인터넷 연결", "plasma-nm": "인터넷 연결",
    "fcitx5": "한글 입력", "fcitx5-hangul": "한글 입력", "im-config": "한글 입력",
    "systemd": "시스템", "sudo": "관리자 권한", "apt": "프로그램 설치 도구", "dpkg": "프로그램 설치 도구",
    "packagekit": "프로그램 설치 도구", "polkitd": "관리자 암호 창", "policykit-1": "관리자 암호 창",
    "grub-efi-amd64-signed": "부팅", "shim-signed": "부팅", "linux-generic": "리눅스 커널",
    "pipewire": "소리", "wireplumber": "소리",
    "tailscale": "원격 접속", "remotepc": "원격 접속",
}
PROTECTED_PREFIXES = ("linux-image-", "linux-modules-", "libc6", "manito-")

# 바로가기 이름이 패키지 전체를 잘 나타내지 못하는 경우의 표시 이름
NAME_OVERRIDES = {"plasma-desktop": "KDE 바탕화면", "mozc-utils-gui": "일본어 입력(Mozc) 설정"}

# 프로그램 목록(.desktop)에는 없지만 사용자가 알아야 하는 '뒤에서 도는 프로그램'
BACKGROUND_PROGRAMS = {
    "tailscale": ("Tailscale", "원격 접속용 연결망 (뒤에서 동작)"),
    "remotepc": ("RemotePC", "원격 화면 접속 (뒤에서 동작)"),
}


@dataclass
class PkgInfo:
    version: str = ""
    size_kb: int | None = None
    priority: str = ""
    essential: bool = False


@dataclass
class RemovalPlan:
    target: str
    packages: list[str] = field(default_factory=list)   # 실제로 함께 지워지는 패키지
    blocked: str = ""                                      # 비어 있지 않으면 제거 금지 (이유)

    @property
    def ok(self) -> bool:
        return not self.blocked and bool(self.packages)


# ── dpkg 기록 읽기 (관리자 권한 불필요) ──
def parse_dpkg_status(text: str) -> dict[str, PkgInfo]:
    """dpkg status 파일 → 설치된 패키지 정보."""
    out: dict[str, PkgInfo] = {}
    for block in text.split("\n\n"):
        fields: dict[str, str] = {}
        for line in block.splitlines():
            if line[:1] in (" ", "\t") or ":" not in line:
                continue
            k, v = line.split(":", 1)
            fields[k] = v.strip()
        name = fields.get("Package")
        if not name or not fields.get("Status", "").endswith(" installed"):
            continue
        size = fields.get("Installed-Size", "")
        out[name] = PkgInfo(version=fields.get("Version", ""),
                            size_kb=int(size) if size.isdigit() else None,
                            priority=fields.get("Priority", ""),
                            essential=fields.get("Essential", "").lower() == "yes")
    return out


def dpkg_owners(info_dir: Path, paths: set[str]) -> dict[str, str]:
    """파일 경로 → 그 파일을 설치한 패키지 이름 (dpkg/info/*.list 를 읽음)."""
    owners: dict[str, str] = {}
    if not paths or not info_dir.is_dir():
        return owners
    for lst in info_dir.glob("*.list"):
        pkg = lst.stem.split(":", 1)[0]
        try:
            with open(lst, encoding="utf-8", errors="replace") as f:
                for line in f:
                    p = line.rstrip("\n")
                    if p in paths and p not in owners:
                        owners[p] = pkg
        except OSError:
            continue
    return owners


def parse_dpkg_log(text: str) -> dict[str, float]:
    """dpkg.log → 패키지를 '처음 설치한' 시각 (업데이트·재설치 시각이 아니라)."""
    out: dict[str, float] = {}
    for line in text.splitlines():
        parts = line.split()
        if len(parts) >= 5 and parts[2] == "install" and parts[4] == "<none>":
            try:
                t = time.mktime(time.strptime(f"{parts[0]} {parts[1]}", "%Y-%m-%d %H:%M:%S"))
            except ValueError:
                continue
            name = parts[3].split(":", 1)[0]
            out[name] = t      # 지웠다가 다시 깔면 마지막 설치 시각
    return out


def read_install_times(log_dir: Path = Path("/var/log")) -> dict[str, float]:
    import gzip
    files = sorted(log_dir.glob("dpkg.log*"), key=lambda p: p.stat().st_mtime) if log_dir.is_dir() else []
    out: dict[str, float] = {}
    for f in files:           # 오래된 기록부터 읽어 새 기록이 덮어쓰게
        try:
            raw = gzip.open(f, "rt", encoding="utf-8", errors="replace").read() if f.suffix == ".gz" \
                else f.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        out.update(parse_dpkg_log(raw))
    return out


def protect_reason(pkg: str, info: PkgInfo | None = None) -> str:
    if pkg in PROTECTED:
        return PROTECTED[pkg]
    if pkg.startswith(PROTECTED_PREFIXES):
        return "시스템 필수 부품"
    if info and (info.essential or info.priority in ("required", "important")):
        return "시스템 필수 부품"
    return ""


def parse_apt_simulation(text: str) -> list[str]:
    """`apt-get -s remove X` 출력 → 함께 지워지는 패키지 이름들 ('Remv 이름 [버전]' 줄)."""
    out = []
    for line in text.splitlines():
        if line.startswith("Remv "):
            name = line.split()[1].split(":", 1)[0]
            if name not in out:
                out.append(name)
    return out


def check_plan(target: str, removed: list[str], status: dict[str, PkgInfo]) -> RemovalPlan:
    plan = RemovalPlan(target=target, packages=removed)
    if not removed:
        plan.blocked = "지울 것이 없습니다 (이미 지워졌거나 설치되어 있지 않음)"
        return plan
    for p in removed:
        why = protect_reason(p, status.get(p))
        if why:
            plan.blocked = (f"'{p}'({why})까지 함께 지워지게 되어 막았습니다"
                            if p != target else f"{why}에 필요한 프로그램이라 지울 수 없습니다")
            break
    return plan


def _local_bin() -> Path:
    return Path.home() / ".local" / "bin"


def list_manual_files(bin_dir: Path) -> list[Program]:
    """직접 받은 실행 파일 (패키지 관리자가 모르는 것)."""
    out = []
    if not bin_dir.is_dir():
        return out
    for f in sorted(bin_dir.iterdir()):
        if f.name.startswith(".") or not f.is_file() or not os.access(f, os.X_OK):
            continue
        try:
            st = f.stat()
        except OSError:
            continue
        out.append(Program(id=f"file:{f}", name=f.name, kind="file", package=str(f),
                           comment="직접 받아 넣은 프로그램 파일", size_kb=st.st_size // 1024,
                           installed=st.st_mtime))
    return out


def build_program_list(desktop_dirs: list[Path], status: dict[str, PkgInfo], info_dir: Path,
                       bin_dir: Path | None = None, install_times: dict[str, float] | None = None) -> list[Program]:
    entries = []   # (desktop 파일, App, 아이콘, 설명)
    seen: set[str] = set()
    for d in desktop_dirs:
        if not d.is_dir():
            continue
        for f in sorted(d.rglob("*.desktop")):
            if f.name in seen:
                continue
            seen.add(f.name)
            app = parse_desktop_file(f)
            if not app:
                continue
            icon, comment = _desktop_extra(f)
            entries.append((f, app, icon, comment))
    owners = dpkg_owners(info_dir, {str(f) for f, *_ in entries})
    by_pkg: dict[str, Program] = {}
    for f, app, icon, comment in entries:
        pkg = owners.get(str(f))
        if not pkg or pkg not in status:
            continue   # 패키지가 모르는 바로가기 (사용자가 만든 것 등)는 목록에서 뺀다
        if pkg in by_pkg:
            prog = by_pkg[pkg]
            prog.apps.append(app.name)
            prog.desktop_ids.append(f.name)
            # 대표 이름: 바로가기 파일 이름이 패키지 이름으로 끝나는 것 (예: org.kde.dolphin → dolphin)
            if f.stem.lower().endswith(pkg.lower()) and not prog.id.endswith("#main"):
                prog.name, prog.icon, prog.comment = app.name, icon, comment
                prog.id += "#main"
            continue
        info = status[pkg]
        mtime = (install_times or {}).get(pkg) or _list_mtime(info_dir, pkg)
        main = "#main" if f.stem.lower().endswith(pkg.lower()) else ""
        by_pkg[pkg] = Program(id=f"deb:{pkg}{main}", name=app.name, kind="deb", package=pkg,
                              icon=icon, comment=comment, size_kb=info.size_kb, installed=mtime,
                              version=info.version, protected=protect_reason(pkg, info),
                              apps=[app.name], desktop_ids=[f.name])
    for pkg, (name, comment) in BACKGROUND_PROGRAMS.items():
        if pkg in status and pkg not in by_pkg:
            info = status[pkg]
            by_pkg[pkg] = Program(id=f"deb:{pkg}", name=name, kind="deb", package=pkg, comment=comment,
                                  size_kb=info.size_kb, installed=_list_mtime(info_dir, pkg),
                                  version=info.version, protected=protect_reason(pkg, info))
    progs = list(by_pkg.values())
    for p in progs:
        p.id = p.id.removesuffix("#main")
        p.name = NAME_OVERRIDES.get(p.package, p.name)
    if bin_dir is not None:
        progs += list_manual_files(bin_dir)
    return sorted(progs, key=lambda p: p.name.lower())


def _list_mtime(info_dir: Path, pkg: str) -> float | None:
    for cand in (info_dir / f"{pkg}.list", *info_dir.glob(f"{pkg}:*.list")):
        try:
            return cand.stat().st_mtime
        except OSError:
            continue
    return None


def _desktop_extra(path: Path) -> tuple[str, str]:
    icon = comment = ""
    try:
        in_entry = False
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            s = line.strip()
            if s.startswith("["):
                in_entry = s == "[Desktop Entry]"
                continue
            if not in_entry or "=" not in s:
                continue
            k, v = s.split("=", 1)
            if k == "Icon":
                icon = v
            elif k == "Comment[ko]" or (k == "Comment" and not comment):
                comment = v
    except OSError:
        pass
    return icon, comment


# ── 실제 컴퓨터에서 쓰는 진입점 ──
def read_status() -> dict[str, PkgInfo]:
    try:
        return parse_dpkg_status(DPKG_STATUS.read_text(encoding="utf-8", errors="replace"))
    except OSError:
        return {}


def list_programs() -> list[Program]:
    progs = build_program_list(application_dirs(), read_status(), DPKG_INFO, _local_bin(), read_install_times())
    progs += flatpak_programs()
    from .linux_winapps import list_windows_programs
    progs += list_windows_programs()
    return sorted(progs, key=lambda p: p.name.lower())


# ── Flatpak (Flathub 앱) ──
FLATPAK_DIRS = {"system": Path("/var/lib/flatpak"), "user": Path.home() / ".local/share/flatpak"}
_UNITS = {"b": 1 / 1024, "bytes": 1 / 1024, "kb": 1, "kib": 1, "mb": 1024, "mib": 1024,
          "gb": 1024 * 1024, "gib": 1024 * 1024, "tb": 1024 ** 3}


def parse_size_kb(text: str) -> int | None:
    """'1.2 GB', '512 MB', '300 kB', '1,5 GB' → KB."""
    parts = text.replace("\xa0", " ").strip().split()
    if len(parts) != 2:
        return None
    try:
        num = float(parts[0].replace(",", "."))
    except ValueError:
        return None
    unit = _UNITS.get(parts[1].lower())
    return int(num * unit) if unit else None


def parse_flatpak_list(text: str) -> list[Program]:
    """`flatpak list --app --columns=application,name,version,size,installation` (탭 구분) → 목록."""
    out = []
    for line in text.splitlines():
        cols = line.split("\t")
        if len(cols) < 5 or not cols[0].strip():
            continue
        app, name, version, size, scope = (c.strip() for c in cols[:5])
        out.append(Program(id=f"flatpak:{scope}:{app}", name=name or app, kind="flatpak", package=app,
                           icon=app, comment="Flathub 앱", size_kb=parse_size_kb(size), version=version,
                           scope=scope if scope in FLATPAK_DIRS else "system", desktop_ids=[f"{app}.desktop"]))
    return out


def parse_flatpak_updates(text: str) -> list[tuple[str, str, str]]:
    """`flatpak remote-ls --updates --columns=application,version,name` → [(앱ID, 새 버전, 이름)]."""
    out = []
    for line in text.splitlines():
        cols = [c.strip() for c in line.split("\t")]
        if cols and cols[0] and "." in cols[0]:
            out.append((cols[0], cols[1] if len(cols) > 1 else "", cols[2] if len(cols) > 2 else cols[0]))
    return out


def _flatpak_icon(scope: str, app: str) -> str:
    """가장 큰 아이콘 파일 경로 (scalable 우선). 없으면 앱 ID (아이콘 테마에서 찾음)."""
    base = FLATPAK_DIRS.get(scope, FLATPAK_DIRS["system"]) / "exports/share/icons/hicolor"
    best, best_size = app, -1
    if base.is_dir():
        for f in base.glob(f"*/apps/{app}.*"):
            folder = f.parent.parent.name            # 예: 256x256, scalable
            size = 100000 if folder == "scalable" else int(folder.split("x")[0]) if folder.split("x")[0].isdigit() else 0
            if size > best_size:
                best, best_size = str(f), size
    return best


def _flatpak(args: list[str], timeout: float = 120) -> str:
    import shutil
    if not shutil.which("flatpak"):
        return ""
    env = dict(os.environ, LANG="C", LC_ALL="C")
    try:
        r = subprocess.run(["flatpak", *args], capture_output=True, text=True, env=env, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired):
        return ""
    return r.stdout if r.returncode == 0 else ""


def flatpak_programs() -> list[Program]:
    progs = parse_flatpak_list(_flatpak(["list", "--app", "--columns=application,name,version,size,installation"]))
    for p in progs:
        p.icon = _flatpak_icon(p.scope, p.package)
        d = FLATPAK_DIRS[p.scope] / "app" / p.package
        try:
            p.installed = d.stat().st_mtime
        except OSError:
            pass
    return progs


def flatpak_updates() -> list[tuple[str, str, str]]:
    """설치된 Flatpak 앱·부품 중 새 버전이 있는 것 (시스템·나만 설치 모두)."""
    out = []
    for scope in ("--system", "--user"):
        out += parse_flatpak_updates(_flatpak(["remote-ls", scope, "--updates",
                                               "--columns=application,version,name"], timeout=180))
    return out


def plan_removal(pkg: str) -> RemovalPlan:
    """무엇이 함께 지워지는지 미리 계산 (apt 시뮬레이션: 실제로 지우지 않음, 관리자 권한 불필요)."""
    status = read_status()
    if pkg not in status:
        return RemovalPlan(target=pkg, blocked="설치되어 있지 않은 프로그램입니다")
    why = protect_reason(pkg, status[pkg])
    if why:
        return RemovalPlan(target=pkg, packages=[pkg], blocked=f"{why}에 필요한 프로그램이라 지울 수 없습니다")
    env = dict(os.environ, LANG="C", LC_ALL="C")
    try:
        r = subprocess.run(["apt-get", "-s", "-q", "remove", pkg], capture_output=True, text=True,
                           env=env, timeout=60)
    except (OSError, subprocess.TimeoutExpired) as e:
        return RemovalPlan(target=pkg, blocked=f"제거 계획을 계산하지 못했습니다: {e}")
    if r.returncode != 0:
        return RemovalPlan(target=pkg, blocked="제거 계획을 계산하지 못했습니다: "
                           + (r.stderr.strip().splitlines() or ["알 수 없는 오류"])[-1])
    return check_plan(pkg, parse_apt_simulation(r.stdout), status)
