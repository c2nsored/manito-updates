"""KDE 시스템 트레이를 윈도우처럼: 필수 아이콘만 보이고, 새로 나타나는 프로그램 아이콘은 ▲(숨긴 아이콘) 안으로.

KDE에는 '새 아이콘은 기본으로 숨기기' 설정이 없어서, 로그인 동안 도는 작은 도우미(manito-desktop-helper)가
새 트레이 아이콘이 등록될 때 처음 보는 것만 숨김 목록에 넣는다.
사용자가 트레이 설정에서 '항상 보이기'로 꺼낸 아이콘은 이미 본 것으로 기록돼 있어 다시 숨기지 않는다.

순수 판단 로직(decide·script)은 표준 라이브러리만 쓰고 테스트가 있다. D-Bus 연결은 도우미 쪽(python3-gi).
"""
from __future__ import annotations

import json
from pathlib import Path

# 항상 보이는 것: 한/영 입력, 인터넷, 소리, 알림 (시계는 트레이 밖)
SHOWN = ["Fcitx", "org.kde.plasma.networkmanagement", "org.kde.plasma.volume", "org.kde.plasma.notifications"]
# 처음부터 ▲ 안에 두는 KDE 기본 항목
HIDDEN = ["org.kde.kupapplet", "org.kde.plasma.vault", "org.kde.plasma.mediacontroller", "org.kde.plasma.bluetooth",
          "org.kde.plasma.battery", "org.kde.plasma.manage-inputmethod", "org.kde.plasma.cameraindicator",
          "org.kde.plasma.brightness", "org.kde.plasma.keyboardlayout", "org.kde.kscreen", "org.kde.plasma.clipboard",
          "org.kde.plasma.devicenotifier", "kded6", "plasmashell_microphone"]


def seen_file() -> Path:
    return Path.home() / ".local" / "state" / "manito" / "tray-seen.json"


def load_seen(path: Path) -> set[str]:
    try:
        return set(json.loads(path.read_text(encoding="utf-8")))
    except (OSError, ValueError):
        return set()


def save_seen(path: Path, seen: set[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(sorted(seen), ensure_ascii=False), encoding="utf-8")


def decide(item_ids: list[str], seen: set[str], shown: list[str], hidden: list[str]) -> list[str]:
    """숨김 목록에 새로 넣을 아이콘 ID: 처음 보고, 사용자가 위치를 정한 적도 없는 것."""
    out = []
    for i in item_ids:
        if not i or i in seen or i in shown or i in hidden or i in out:
            continue
        out.append(i)
    return out


def hide_script(ids: list[str]) -> str:
    """plasmashell evaluateScript 용: 트레이의 숨김 목록에 ids 추가 (보이기 목록에서는 빼지 않음)."""
    return """
var add = %s;
panels().forEach(function(p){ p.widgets().forEach(function(w){
  if (w.type != "org.kde.plasma.systemtray") return;
  w.currentConfigGroup = ["General"];
  var hidden = w.readConfig("hiddenItems", []);
  var shown = w.readConfig("shownItems", []);
  hidden = (typeof hidden == "string") ? (hidden ? hidden.split(",") : []) : Array.prototype.slice.call(hidden);
  shown = (typeof shown == "string") ? (shown ? shown.split(",") : []) : Array.prototype.slice.call(shown);
  add.forEach(function(id){ if (hidden.indexOf(id) < 0 && shown.indexOf(id) < 0) hidden.push(id); });
  w.writeConfig("hiddenItems", hidden);
  w.reloadConfig();
});});
""" % json.dumps(ids, ensure_ascii=False)


def setup_script() -> str:
    """처음 설정: 필수만 보이고 KDE 기본 항목은 숨김 (화면 배치 스크립트와 같은 값)."""
    return """
panels().forEach(function(p){ p.widgets().forEach(function(w){
  if (w.type != "org.kde.plasma.systemtray") return;
  w.currentConfigGroup = ["General"];
  w.writeConfig("shownItems", %s);
  w.writeConfig("hiddenItems", %s);
  w.writeConfig("showAllItems", false);
  w.reloadConfig();
});});
""" % (json.dumps(SHOWN), json.dumps(HIDDEN))
