"""파일 검색 도구 — 허용된 폴더 안에서만, 읽기 전용."""
from __future__ import annotations

import fnmatch
import os
import time
from pathlib import Path

from ..config import expand
from . import Tool, ToolContext, ToolResult

SKIP_DIRS = {"node_modules", "__pycache__", ".git", ".cache", "Trash", ".local", ".var", "snap"}


def _allowed_roots(ctx: ToolContext) -> list[Path]:
    return [Path(expand(r)).resolve() for r in ctx.config["files"]["search_roots"]]


def _inside(p: Path, roots: list[Path]) -> bool:
    return any(p == r or p.is_relative_to(r) for r in roots)


def resolve_folder(ctx: ToolContext, folder: str) -> Path | None:
    if not folder:
        return None
    dirs = ctx.platform.user_dirs()
    key = folder.strip().removesuffix("폴더").strip()
    if key in dirs:
        return dirs[key]
    for k, v in dirs.items():
        if key.lower() in (k.lower(), v.name.lower()):
            return v
    return Path(expand(folder))


def search_files(ctx: ToolContext, query: str = "", folder: str = "", extension: str = "") -> ToolResult:
    cfg = ctx.config["files"]
    roots = _allowed_roots(ctx)
    base = resolve_folder(ctx, folder)
    if base is not None:
        base = base.resolve()
        if not _inside(base, roots):
            return ToolResult(False, f"'{base}'는 검색이 허용된 폴더가 아닙니다.")
        if not base.is_dir():
            return ToolResult(False, f"'{base}' 폴더가 없습니다.")
        starts = [base]
    else:
        starts = roots

    ext = extension.lower().lstrip(".")
    q = query.lower().strip()
    pattern = q if any(c in q for c in "*?[") else None
    max_results, max_depth = int(cfg["max_results"]), int(cfg["max_depth"])
    deadline = time.monotonic() + 5.0
    found: list[dict] = []
    truncated = False

    for start in starts:
        base_depth = len(start.parts)
        for dirpath, dirnames, filenames in os.walk(start):
            if time.monotonic() > deadline:
                truncated = True
                break
            depth = len(Path(dirpath).parts) - base_depth
            dirnames[:] = [d for d in dirnames if not d.startswith(".") and d not in SKIP_DIRS]
            if depth >= max_depth:
                dirnames[:] = []
            for fn in filenames:
                low = fn.lower()
                if ext and not low.endswith("." + ext):
                    continue
                if q:
                    if pattern:
                        if not fnmatch.fnmatch(low, pattern):
                            continue
                    elif q not in low:
                        continue
                p = Path(dirpath) / fn
                try:
                    st = p.stat()
                except OSError:
                    continue
                found.append({"path": str(p), "size": st.st_size, "modified": st.st_mtime})
                if len(found) >= max_results:
                    truncated = True
                    break
            if len(found) >= max_results:
                break

    found.sort(key=lambda x: -x["modified"])
    where = str(base) if base else "허용된 폴더 전체"
    if not found:
        return ToolResult(True, f"{where}에서 조건에 맞는 파일을 찾지 못했습니다.", [])
    lines = [f"- {f['path']}" for f in found[:20]]
    more = f"\n(그 외 {len(found) - 20}개)" if len(found) > 20 else ""
    note = "\n(결과가 많아 일부만 검색했습니다)" if truncated else ""
    return ToolResult(True, f"{where}에서 {len(found)}개 찾음:\n" + "\n".join(lines) + more + note, found)


TOOLS = [
    Tool(
        name="search_files",
        description="파일 이름으로 파일을 찾는다. 폴더는 '다운로드', '문서' 같은 이름이나 경로로 지정할 수 있다.",
        parameters={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "파일 이름 일부 또는 *.txt 같은 패턴"},
                "folder": {"type": "string", "description": "검색할 폴더 (예: 다운로드)"},
                "extension": {"type": "string", "description": "확장자 (예: pdf)"},
            },
        },
        risk="read",
        func=search_files,
    ),
]
