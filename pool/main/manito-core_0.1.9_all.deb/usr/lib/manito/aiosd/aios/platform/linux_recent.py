"""시작 메뉴 '최근 설치한 앱' 분류 — 마니또를 설치한 뒤에 새로 깐 프로그램을 최근 순으로.

KDE 시작 메뉴(XDG 메뉴 규격)에 하위 메뉴를 하나 더한다:
  ~/.config/menus/applications-merged/manito-recent.menu  (어떤 바로가기를 넣을지)
  ~/.local/share/desktop-directories/manito-recent.directory  (분류 이름·아이콘)
프로그램 목록·설치 시각은 프로그램 관리와 같은 것(linux_programs)을 쓴다. 표준 라이브러리만.
"""
from __future__ import annotations

import os
import subprocess
import time
from pathlib import Path
from xml.sax.saxutils import escape

MENU_NAME = "manito-recent"
TITLE = "최근 설치한 앱"
# 아래 menu_xml의 Layout으로 분류 목록 맨 위(구분선 바로 아래)에 온다 — 시작 메뉴가 캐시를 새로 읽은 뒤 반영됨
# (2026-11-16 사용자 확인. 처음엔 캐시 때문에 안 바뀐 것처럼 보였음). 구분선 위 묶음은 마니또 전용 시작 메뉴에서 —
# docs/08-윈도우식-화면-개편-계획.md
MENU_LABEL = TITLE
DAYS = 30
LIMIT = 15
GRACE = 3600        # OS 설치 직후 1시간 안에 들어온 것은 '기본 프로그램'으로 보고 뺀다


def os_installed_time() -> float:
    """마니또를 디스크에 설치한 시각 (루트 파일 시스템 만든 시각, 모르면 0)."""
    try:
        r = subprocess.run(["stat", "-c", "%W", "/"], capture_output=True, text=True, timeout=5)
        t = int(r.stdout.strip() or 0)
        if t > 0:
            return float(t)
    except (OSError, ValueError, subprocess.TimeoutExpired):
        pass
    try:
        return Path("/etc/hostname").stat().st_mtime
    except OSError:
        return 0.0


def recent(programs, os_installed: float, now: float | None = None, days: int = DAYS, limit: int = LIMIT):
    """최근 설치한 프로그램 (새것 먼저). 바로가기가 없는 것(뒤에서 도는 프로그램·파일)은 뺀다."""
    now = now if now is not None else time.time()
    out = [p for p in programs
           if p.installed and p.desktop_ids and p.installed > os_installed + GRACE and p.installed > now - days * 86400]
    out.sort(key=lambda p: p.installed, reverse=True)
    return out[:limit]


def menu_xml(desktop_ids: list[str]) -> str:
    inc = "\n".join(f"      <Filename>{escape(i)}</Filename>" for i in desktop_ids)
    return f"""<!DOCTYPE Menu PUBLIC "-//freedesktop//DTD Menu 1.0//EN"
 "http://www.freedesktop.org/standards/menu-spec/menu-1.0.dtd">
<!-- MANITO: 자동으로 만드는 파일입니다 (manito-desktop-helper). 직접 고치지 마세요. -->
<Menu>
  <Name>Applications</Name>
  <!-- 분류 목록 맨 위에 오게 (KDE 기본 배치를 이어받되 이 분류만 앞으로).
       이 파일은 기본 메뉴 정의보다 나중에 합쳐지므로 이 Layout이 쓰인다 -->
  <Layout>
    <Menuname>{MENU_NAME}</Menuname>
    <Merge type="menus"/>
    <Menuname>Applications</Menuname>
    <Merge type="files"/>
  </Layout>
  <Menu>
    <Name>{MENU_NAME}</Name>
    <Directory>{MENU_NAME}.directory</Directory>
    <Include>
{inc if inc else "      <Filename>manito-recent-none.desktop</Filename>"}
    </Include>
  </Menu>
</Menu>
"""


def directory_entry() -> str:
    return (f"[Desktop Entry]\nType=Directory\nName={MENU_LABEL}\nName[ko]={MENU_LABEL}\n"
            f"Comment={TITLE}\nComment[ko]={TITLE}\nIcon=appointment-new\n")


def paths() -> tuple[Path, Path]:
    cfg = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    data = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local/share"))
    return cfg / "menus/applications-merged" / f"{MENU_NAME}.menu", data / "desktop-directories" / f"{MENU_NAME}.directory"


def write(programs, os_installed: float, now: float | None = None) -> bool:
    """메뉴 파일을 고쳐 쓴다. 내용이 바뀌었으면 True (시작 메뉴 다시 읽기가 필요)."""
    ids = [i for p in recent(programs, os_installed, now) for i in p.desktop_ids[:1]]
    menu, directory = paths()
    changed = False
    for path, text in ((menu, menu_xml(ids)), (directory, directory_entry())):
        try:
            if path.read_text(encoding="utf-8") == text:
                continue
        except OSError:
            pass
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
        changed = True
    return changed
