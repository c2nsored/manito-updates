"""OS별 차이를 감추는 공통 인터페이스.

GPU 제조사·OS가 바뀌어도 이 인터페이스만 맞추면 나머지 코드는 그대로 쓴다.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class App:
    id: str                 # 고유 이름 (예: firefox.desktop)
    name: str               # 표시 이름
    names: list[str] = field(default_factory=list)  # 검색용 이름들 (번역명, 일반명, 키워드)
    target: str = ""        # 실행 대상 (.desktop 경로, .lnk 경로 등)
    source: str = "app"     # app / steam


@dataclass
class Program:
    """프로그램 관리 목록의 한 줄 (윈도우 '프로그램 추가/제거'의 항목)."""
    id: str                 # deb:패키지 / flatpak:범위:앱ID / file:경로
    name: str               # 표시 이름
    kind: str               # deb(패키지) / flatpak(Flathub 앱) / windows(윈도우 프로그램) / file(직접 받은 파일)
    package: str            # 패키지 이름 또는 파일 경로
    icon: str = ""
    comment: str = ""
    size_kb: int | None = None
    installed: float | None = None   # 설치(또는 마지막 업데이트) 시각
    version: str = ""
    protected: str = ""     # 비어 있지 않으면 지울 수 없는 이유
    apps: list[str] = field(default_factory=list)   # 이 패키지에 든 프로그램 이름들
    scope: str = ""         # Flatpak: system(모든 사용자) / user(나만)
    desktop_ids: list[str] = field(default_factory=list)   # 시작 메뉴 바로가기 이름들 (예: org.kde.kate.desktop)


@dataclass
class Game:
    appid: str
    name: str
    library: str = ""


@dataclass
class GpuInfo:
    name: str
    vram_total_mb: int | None
    vram_used_mb: int | None

    @property
    def vram_free_mb(self) -> int | None:
        if self.vram_total_mb is None or self.vram_used_mb is None:
            return None
        return self.vram_total_mb - self.vram_used_mb


class Platform:
    name = "base"

    def list_apps(self) -> list[App]:
        return []

    def launch_app(self, app: App) -> str:
        """프로그램 실행. 성공 시 설명 문자열, 실패 시 예외."""
        raise NotImplementedError

    def steam_roots(self) -> list[Path]:
        return []

    def launch_steam_game(self, appid: str) -> str:
        raise NotImplementedError

    def cpu_percent(self) -> float | None:
        return None

    def memory_mb(self) -> tuple[int, int] | None:
        """(전체, 사용 중) MB"""
        return None

    def gpus(self) -> list[GpuInfo]:
        return []

    # ── 프로그램 관리 ──
    def list_programs(self) -> list[Program]:
        return []

    def open_program_manager(self, args: list[str]) -> str:
        """프로그램 관리 창 띄우기 (제거·업데이트는 그 창에서 사용자가 확인하고 관리자 암호 입력)."""
        raise NotImplementedError("이 OS에서는 프로그램 관리 창을 아직 지원하지 않습니다")

    # ── 휴지통·웹 ──
    def trash(self, path: Path) -> str:
        """파일·폴더를 휴지통으로 (되돌릴 수 있게). 성공 시 설명, 실패 시 예외."""
        raise NotImplementedError("이 OS에서는 휴지통 기능을 아직 지원하지 않습니다")

    def empty_trash(self) -> int:
        """휴지통 비우기. 지운 항목 수 (모르면 -1)."""
        raise NotImplementedError("이 OS에서는 휴지통 비우기를 아직 지원하지 않습니다")

    def trash_dir(self) -> Path | None:
        """휴지통 위치 (휴지통 안의 파일을 다시 버리지 않게 검사용)."""
        return None

    def open_url(self, url: str) -> str:
        """기본 웹 브라우저로 주소 열기."""
        import webbrowser
        if not webbrowser.open(url):
            raise RuntimeError("웹 브라우저를 열 수 없습니다")
        return url

    # ── 코딩 모드: AI가 만든 프로그램 실행 ──
    # 셸을 거치지 않고 argv 그대로 실행한다. 리눅스 구현은 격리(작업 폴더만 쓰기, 인터넷 차단)를 덧씌운다.
    sandboxed = False

    def run_program(self, argv: list[str], project_dir: Path, timeout: float) -> tuple[int, str]:
        """끝날 때까지 기다리며 출력을 모은다. (종료 코드, 출력). 시간 초과는 코드 -1."""
        import subprocess
        try:
            r = subprocess.run(argv, cwd=project_dir, stdin=subprocess.DEVNULL, capture_output=True,
                               timeout=timeout, env=self._program_env(project_dir))
        except subprocess.TimeoutExpired as e:
            out = (e.stdout or b"") + (e.stderr or b"")
            return -1, out.decode("utf-8", "replace") + f"\n[{timeout:.0f}초가 지나 중단했습니다]"
        return r.returncode, (r.stdout + r.stderr).decode("utf-8", "replace")

    def open_program(self, argv: list[str], project_dir: Path) -> str:
        """창이 있는 프로그램을 띄워 두고 바로 돌아온다."""
        import subprocess
        subprocess.Popen(argv, cwd=project_dir, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, env=self._program_env(project_dir),
                         start_new_session=True, close_fds=True)
        return " ".join(argv)

    def _program_env(self, project_dir: Path) -> dict:
        import os
        env = dict(os.environ)
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        env["PYTHONIOENCODING"] = "utf-8"
        return env

    def user_dirs(self) -> dict[str, Path]:
        """'다운로드', '문서' 같은 이름 → 실제 폴더."""
        home = Path.home()
        d = {
            "홈": home,
            "다운로드": home / "Downloads",
            "문서": home / "Documents",
            "사진": home / "Pictures",
            "그림": home / "Pictures",
            "바탕화면": home / "Desktop",
            "음악": home / "Music",
            "동영상": home / "Videos",
            "비디오": home / "Videos",
        }
        return d
