"""Steam 설치 게임 목록 읽기 (AI 없이 정확하게).

Steam은 설치된 게임마다 steamapps/appmanifest_<번호>.acf 파일을 남긴다.
여러 라이브러리 폴더는 steamapps/libraryfolders.vdf 에 적혀 있다.
"""
from __future__ import annotations

import re
from pathlib import Path

from .base import Game

_TOKEN = re.compile(r'"((?:[^"\\]|\\.)*)"|([{}])')

# 게임이 아닌 Steam 구성요소 (Proton, 런타임 등)는 목록에서 뺀다
_NOT_GAMES = re.compile(r"^(Proton|Steam Linux Runtime|Steamworks Common|Steam Audio)", re.I)


def parse_vdf(text: str) -> dict:
    """Valve의 KeyValues(VDF) 텍스트 형식을 dict로 변환."""
    tokens = [m.group(1) if m.group(1) is not None else m.group(2) for m in _TOKEN.finditer(text)]
    root: dict = {}
    stack = [root]
    key = None
    for t in tokens:
        if t == "{":
            new: dict = {}
            if key is not None:
                stack[-1][key] = new
            stack.append(new)
            key = None
        elif t == "}":
            if len(stack) > 1:
                stack.pop()
            key = None
        elif key is None:
            key = t
        else:
            stack[-1][key] = t.replace('\\\\', '\\')
            key = None
    return root


def library_paths(steam_root: Path) -> list[Path]:
    libs = [steam_root]
    vdf = steam_root / "steamapps" / "libraryfolders.vdf"
    if vdf.is_file():
        try:
            data = parse_vdf(vdf.read_text(encoding="utf-8", errors="replace"))
            folders = data.get("libraryfolders") or data.get("LibraryFolders") or {}
            for v in folders.values():
                p = v.get("path") if isinstance(v, dict) else v
                if p:
                    pp = Path(p)
                    if pp not in libs:
                        libs.append(pp)
        except Exception:
            pass
    return libs


def installed_games(steam_roots: list[Path]) -> list[Game]:
    seen: dict[str, Game] = {}
    for root in steam_roots:
        if not (root / "steamapps").is_dir():
            continue
        for lib in library_paths(root):
            sa = lib / "steamapps"
            if not sa.is_dir():
                continue
            for acf in sa.glob("appmanifest_*.acf"):
                try:
                    st = parse_vdf(acf.read_text(encoding="utf-8", errors="replace")).get("AppState", {})
                except Exception:
                    continue
                appid, name = st.get("appid"), st.get("name")
                if appid and name and not _NOT_GAMES.match(name) and appid not in seen:
                    seen[appid] = Game(appid=appid, name=name, library=str(lib))
    return sorted(seen.values(), key=lambda g: g.name.lower())
