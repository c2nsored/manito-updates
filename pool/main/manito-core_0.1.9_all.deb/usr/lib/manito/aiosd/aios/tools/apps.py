"""프로그램·게임 검색 및 실행 도구."""
from __future__ import annotations

from . import Tool, ToolContext, ToolResult


def _cands(ms) -> list[dict]:
    return [{"id": m.app.id, "name": m.app.name, "source": m.app.source, "score": round(m.score)} for m in ms]


def find_app(ctx: ToolContext, query: str) -> ToolResult:
    ms = ctx.catalog.match(query, limit=10)
    if not ms:
        return ToolResult(True, f"'{query}'와(과) 비슷한 프로그램을 찾지 못했습니다.", [])
    lines = [f"- {m.app.name}" + (" (Steam 게임)" if m.app.source == "steam" else "") for m in ms]
    return ToolResult(True, "찾은 프로그램:\n" + "\n".join(lines), _cands(ms))


def launch_app(ctx: ToolContext, query: str = "", app_id: str = "", source: str = "") -> ToolResult:
    items = ctx.catalog.items()
    app = None
    ms = []
    if app_id:
        app = next((a for a in items if a.id == app_id), None)
        if not app:
            return ToolResult(False, f"'{app_id}' 프로그램이 목록에 없습니다.")
    else:
        app, ms = ctx.catalog.resolve(query, source=source or None)
        if not app:
            if not ms:
                return ToolResult(False, f"'{query}'에 해당하는 프로그램을 찾지 못했습니다. "
                                         "설정 파일의 [aliases]에 별칭을 추가할 수 있습니다.")
            lines = [f"{i+1}. {m.app.name}" + (" (Steam)" if m.app.source == "steam" else "")
                     for i, m in enumerate(ms)]
            return ToolResult(True, "어느 것을 실행할까요?\n" + "\n".join(lines), _cands(ms), needs_choice=True)

    try:
        if app.source == "steam":
            how = ctx.platform.launch_steam_game(app.target)
        else:
            how = ctx.platform.launch_app(app)
    except Exception as e:  # 실행 실패해도 서비스는 멈추지 않는다
        return ToolResult(False, f"'{app.name}' 실행 실패: {e}")
    kind = "게임" if app.source == "steam" else "프로그램"
    return ToolResult(True, f"{kind} '{app.name}'을(를) 실행했습니다.",
                      {"id": app.id, "name": app.name, "source": app.source, "how": how})


TOOLS = [
    Tool(
        name="find_app",
        description="설치된 프로그램과 Steam 게임을 이름으로 검색한다.",
        parameters={
            "type": "object",
            "properties": {"query": {"type": "string", "description": "프로그램 또는 게임 이름"}},
            "required": ["query"],
        },
        risk="read",
        func=find_app,
    ),
    Tool(
        name="launch_app",
        description="설치된 프로그램 또는 Steam 게임을 실행한다. 이름이 모호하면 후보 목록을 돌려준다.",
        parameters={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "프로그램 또는 게임 이름"},
                "app_id": {"type": "string", "description": "find_app 결과의 정확한 id (있으면 우선)"},
                "source": {"type": "string", "enum": ["", "app", "steam"],
                           "description": "steam 이면 Steam 게임에서만 찾기"},
            },
        },
        risk="launch",
        func=launch_app,
    ),
]
