"""Windows 구현 — 개발·테스트용. 최종 목표 OS는 Linux."""
from __future__ import annotations

import ctypes
import os
import time
from pathlib import Path

from .base import App, Platform


class _MEMSTATUS(ctypes.Structure):
    _fields_ = [
        ("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
        ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
        ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]


class _FILETIME(ctypes.Structure):
    _fields_ = [("lo", ctypes.c_ulong), ("hi", ctypes.c_ulong)]


def _ft(ft: _FILETIME) -> int:
    return (ft.hi << 32) | ft.lo


class WindowsPlatform(Platform):
    name = "windows"

    def list_apps(self) -> list[App]:
        roots = [
            Path(os.environ.get("ProgramData", r"C:\ProgramData")) / r"Microsoft\Windows\Start Menu\Programs",
            Path(os.environ.get("APPDATA", "")) / r"Microsoft\Windows\Start Menu\Programs",
        ]
        apps: dict[str, App] = {}
        for r in roots:
            if not r.is_dir():
                continue
            for lnk in r.rglob("*.lnk"):
                n = lnk.stem
                if "uninstall" in n.lower() or "제거" in n:
                    continue
                apps.setdefault(n.lower(), App(id=lnk.name, name=n, names=[n], target=str(lnk)))
        return sorted(apps.values(), key=lambda a: a.name.lower())

    def launch_app(self, app: App) -> str:
        os.startfile(app.target)  # type: ignore[attr-defined]
        return app.target

    def steam_roots(self) -> list[Path]:
        cands = [
            Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Steam",
            Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Steam",
        ]
        return [c for c in cands if c.is_dir()]

    def launch_steam_game(self, appid: str) -> str:
        if not appid.isdigit():
            raise ValueError("잘못된 Steam 게임 번호")
        url = f"steam://rungameid/{appid}"
        os.startfile(url)  # type: ignore[attr-defined]
        return url

    # ── 휴지통 (Windows 휴지통, 되돌리기 가능) ──
    def trash(self, path: Path) -> str:
        class SHFILEOPSTRUCTW(ctypes.Structure):
            _fields_ = [("hwnd", ctypes.c_void_p), ("wFunc", ctypes.c_uint), ("pFrom", ctypes.c_wchar_p),
                        ("pTo", ctypes.c_wchar_p), ("fFlags", ctypes.c_ushort), ("fAnyOperationsAborted", ctypes.c_int),
                        ("hNameMappings", ctypes.c_void_p), ("lpszProgressTitle", ctypes.c_wchar_p)]
        FO_DELETE, FOF_ALLOWUNDO, FOF_NOCONFIRMATION, FOF_SILENT, FOF_NOERRORUI = 3, 0x40, 0x10, 0x4, 0x400
        op = SHFILEOPSTRUCTW(None, FO_DELETE, str(path) + "\0", None,
                             FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_SILENT | FOF_NOERRORUI, 0, None, None)
        rc = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))
        if rc != 0 or op.fAnyOperationsAborted:
            raise RuntimeError(f"휴지통으로 옮기지 못했습니다 (코드 {rc})")
        return "Windows 휴지통"

    def empty_trash(self) -> int:
        SHERB_NOCONFIRMATION, SHERB_NOPROGRESSUI, SHERB_NOSOUND = 0x1, 0x2, 0x4
        ctypes.windll.shell32.SHEmptyRecycleBinW(None, None, SHERB_NOCONFIRMATION | SHERB_NOPROGRESSUI | SHERB_NOSOUND)
        return -1

    def cpu_percent(self) -> float | None:
        k = ctypes.windll.kernel32  # type: ignore[attr-defined]
        i1, k1, u1 = _FILETIME(), _FILETIME(), _FILETIME()
        i2, k2, u2 = _FILETIME(), _FILETIME(), _FILETIME()
        if not k.GetSystemTimes(ctypes.byref(i1), ctypes.byref(k1), ctypes.byref(u1)):
            return None
        time.sleep(0.2)
        k.GetSystemTimes(ctypes.byref(i2), ctypes.byref(k2), ctypes.byref(u2))
        idle = _ft(i2) - _ft(i1)
        total = (_ft(k2) - _ft(k1)) + (_ft(u2) - _ft(u1))  # kernel 시간에 idle 포함
        return round(100.0 * (1 - idle / total), 1) if total > 0 else None

    def memory_mb(self) -> tuple[int, int] | None:
        st = _MEMSTATUS()
        st.dwLength = ctypes.sizeof(_MEMSTATUS)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(st)):  # type: ignore[attr-defined]
            return None
        total = st.ullTotalPhys // (1024 * 1024)
        return total, total - st.ullAvailPhys // (1024 * 1024)
