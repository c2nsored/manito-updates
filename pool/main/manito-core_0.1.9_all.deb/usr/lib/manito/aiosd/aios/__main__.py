"""명령줄 진입점.

  python -m aios serve            서비스 실행 (채팅 화면: http://127.0.0.1:8765)
  python -m aios chat "메시지"     서비스 없이 바로 한 번 대화
  python -m aios status           시스템·모델 상태
  python -m aios apps [검색어]     인식한 프로그램·게임 목록
"""
from __future__ import annotations

import argparse
import json
import logging
import sys

from . import __version__


def main(argv: list[str] | None = None) -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(prog="aios", description="AI Native OS 핵심 서비스")
    ap.add_argument("--config", help="설정 파일 경로")
    ap.add_argument("-v", "--verbose", action="store_true")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("serve")
    s.add_argument("--port", type=int)
    c = sub.add_parser("chat")
    c.add_argument("message")
    sub.add_parser("status")
    a = sub.add_parser("apps")
    a.add_argument("query", nargs="?", default="")
    sub.add_parser("version")
    args = ap.parse_args(argv)

    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    if args.cmd == "version":
        print(__version__)
        return 0

    from .config import load_config
    from .core import AIOS

    cfg = load_config(args.config)
    aios = AIOS(cfg)
    try:
        if args.cmd == "serve":
            from .server import run_forever
            run_forever(aios, cfg["server"]["host"], args.port or int(cfg["server"]["port"]))
            return 0
        if args.cmd == "chat":
            out = aios.agent.handle(args.message)
            print(out["reply"])
            return 0
        if args.cmd == "status":
            from .tools.system import collect_status
            print(json.dumps(collect_status(aios.ctx), ensure_ascii=False, indent=2))
            return 0
        if args.cmd == "apps":
            if args.query:
                for m in aios.catalog.match(args.query, limit=20):
                    print(f"{m.score:5.0f}  [{m.app.source}] {m.app.name}  ({m.app.id})")
            else:
                for app in aios.catalog.items():
                    print(f"[{app.source}] {app.name}  ({app.id})")
            return 0
    finally:
        if args.cmd != "serve":
            aios.close()
    return 1


if __name__ == "__main__":
    sys.exit(main())
