"""모델 관리자: AI 모델(llama-server 프로세스)을 켜고 끄는 결정적 코드.

- 모델의 판단이 아니라 실제 VRAM 측정값으로 실행 가능 여부를 정한다.
- 게임 모드에서는 GPU 모델을 절대 올리지 않는다.
- 로딩에 실패해도 aiosd 자체는 멈추지 않는다.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path

from . import llm
from .config import data_dir, expand


class ModelUnavailable(Exception):
    """모델을 지금 사용할 수 없음 (이유는 사용자에게 그대로 보여준다)."""


@dataclass
class Profile:
    name: str
    kind: str = "managed"          # managed / external
    uses_gpu: bool = False
    vram_mb: int = 0
    port: int = 0
    command: list[str] = field(default_factory=list)
    base_url: str = ""
    model: str = "local"
    startup_timeout: float = 180.0

    @classmethod
    def from_config(cls, name: str, d: dict) -> "Profile":
        p = cls(name=name)
        for k in ("kind", "uses_gpu", "vram_mb", "port", "command", "base_url", "model", "startup_timeout"):
            if k in d:
                setattr(p, k, d[k])
        if p.kind == "managed" and not p.base_url:
            p.base_url = f"http://127.0.0.1:{p.port}/v1"
        return p


@dataclass
class _Running:
    proc: subprocess.Popen
    started: float
    last_used: float
    log: Path


class ModelManager:
    def __init__(self, config: dict, platform, memory=None):
        mcfg = config["models"]
        self.platform = platform
        self.memory = memory
        self.idle_unload = float(mcfg.get("gpu_idle_unload_seconds", 600))
        self.margin = int(mcfg.get("vram_safety_margin_mb", 1024))
        self.profiles = {n: Profile.from_config(n, d) for n, d in mcfg.get("profiles", {}).items()}
        self._running: dict[str, _Running] = {}
        self._errors: dict[str, str] = {}
        self._lock = threading.RLock()
        self.game_mode = bool(memory.get_state("game_mode", False)) if memory else False
        self._stop = threading.Event()
        self._watcher: threading.Thread | None = None

    # ── 상태 ──
    def is_running(self, name: str) -> bool:
        p = self.profiles.get(name)
        if not p:
            return False
        if p.kind == "external":
            return llm.health(p.base_url)
        r = self._running.get(name)
        return bool(r and r.proc.poll() is None)

    def status(self) -> list[dict]:
        out = []
        with self._lock:
            for n, p in self.profiles.items():
                r = self._running.get(n)
                running = r is not None and r.proc.poll() is None if p.kind == "managed" else None
                out.append({
                    "name": n, "kind": p.kind, "uses_gpu": p.uses_gpu, "vram_mb": p.vram_mb,
                    "running": bool(running),
                    "pid": r.proc.pid if (r and running) else None,
                    "last_used": r.last_used if r else None,
                    "error": self._errors.get(n),
                })
        return out

    # ── 로드 ──
    def _check_vram(self, p: Profile) -> None:
        gpus = self.platform.gpus()
        free = [g.vram_free_mb for g in gpus if g.vram_free_mb is not None]
        if not free:
            return  # 측정 불가한 환경(Windows 개발용 등) → 검사 생략
        need = p.vram_mb + self.margin
        if max(free) < need:
            raise ModelUnavailable(
                f"VRAM 부족: 필요 약 {need}MB, 여유 {max(free)}MB. "
                "다른 프로그램(게임 등)이 GPU를 사용 중일 수 있습니다.")

    def _build_argv(self, p: Profile) -> list[str]:
        argv = [expand(a.replace("{port}", str(p.port))) for a in p.command]
        if not argv:
            raise ModelUnavailable(f"모델 '{p.name}'의 실행 명령(command)이 설정되지 않았습니다.")
        exe = argv[0]
        if not (os.path.isfile(exe) or shutil.which(exe)):
            raise ModelUnavailable(f"AI 서버 프로그램 '{exe}'을(를) 찾을 수 없습니다. "
                                   "llama.cpp 설치가 필요합니다 (docs/05-Linux-설치.md).")
        if "-m" in argv:
            i = argv.index("-m")
            if i + 1 < len(argv) and not os.path.isfile(argv[i + 1]):
                raise ModelUnavailable(f"모델 파일이 없습니다: {argv[i + 1]}")
        return argv

    def ensure(self, name: str) -> Profile:
        """모델이 준비될 때까지 기다린다. 사용할 수 없으면 ModelUnavailable."""
        with self._lock:
            p = self.profiles.get(name)
            if not p:
                raise ModelUnavailable(f"'{name}' 모델 프로필이 설정에 없습니다.")
            if p.uses_gpu and self.game_mode:
                raise ModelUnavailable("게임 모드 중에는 GPU AI 모델을 실행하지 않습니다.")

            if p.kind == "external":
                if not llm.health(p.base_url):
                    raise ModelUnavailable(f"외부 AI 서버({p.base_url})가 응답하지 않습니다.")
                return p

            r = self._running.get(name)
            if r and r.proc.poll() is None:
                r.last_used = time.time()
                return p

            if p.uses_gpu:
                # GPU 모델은 하나만: 다른 GPU 모델 먼저 내리고 측정
                for other in [n for n in self._running if n != name and self.profiles[n].uses_gpu]:
                    self.unload(other)
                    time.sleep(1.0)
                self._check_vram(p)

            argv = self._build_argv(p)
            logdir = data_dir() / "logs"
            logdir.mkdir(parents=True, exist_ok=True)
            log = logdir / f"model-{name}.log"
            logf = open(log, "ab")
            kw: dict = {}
            if sys.platform != "win32":
                kw["start_new_session"] = True
            try:
                proc = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=logf,
                                        stderr=subprocess.STDOUT, **kw)
            except OSError as e:
                logf.close()
                raise ModelUnavailable(f"모델 실행 실패: {e}") from e
            logf.close()
            self._running[name] = _Running(proc, time.time(), time.time(), log)
            self._errors.pop(name, None)

        # 준비될 때까지 대기 (락 밖에서)
        deadline = time.time() + p.startup_timeout
        while time.time() < deadline:
            if proc.poll() is not None:
                self._errors[name] = f"모델 프로세스가 종료됨 (코드 {proc.returncode}). 로그: {log}"
                with self._lock:
                    self._running.pop(name, None)
                raise ModelUnavailable(self._errors[name])
            if llm.health(p.base_url, timeout=1.0):
                return p
            time.sleep(0.5)
        self.unload(name)
        self._errors[name] = f"모델 준비 시간 초과 ({p.startup_timeout:.0f}초). 로그: {log}"
        raise ModelUnavailable(self._errors[name])

    def touch(self, name: str) -> None:
        r = self._running.get(name)
        if r:
            r.last_used = time.time()

    # ── 언로드 ──
    def unload(self, name: str) -> bool:
        with self._lock:
            r = self._running.pop(name, None)
        if not r:
            return False
        if r.proc.poll() is None:
            r.proc.terminate()
            try:
                r.proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                r.proc.kill()
                r.proc.wait(timeout=5)
        return True

    def unload_all(self, gpu_only: bool = False) -> list[str]:
        names = [n for n in list(self._running) if not gpu_only or self.profiles[n].uses_gpu]
        return [n for n in names if self.unload(n)]

    def set_game_mode(self, on: bool) -> list[str]:
        """게임 모드 켜기 = GPU 모델 모두 언로드. (게임 자동 감지는 Phase 2)"""
        self.game_mode = on
        if self.memory:
            self.memory.set_state("game_mode", on)
        return self.unload_all(gpu_only=True) if on else []

    # ── 유휴 모델 자동 언로드 ──
    def start_watcher(self) -> None:
        if self._watcher:
            return
        self._watcher = threading.Thread(target=self._watch, name="model-watcher", daemon=True)
        self._watcher.start()

    def _watch(self) -> None:
        while not self._stop.wait(15):
            now = time.time()
            for n, r in list(self._running.items()):
                if r.proc.poll() is not None:
                    with self._lock:
                        self._running.pop(n, None)
                    self._errors[n] = f"모델 프로세스가 예기치 않게 종료됨 (코드 {r.proc.returncode})"
                elif self.profiles[n].uses_gpu and now - r.last_used > self.idle_unload:
                    self.unload(n)

    def shutdown(self) -> None:
        self._stop.set()
        self.unload_all()
