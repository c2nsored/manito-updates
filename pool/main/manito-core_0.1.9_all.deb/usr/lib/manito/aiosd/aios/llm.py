"""OpenAI 호환 AI 서버 클라이언트 (llama-server, Ollama, LM Studio, vLLM 공통).

특정 AI 엔진에 묶이지 않도록 이 표준 API만 사용한다.
"""
from __future__ import annotations

import json
import urllib.error
import urllib.request


class LLMError(Exception):
    pass


def _post(url: str, body: dict, timeout: float) -> dict:
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:500]
        raise LLMError(f"HTTP {e.code}: {detail}") from e
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise LLMError(f"AI 서버에 연결할 수 없습니다: {e}") from e
    except json.JSONDecodeError as e:
        raise LLMError("AI 서버 응답을 해석할 수 없습니다") from e


def chat(base_url: str, model: str, messages: list[dict], tools: list[dict] | None = None,
         timeout: float = 300.0, temperature: float = 0.3, max_tokens: int = 1024, think: bool = False) -> dict:
    """assistant 메시지(dict)를 돌려준다. tool_calls가 들어있을 수 있다.
    - max_tokens: 대답 길이 상한 (모델이 끝내지 못하고 헛말을 이어 가는 일 방지 — 2026-11-16 Gemma 4에서 6,700토큰 헛생성 96초)
    - think=False: '생각하기' 모드가 있는 모델(Gemma 4 등)은 끄고 바로 답하게 한다 (지원 안 하는 서버는 무시)"""
    body: dict = {"model": model, "messages": messages, "temperature": temperature, "stream": False,
                  "max_tokens": max_tokens, "chat_template_kwargs": {"enable_thinking": think}}
    if tools:
        body["tools"] = tools
    url = base_url.rstrip("/") + "/chat/completions"
    try:
        resp = _post(url, body, timeout)
    except LLMError as e:
        # 도구 호출이나 추가 옵션을 지원하지 않는 서버/모델이면 기본 형태로 한 번 더 시도
        if str(e).startswith("HTTP 4"):
            body.pop("tools", None)
            body.pop("chat_template_kwargs", None)
            resp = _post(url, body, timeout)
        else:
            raise
    try:
        msg = resp["choices"][0]["message"]
    except (KeyError, IndexError, TypeError) as e:
        raise LLMError(f"예상하지 못한 응답 형식: {str(resp)[:200]}") from e
    return normalize_message(msg, tools)


# ── 도구 호출이 글자로 새어 나온 경우 되살리기 ──
# 일부 엔진·모델 조합(예: llama.cpp 8681 + Gemma 4)은 도구 호출을 해석하지 못하고 원문 그대로 content에 남긴다:
#   ask_expert{task:<|"|>보고서 써 줘<|"|>}<tool_call|>      (앞에 '<|tool_call>call:'이 붙기도 함)
import re as _re  # noqa: E402

_RAW_CALL = _re.compile(r"^\s*(?:<\|tool_call>)?\s*(?:call:)?([A-Za-z_]\w*)\{(.*)\}\s*(?:<tool_call\|>)?\s*(?:<eos>)?\s*$",
                        _re.DOTALL)
_RAW_ARG = _re.compile(r'(\w+):(?:<\|"\|>(.*?)<\|"\|>|([^,}]*))', _re.DOTALL)


def _raw_value(text: str):
    t = text.strip()
    if t in ("true", "false"):
        return t == "true"
    try:
        return int(t)
    except ValueError:
        try:
            return float(t)
        except ValueError:
            return t


_PY_CALL = _re.compile(r"^\s*`*\s*([A-Za-z_]\w*)\s*\((.*)\)\s*`*\s*$", _re.DOTALL)


def _python_style_call(text: str, names: set[str]) -> tuple[str, dict] | None:
    """`open_program_manager(action="remove", program="카카오톡")`처럼 파이썬 함수 모양으로 쓴 호출.
    값은 ast.literal_eval로만 읽는다 (코드는 절대 실행하지 않음)."""
    import ast
    m = _PY_CALL.match(text)
    if not m or m.group(1) not in names:
        return None
    if not m.group(2).strip():
        return m.group(1), {}
    try:
        node = ast.parse(f"f({m.group(2)})", mode="eval").body
    except SyntaxError:
        return None
    if not isinstance(node, ast.Call) or node.args:
        return None
    try:
        return m.group(1), {k.arg: ast.literal_eval(k.value) for k in node.keywords if k.arg}
    except ValueError:
        return None


def normalize_message(msg: dict, tools: list[dict] | None) -> dict:
    """content에 원문 도구 호출만 들어 있으면 정식 tool_calls로 바꾼다 (등록된 도구 이름일 때만)."""
    if msg.get("tool_calls") or not tools:
        return msg
    names = {t.get("function", {}).get("name") for t in tools}
    text = _re.sub(r"^\s*(?:도구\s*호출|tool\s*call)\s*[:：]\s*", "", msg.get("content") or "", flags=_re.I)
    py = _python_style_call(text, names)
    if py:
        name, args = py
        return {**msg, "content": "", "tool_calls": [{"id": f"raw-{name}", "type": "function",
                                                      "function": {"name": name, "arguments": json.dumps(args, ensure_ascii=False)}}]}
    m = _RAW_CALL.match(text)
    if not m:
        return msg
    name = m.group(1)
    if name not in names:
        return msg
    args = {a.group(1): (a.group(2) if a.group(2) is not None else _raw_value(a.group(3) or ""))
            for a in _RAW_ARG.finditer(m.group(2))}
    return {**msg, "content": "", "tool_calls": [{"id": f"raw-{name}", "type": "function",
                                                  "function": {"name": name, "arguments": json.dumps(args, ensure_ascii=False)}}]}


def health(base_url: str, timeout: float = 2.0) -> bool:
    """서버가 요청을 받을 준비가 되었는지 확인."""
    root = base_url.rstrip("/")
    if root.endswith("/v1"):
        root = root[:-3]
    for path in ("/health", "/v1/models"):
        try:
            with urllib.request.urlopen(root + path, timeout=timeout) as r:
                if r.status == 200:
                    return True
        except Exception:
            continue
    return False
