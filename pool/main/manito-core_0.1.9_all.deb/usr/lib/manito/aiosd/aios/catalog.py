"""설치된 프로그램 + Steam 게임 통합 목록과 이름 매칭.

"사이버펑크 실행해줘" 같은 요청을 실제 실행 대상으로 바꾸는 부분.
AI 없이 결정적으로 동작한다.
"""
from __future__ import annotations

import difflib
import re
import threading
import time
from dataclasses import dataclass

from .platform import App
from .platform.steam import installed_games


def normalize(s: str) -> str:
    s = s.lower()
    s = re.sub(r"[\s\-_:.,'\"™®!()\[\]]+", "", s)
    return s


@dataclass
class Match:
    app: App
    score: float
    coverage: float = 1.0   # 검색어가 일치한 이름에서 차지하는 비율 (낮으면 우연히 겹친 것일 수 있음)


class Catalog:
    def __init__(self, platform, aliases: dict | None = None, ttl: float = 60.0):
        self.platform = platform
        self.aliases = {normalize(k): v for k, v in (aliases or {}).items()}
        self.ttl = ttl
        self._items: list[App] = []
        self._loaded = 0.0
        self._lock = threading.Lock()

    def items(self) -> list[App]:
        with self._lock:
            if time.time() - self._loaded > self.ttl:
                items = list(self.platform.list_apps())
                for g in installed_games(self.platform.steam_roots()):
                    items.append(App(id=f"steam:{g.appid}", name=g.name, names=[g.name],
                                     target=g.appid, source="steam"))
                self._items = items
                self._loaded = time.time()
            return self._items

    def refresh(self) -> None:
        with self._lock:
            self._loaded = 0.0

    def _queries(self, query: str) -> list[str]:
        q = normalize(query)
        qs = [q]
        if q in self.aliases:
            qs.insert(0, normalize(self.aliases[q]))
        return [x for x in qs if x]

    def match(self, query: str, source: str | None = None, limit: int = 5) -> list[Match]:
        qs = self._queries(query)
        if not qs:
            return []
        out = []
        for app in self.items():
            if source and app.source != source:
                continue
            best, cov = 0.0, 1.0
            for name in {app.name, *app.names}:
                n = normalize(name)
                if not n:
                    continue
                for i, q in enumerate(qs):
                    bonus = 5 if (i == 0 and len(qs) > 1) else 0  # 별칭 일치 우대
                    if n == q:
                        s = 100
                    elif n.startswith(q) and len(q) >= 2:
                        s = 90
                    elif q in n and len(q) >= 3:
                        s = 80
                    else:
                        s = difflib.SequenceMatcher(None, q, n).ratio() * 70
                    if s + bonus > best:
                        best, cov = s + bonus, min(1.0, len(q) / len(n))
            if best >= 55:
                out.append(Match(app, best, cov))
        out.sort(key=lambda m: (-m.score, m.app.name.lower()))
        return out[:limit]

    def resolve(self, query: str, source: str | None = None) -> tuple[App | None, list[Match]]:
        """확실한 하나가 있으면 (app, 후보), 아니면 (None, 후보)."""
        ms = self.match(query, source=source)
        if not ms:
            return None, []
        top = ms[0]
        if top.score >= 100:
            return top.app, ms
        clear_winner = len(ms) == 1 or top.score - ms[1].score >= 10
        # 예: '크롬' → 'Chrome Remote Desktop' 처럼 이름의 일부만 겹치면 실행 전에 사용자에게 확인
        if clear_winner and top.coverage >= 0.4:
            return top.app, ms
        return None, ms
