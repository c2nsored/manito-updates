"""설정 파일 로드. 설정 파일이 없어도 기본값으로 동작한다."""
from __future__ import annotations

import copy
import os
import sys
import tomllib
from pathlib import Path

DEFAULTS: dict = {
    "server": {"host": "127.0.0.1", "port": 8765},
    # mode: "ai_first"(상주 AI가 먼저 판단, 규칙은 비상용) | "rule_first"(규칙 먼저)
    # primary_profile: 상주 AI (비어 있으면 default_profile), expert_profile: 어려운 일을 맡길 전문가 AI (없으면 위임 안 함)
    "agent": {"mode": "ai_first", "primary_profile": "", "expert_profile": "",
              "default_profile": "light-cpu", "use_llm": True, "history_messages": 12},
    "models": {
        "gpu_idle_unload_seconds": 600,
        "vram_safety_margin_mb": 1024,
        "profiles": {},
    },
    "files": {"search_roots": ["~"], "max_results": 50, "max_depth": 6},
    # 코딩 모드: AI가 프로그램을 만드는 전용 작업 폴더, 실행 제한 시간(초)
    "coding": {"workspace": "~/manito-projects", "run_timeout": 60},
    # 한국어 이름 → 프로그램 이름 (설정 파일 [aliases]로 추가·덮어쓰기 가능)
    "aliases": {
        "파이어폭스": "firefox", "크롬": "chrome", "엣지": "edge", "스팀": "steam",
        "터미널": "konsole", "콘솔": "konsole", "파일 관리자": "dolphin", "탐색기": "dolphin",
        "계산기": "calculator", "메모장": "kate", "텍스트 편집기": "kate", "설정": "system settings",
        "시스템 설정": "system settings", "디스코드": "discord", "블렌더": "blender",
        "김프": "gimp", "브이엘씨": "vlc", "비주얼 스튜디오 코드": "visual studio code", "브이에스코드": "code",
    },
}


def config_dir() -> Path:
    if sys.platform == "win32":
        return Path(os.environ.get("APPDATA", Path.home())) / "aios"
    return Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "aios"


def data_dir() -> Path:
    if sys.platform == "win32":
        return Path(os.environ.get("LOCALAPPDATA", Path.home())) / "aios"
    return Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / "aios"


def _merge(base: dict, override: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def load_config(path: str | os.PathLike | None = None) -> dict:
    """path가 없으면 AIOS_CONFIG 환경변수 → 기본 위치 순으로 찾는다."""
    candidates = []
    if path:
        candidates.append(Path(path))
    elif os.environ.get("AIOS_CONFIG"):
        candidates.append(Path(os.environ["AIOS_CONFIG"]))
    else:
        candidates.append(config_dir() / "aios.toml")

    cfg = copy.deepcopy(DEFAULTS)
    for c in candidates:
        if c.is_file():
            with open(c, "rb") as f:
                cfg = _merge(cfg, tomllib.load(f))
            cfg["_source"] = str(c)
            break
    return cfg


def expand(p: str) -> str:
    return os.path.expandvars(os.path.expanduser(p))
