"""코딩 모드 도구 — AI가 전용 작업 폴더 안에서 프로그램을 만들고 실행한다.

- 작업 폴더: 설정 [coding] workspace (기본 ~/manito-projects) 아래 프로젝트별 폴더
- 파일 보기·만들기·고치기(위험도 read/workspace)는 작업 폴더 안에서만, 묻지 않고 처리.
  경로는 매번 실제 위치로 풀어서 작업 폴더 밖(../, 바로가기 등)으로 나가면 거부한다.
- 실행(위험도 system)은 셸 명령이 아니라 "이 프로젝트의 이 파이썬 파일 실행"만 가능하고, 매번 사용자 허락이 필요하다.
  리눅스에서는 격리 실행(작업 폴더만 쓰기, 홈의 다른 파일 숨김, 인터넷 차단) — aios/platform/linux.py
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

from ..config import expand
from . import Tool, ToolContext, ToolResult

MAX_FILE_BYTES = 1_000_000
MAX_READ_CHARS = 100_000
MAX_OUTPUT_CHARS = 4000
MAX_LIST = 300
_NAME = re.compile(r"[\w가-힣][\w가-힣.-]{0,59}")
SKIP = {"__pycache__", ".git", ".venv", "node_modules"}


def workspace(ctx: ToolContext) -> Path:
    return Path(expand(ctx.config.get("coding", {}).get("workspace", "~/manito-projects")))


def project_dir(ctx: ToolContext, project: str, create: bool = False) -> Path:
    project = (project or "").strip()
    if not _NAME.fullmatch(project) or project in (".", ".."):
        raise ValueError(f"프로젝트 이름이 올바르지 않습니다: '{project}' (글자·숫자·-·_ 만, 60자 이내)")
    d = workspace(ctx) / project
    if create:
        d.mkdir(parents=True, exist_ok=True)
    return d


def _inside(ctx: ToolContext, project: str, rel: str) -> Path:
    base = project_dir(ctx, project).resolve()
    target = (base / (rel or "").strip()).resolve()
    if target != base and not target.is_relative_to(base):
        raise ValueError(f"'{rel}'는 프로젝트 폴더 밖입니다.")
    return target


def _err(e: Exception) -> ToolResult:
    return ToolResult(False, str(e))


def project_files(ctx: ToolContext, project: str = "") -> ToolResult:
    try:
        base = project_dir(ctx, project)
    except ValueError as e:
        return _err(e)
    if not base.is_dir():
        return ToolResult(True, f"프로젝트 '{project}'에는 아직 파일이 없습니다.", [])
    files = []
    for p in sorted(base.rglob("*")):
        if any(part in SKIP for part in p.relative_to(base).parts):
            continue
        if p.is_file():
            files.append({"path": p.relative_to(base).as_posix(), "size": p.stat().st_size})
            if len(files) >= MAX_LIST:
                break
    text = "\n".join(f"- {f['path']} ({f['size']}바이트)" for f in files) or "(파일 없음)"
    return ToolResult(True, f"프로젝트 '{project}' 파일 {len(files)}개:\n{text}", files)


def project_read(ctx: ToolContext, project: str = "", path: str = "") -> ToolResult:
    try:
        f = _inside(ctx, project, path)
    except ValueError as e:
        return _err(e)
    if not f.is_file():
        return ToolResult(False, f"'{path}' 파일이 없습니다.")
    text = f.read_text(encoding="utf-8", errors="replace")
    cut = len(text) > MAX_READ_CHARS
    return ToolResult(True, text[:MAX_READ_CHARS] + ("\n[이하 생략]" if cut else ""), {"path": path})


def project_write(ctx: ToolContext, project: str = "", path: str = "", content: str = "") -> ToolResult:
    try:
        project_dir(ctx, project, create=True)
        f = _inside(ctx, project, path)
    except ValueError as e:
        return _err(e)
    if f == project_dir(ctx, project).resolve():
        return ToolResult(False, "파일 이름이 필요합니다.")
    data = content.encode("utf-8")
    if len(data) > MAX_FILE_BYTES:
        return ToolResult(False, f"파일이 너무 큽니다 ({len(data)}바이트, 최대 {MAX_FILE_BYTES}).")
    existed = f.exists()
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_bytes(data)
    return ToolResult(True, f"{'고침' if existed else '만듦'}: {project}/{path} ({len(data)}바이트)", {"path": path})


def _python_target(ctx: ToolContext, project: str, file: str) -> tuple[Path, Path]:
    base = project_dir(ctx, project).resolve()
    f = _inside(ctx, project, file)
    if f.suffix != ".py":
        raise ValueError("지금은 파이썬 파일(.py)만 실행할 수 있습니다.")
    if not f.is_file():
        raise ValueError(f"'{file}' 파일이 없습니다.")
    return base, f


def project_run(ctx: ToolContext, project: str = "", file: str = "", args: list | None = None) -> ToolResult:
    try:
        base, f = _python_target(ctx, project, file)
    except ValueError as e:
        return _err(e)
    argv = [sys.executable, str(f)] + [str(a) for a in (args or [])][:20]
    timeout = float(ctx.config.get("coding", {}).get("run_timeout", 60))
    try:
        code, out = ctx.platform.run_program(argv, base, timeout)
    except Exception as e:
        return ToolResult(False, f"실행하지 못했습니다: {e}")
    out = out.strip()
    if len(out) > MAX_OUTPUT_CHARS:
        out = "[앞부분 생략]\n" + out[-MAX_OUTPUT_CHARS:]
    where = " (격리 실행)" if getattr(ctx.platform, "sandboxed", False) else ""
    head = f"실행 결과: {project}/{file}{where} — 종료 코드 {code}"
    return ToolResult(code == 0, f"{head}\n{out or '(출력 없음)'}", {"code": code})


def project_open(ctx: ToolContext, project: str = "", file: str = "") -> ToolResult:
    try:
        base, f = _python_target(ctx, project, file)
        ctx.platform.open_program([sys.executable, str(f)], base)
    except Exception as e:
        return ToolResult(False, f"띄우지 못했습니다: {e}")
    return ToolResult(True, f"창으로 띄웠습니다: {project}/{file}")


_P = {"project": {"type": "string", "description": "프로젝트 이름"}}

TOOLS = [
    Tool("project_files", "코딩 프로젝트의 파일 목록을 본다.",
         {"type": "object", "properties": dict(_P), "required": ["project"]}, "read", project_files),
    Tool("project_read", "코딩 프로젝트의 파일 내용을 읽는다.",
         {"type": "object", "properties": {**_P, "path": {"type": "string", "description": "프로젝트 안 상대 경로"}},
          "required": ["project", "path"]}, "read", project_read),
    Tool("project_write", "코딩 프로젝트에 파일을 만들거나 전체 내용을 새로 쓴다 (프로젝트 폴더 안에서만).",
         {"type": "object", "properties": {**_P, "path": {"type": "string", "description": "프로젝트 안 상대 경로"},
                                           "content": {"type": "string", "description": "파일 전체 내용"}},
          "required": ["project", "path", "content"]}, "workspace", project_write),
    Tool("project_run", "코딩 프로젝트의 파이썬 파일을 실행하고 출력을 본다 (사용자 허락 필요, 제한 시간 있음).",
         {"type": "object", "properties": {**_P, "file": {"type": "string", "description": "실행할 .py 파일"},
                                           "args": {"type": "array", "items": {"type": "string"}}},
          "required": ["project", "file"]}, "system", project_run),
    Tool("project_open", "창이 있는 프로그램(.py)을 화면에 띄운다 (사용자 허락 필요).",
         {"type": "object", "properties": {**_P, "file": {"type": "string"}}, "required": ["project", "file"]},
         "system", project_open),
]

CODING_TOOL_NAMES = {t.name for t in TOOLS}
