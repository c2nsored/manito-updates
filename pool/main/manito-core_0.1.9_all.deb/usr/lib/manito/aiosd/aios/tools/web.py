"""웹 도구: 기본 웹 브라우저(MANITO에서는 Edge)로 주소를 열거나 검색한다.

AI가 직접 인터넷에 접속하는 것이 아니라, 사용자의 브라우저에 페이지를 띄워 주기만 한다.
http/https 주소만 연다 (file:, javascript: 등은 거부).
"""
from __future__ import annotations

import re
import urllib.parse

from . import Tool, ToolContext, ToolResult

SEARCH_URL = "https://www.google.com/search?q={q}"
# 이름.이름 형태의 주소(한글 주소 포함), localhost, IPv4
_HOST = re.compile(r"(?:[\w-]+\.)+[\w-]{2,}|localhost|\d{1,3}(?:\.\d{1,3}){3}")


def _normalize(url: str) -> str:
    url = (url or "").strip()
    if not url:
        raise ValueError("열 주소가 비어 있습니다")
    if "://" not in url:
        # "javascript:..." "file:..." 처럼 다른 방식의 주소는 거부, "naver.com" 같은 짧은 주소만 https 를 붙인다
        if re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*:(?!\d)", url):
            raise ValueError(f"웹 주소(http/https)만 열 수 있습니다: {url}")
        url = "https://" + url
    parts = urllib.parse.urlsplit(url)
    try:
        parts.port                            # 포트가 숫자가 아니면 여기서 오류
    except ValueError as e:
        raise ValueError(f"올바른 웹 주소가 아닙니다: {url}") from e
    host = parts.hostname or ""
    if parts.scheme not in ("http", "https") or not _HOST.fullmatch(host):
        raise ValueError(f"웹 주소(http/https)만 열 수 있습니다: {url}")
    return url


def open_url(ctx: ToolContext, url: str = "") -> ToolResult:
    try:
        u = _normalize(url)
        ctx.platform.open_url(u)
    except Exception as e:
        return ToolResult(False, f"웹 페이지를 열지 못했습니다: {e}")
    return ToolResult(True, f"웹 브라우저에서 열었습니다: {u}", {"url": u})


def web_search(ctx: ToolContext, query: str = "") -> ToolResult:
    q = (query or "").strip()
    if not q:
        return ToolResult(False, "검색어가 비어 있습니다.")
    u = SEARCH_URL.format(q=urllib.parse.quote_plus(q))
    try:
        ctx.platform.open_url(u)
    except Exception as e:
        return ToolResult(False, f"검색 페이지를 열지 못했습니다: {e}")
    return ToolResult(True, f"웹 브라우저에서 '{q}'을(를) 검색했습니다.", {"url": u})


TOOLS = [
    Tool("open_url", "웹 페이지를 사용자의 웹 브라우저로 연다 (예: naver.com, https://...).",
         {"type": "object", "properties": {"url": {"type": "string", "description": "열 웹 주소"}}, "required": ["url"]},
         "launch", open_url),
    Tool("web_search", "웹 브라우저에서 검색어로 검색 결과 페이지를 연다.",
         {"type": "object", "properties": {"query": {"type": "string", "description": "검색어"}}, "required": ["query"]},
         "launch", web_search),
]
