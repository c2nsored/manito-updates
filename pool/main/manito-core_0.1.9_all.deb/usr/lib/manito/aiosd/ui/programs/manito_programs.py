#!/usr/bin/env python3
"""MANITO 프로그램 관리 — 설치된 프로그램 보기·지우기·업데이트 (윈도우의 '프로그램 추가/제거' 같은 창).

- 목록과 '무엇이 함께 지워지는지' 계산·안전 판단: aios.platform.linux_programs (표준 라이브러리, 테스트 있음)
- 실제 제거·업데이트: PackageKit (리눅스 표준 설치 서비스) → 할 때마다 관리자 암호 창 (상시 관리자 권한 없음, 원칙 4)
- 직접 받은 파일(rclone 등): 휴지통으로 (되살릴 수 있음)

화면 부품은 PyQt6(위젯) — 핵심 서비스(aiosd)가 아니라 화면 프로그램이라 원칙 8(표준 라이브러리만)의 예외.
이유: KDE와 같은 모양, 마니또 기본 설치에 이미 포함(python3-pyqt6), PackageKit은 python3-gi로 호출.

사용: manito-programs [--updates] [--remove 패키지이름]
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parent.parent.parent))   # …/aiosd (aios 패키지가 있는 곳)

from PyQt6.QtCore import QObject, QSize, Qt, QThread, pyqtSignal  # noqa: E402
from PyQt6.QtGui import QIcon  # noqa: E402
from PyQt6.QtWidgets import (  # noqa: E402
    QApplication, QCheckBox, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMessageBox,
    QProgressBar, QPushButton, QTabWidget, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget,
)

from aios.platform.linux_programs import flatpak_updates, list_programs, plan_removal  # noqa: E402

TITLE = "프로그램 관리"


# ── PackageKit (관리자 작업) ──
def _pk():
    import gi
    gi.require_version("PackageKitGlib", "1.0")
    from gi.repository import PackageKitGlib
    return PackageKitGlib


class Job(QObject):
    """오래 걸리는 일을 화면이 멈추지 않게 따로 실행."""
    progress = pyqtSignal(int, str)
    done = pyqtSignal(object, object)   # (작업, 결과)
    failed = pyqtSignal(str)

    def __init__(self, fn, *args, ok=None):
        super().__init__()
        self.fn, self.args, self.ok = fn, args, ok

    def run(self):
        try:
            self.done.emit(self, self.fn(self, *self.args))
        except Exception as e:   # noqa: BLE001 — 사용자에게 그대로 알림
            self.failed.emit(_friendly_error(e))


def _friendly_error(e: Exception) -> str:
    msg = str(e)
    low = msg.lower()
    if "not authorized" in low or "authorization" in low or "polkit" in low or "dismissed" in low:
        return "관리자 암호 확인이 취소되었거나 실패했어요."
    if "lock" in low:
        return "다른 설치·업데이트 작업이 진행 중이에요. 잠시 뒤 다시 해 주세요."
    return msg


def _progress_cb(job: Job, label: str):
    def cb(progress, _type, _data=None):
        try:
            pct = progress.get_property("percentage")
        except Exception:   # noqa: BLE001
            pct = -1
        job.progress.emit(pct if isinstance(pct, int) and 0 <= pct <= 100 else -1, label)
    return cb


def _check(results):
    err = results.get_error_code() if results else None
    if err is not None:
        raise RuntimeError(err.get_details() or "작업 실패")
    return results


def pk_remove(job: Job, packages: list[str]):
    pk = _pk()
    client = pk.Client()
    cb = _progress_cb(job, "지우는 중")
    res = _check(client.resolve(pk.filter_bitfield_from_string("installed"), packages, None, cb, None))
    ids = [p.get_id() for p in res.get_package_array()]
    if not ids:
        raise RuntimeError("지울 프로그램을 찾지 못했어요 (이미 지워졌을 수 있어요)")
    flags = pk.transaction_flag_bitfield_from_string("only-trusted")
    _check(client.remove_packages(flags, ids, True, False, None, cb, None))
    return len(ids)


def pk_check_updates(job: Job):
    pk = _pk()
    client = pk.Client()
    cb = _progress_cb(job, "업데이트 확인 중")
    try:
        client.refresh_cache(False, None, cb, None)   # 목록 새로 받기 (실패해도 가진 목록으로 계속)
    except Exception:   # noqa: BLE001
        pass
    res = _check(client.get_updates(pk.filter_bitfield_from_string("none"), None, cb, None))
    return [(p.get_name(), p.get_version(), p.get_id()) for p in res.get_package_array()]


# ── Flatpak (Flathub 앱) ──
def _run_flatpak(args: list[str]):
    import os
    import subprocess
    env = dict(os.environ, LANG="C", LC_ALL="C")
    r = subprocess.run(["flatpak", *args], capture_output=True, text=True, env=env, timeout=3600)
    if r.returncode != 0:
        raise RuntimeError((r.stderr.strip().splitlines() or ["Flatpak 작업 실패"])[-1])


def flatpak_remove(job: Job, scope: str, app: str):
    job.progress.emit(-1, "지우는 중")
    _run_flatpak(["uninstall", "--noninteractive", "-y", f"--{scope}", app])
    try:   # 이 앱만 쓰던 공통 부품(런타임)도 정리 — 실패해도 앱 제거는 끝났으니 넘어감
        _run_flatpak(["uninstall", "--noninteractive", "-y", f"--{scope}", "--unused"])
    except Exception:   # noqa: BLE001
        pass
    return 1


def check_all_updates(job: Job):
    ups = {"deb": [], "flatpak": [], "error": ""}
    try:
        ups["deb"] = pk_check_updates(job)
    except Exception as e:   # noqa: BLE001 — 한쪽이 실패해도 다른 쪽은 보여 준다
        ups["error"] = _friendly_error(e)
    job.progress.emit(-1, "Flathub 앱 업데이트 확인 중")
    ups["flatpak"] = flatpak_updates()
    return ups


def update_all_job(job: Job, ups: dict):
    n = 0
    if ups["deb"]:
        n += pk_update(job, [i for _, _, i in ups["deb"]])
    if ups["flatpak"]:
        job.progress.emit(-1, "Flathub 앱 업데이트하는 중")
        for scope in ("system", "user"):
            try:
                _run_flatpak(["update", "--noninteractive", "-y", f"--{scope}"])
            except Exception:   # noqa: BLE001 — '나만 설치'가 하나도 없으면 실패할 수 있어 무시
                if scope == "system":
                    raise
        n += len(ups["flatpak"])
    return n


def pk_update(job: Job, ids: list[str]):
    pk = _pk()
    client = pk.Client()
    flags = pk.transaction_flag_bitfield_from_string("only-trusted")
    _check(client.update_packages(flags, ids, None, _progress_cb(job, "업데이트하는 중"), None))
    return len(ids)


# ── 화면 ──
def _icon(name: str) -> QIcon:
    if name and Path(name).is_absolute() and Path(name).exists():
        return QIcon(name)
    ic = QIcon.fromTheme(name) if name else QIcon()
    return ic if not ic.isNull() else QIcon.fromTheme("application-x-executable")


def _size(kb: int | None) -> str:
    if kb is None:
        return ""
    if kb >= 1024 * 1024:
        return f"{kb / 1024 / 1024:.1f} GB"
    if kb >= 1024:
        return f"{kb / 1024:.0f} MB"
    return f"{kb} KB"


def _date(ts: float | None) -> str:
    return time.strftime("%Y-%m-%d", time.localtime(ts)) if ts else ""


class Window(QWidget):
    def __init__(self, start_updates: bool, remove: str | None):
        super().__init__()
        self.setWindowTitle(TITLE)
        self.setWindowIcon(QIcon.fromTheme("manito-programs", QIcon.fromTheme("applications-other")))
        self.resize(760, 560)
        self.programs = []
        self.updates = {}
        self._threads = []

        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_installed(), "설치된 프로그램")
        self.tabs.addTab(self._build_updates(), "업데이트")
        self.bar = QProgressBar()
        self.bar.setVisible(False)
        self.status = QLabel("")
        lay = QVBoxLayout(self)
        lay.addWidget(self.tabs)
        lay.addWidget(self.bar)
        lay.addWidget(self.status)

        self.reload()
        if start_updates:
            self.tabs.setCurrentIndex(1)
            self.check_updates()
        if remove:
            self.select_package(remove)
            self.remove_selected()

    # 설치된 프로그램 탭
    def _build_installed(self) -> QWidget:
        w = QWidget()
        self.search = QLineEdit()
        self.search.setPlaceholderText("프로그램 찾기")
        self.search.textChanged.connect(self.fill)
        self.show_system = QCheckBox("시스템 필수 프로그램도 보기")
        self.show_system.toggled.connect(self.fill)
        top = QHBoxLayout()
        top.addWidget(self.search, 1)
        top.addWidget(self.show_system)
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["이름", "크기", "설치한 날"])
        self.tree.setRootIsDecorated(False)
        self.tree.setIconSize(QSize(32, 32))
        self.tree.setColumnWidth(0, 470)
        self.tree.itemSelectionChanged.connect(self.on_select)
        self.info = QLabel("지울 프로그램을 고르세요.")
        self.info.setWordWrap(True)
        self.remove_btn = QPushButton(QIcon.fromTheme("edit-delete"), "제거…")
        self.remove_btn.setEnabled(False)
        self.remove_btn.clicked.connect(self.remove_selected)
        bottom = QHBoxLayout()
        bottom.addWidget(self.info, 1)
        bottom.addWidget(self.remove_btn)
        lay = QVBoxLayout(w)
        lay.addLayout(top)
        lay.addWidget(self.tree)
        lay.addLayout(bottom)
        return w

    def reload(self):
        self.programs = list_programs()
        self.fill()

    def fill(self):
        q = self.search.text().strip().lower()
        self.tree.clear()
        shown = 0
        for p in self.programs:
            if p.protected and not self.show_system.isChecked():
                continue
            hay = " ".join([p.name, p.package, p.comment, *p.apps]).lower()
            if q and q not in hay:
                continue
            label = p.name + (f"\n{p.comment}" if p.comment and p.comment != p.name else "")
            it = QTreeWidgetItem([label, _size(p.size_kb), _date(p.installed)])
            it.setIcon(0, _icon(p.icon))
            it.setData(0, Qt.ItemDataRole.UserRole, p)
            tip = f"{p.package}" + (f"  버전 {p.version}" if p.version else "")
            if len(p.apps) > 1:
                tip += "\n포함: " + ", ".join(p.apps)
            if p.protected:
                tip += f"\n🔒 지울 수 없음 — {p.protected}"
            it.setToolTip(0, tip)
            if p.protected:
                it.setForeground(0, self.palette().placeholderText())
            self.tree.addTopLevelItem(it)
            shown += 1
        self.status.setText(f"프로그램 {shown}개")
        self.on_select()

    def selected(self):
        items = self.tree.selectedItems()
        return items[0].data(0, Qt.ItemDataRole.UserRole) if items else None

    def select_package(self, pkg: str):
        for i in range(self.tree.topLevelItemCount()):
            it = self.tree.topLevelItem(i)
            if it.data(0, Qt.ItemDataRole.UserRole).package == pkg:
                self.tree.setCurrentItem(it)
                return

    def on_select(self):
        p = self.selected()
        if not p:
            self.info.setText("지울 프로그램을 고르세요.")
            self.remove_btn.setEnabled(False)
        elif p.protected:
            self.info.setText(f"🔒 {p.name}: {p.protected}에 필요해서 지울 수 없어요.")
            self.remove_btn.setEnabled(False)
        else:
            kind = {"file": "직접 받은 파일 — 휴지통으로 옮겨요 (되살릴 수 있어요)",
                    "windows": "윈도우용 프로그램"}.get(p.kind, p.package)
            self.info.setText(f"{p.name}  ({kind})")
            self.remove_btn.setEnabled(not self._threads)

    def remove_selected(self):
        p = self.selected()
        if not p or p.protected:
            return
        if p.kind == "file":
            return self._trash_file(p)
        if p.kind == "windows":
            text = (f"<b>{p.name}</b>을(를) 지울까요?<br><br>윈도우용 프로그램이에요. 이 프로그램의 설정·대화 기록 등 "
                    "프로그램 안에 저장된 것도 함께 지워지고 되돌릴 수 없어요.")
            if QMessageBox.question(self, TITLE, text) != QMessageBox.StandardButton.Yes:
                return
            try:
                from aios.platform.linux_winapps import remove_app
                remove_app(p.package)
            except Exception as e:   # noqa: BLE001
                QMessageBox.warning(self, TITLE, f"지우지 못했어요: {e}")
                return
            self._finish(f"{p.name}을(를) 지웠어요.")
            return
        if p.kind == "flatpak":
            text = (f"<b>{p.name}</b>을(를) 지울까요?<br><br>Flathub 앱이에요. 이 앱만 쓰던 공통 부품도 함께 정리해요.<br>"
                    "앱의 설정·작업 파일은 남겨 둬요. 관리자 암호를 물어볼 수 있어요.")
            if QMessageBox.question(self, TITLE, text) != QMessageBox.StandardButton.Yes:
                return
            self.busy(f"{p.name} 지우는 중…")
            self.start(flatpak_remove, p.scope, p.package, ok=lambda n: self._finish(f"{p.name}을(를) 지웠어요."))
            return
        self.busy("지우면 무엇이 함께 지워지는지 확인하는 중…")
        self.start(lambda job, pkg: plan_removal(pkg), p.package, ok=lambda plan: self._confirm_remove(p, plan))

    def _confirm_remove(self, p, plan):
        self.idle()
        if not plan.ok:
            QMessageBox.warning(self, TITLE, f"{p.name}을(를) 지울 수 없어요.\n\n{plan.blocked}")
            return
        others = [x for x in plan.packages if x != p.package]
        text = f"<b>{p.name}</b>을(를) 지울까요?"
        if others:
            text += "<br><br>함께 지워지는 것:<br>" + "<br>".join(f"• {x}" for x in others)
        text += "<br><br>관리자 암호를 물어봐요. 지운 뒤에는 되돌릴 수 없어요 (다시 설치는 가능)."
        if QMessageBox.question(self, TITLE, text) != QMessageBox.StandardButton.Yes:
            return
        self.busy(f"{p.name} 지우는 중…")
        self.start(pk_remove, [p.package],
                   ok=lambda n: self._finish(f"{p.name}을(를) 지웠어요."))

    def _trash_file(self, p):
        text = (f"<b>{p.name}</b>을(를) 휴지통으로 옮길까요?<br><br>{p.package}<br><br>"
                "휴지통에서 언제든 되살릴 수 있어요. 이 파일을 쓰던 기능은 멈출 수 있어요.")
        if QMessageBox.question(self, TITLE, text) != QMessageBox.StandardButton.Yes:
            return
        try:
            from aios.platform.linux import LinuxPlatform
            LinuxPlatform().trash(Path(p.package))
        except Exception as e:   # noqa: BLE001
            QMessageBox.warning(self, TITLE, f"옮기지 못했어요: {e}")
            return
        self._finish(f"{p.name}을(를) 휴지통으로 옮겼어요.")

    def _finish(self, msg: str):
        self.idle()
        self.reload()
        self.status.setText(msg)
        QMessageBox.information(self, TITLE, msg)

    # 업데이트 탭
    def _build_updates(self) -> QWidget:
        w = QWidget()
        self.up_info = QLabel("‘업데이트 확인’을 누르면 새 버전이 있는지 찾아요.\n"
                              "(보안 업데이트는 지금처럼 매일 자동으로 설치돼요.)")
        self.up_info.setWordWrap(True)
        self.up_list = QListWidget()
        self.up_list.setIconSize(QSize(24, 24))
        self.check_btn = QPushButton(QIcon.fromTheme("view-refresh"), "업데이트 확인")
        self.check_btn.clicked.connect(self.check_updates)
        self.update_btn = QPushButton(QIcon.fromTheme("system-software-update"), "모두 업데이트")
        self.update_btn.setEnabled(False)
        self.update_btn.clicked.connect(self.update_all)
        btns = QHBoxLayout()
        btns.addWidget(self.check_btn)
        btns.addStretch(1)
        btns.addWidget(self.update_btn)
        lay = QVBoxLayout(w)
        lay.addWidget(self.up_info)
        lay.addWidget(self.up_list)
        lay.addLayout(btns)
        return w

    def check_updates(self):
        self.busy("업데이트 확인 중…")
        self.start(check_all_updates, ok=self._show_updates)

    def _n_updates(self) -> int:
        return len(self.updates.get("deb", [])) + len(self.updates.get("flatpak", [])) if self.updates else 0

    def _show_updates(self, ups):
        self.idle()
        self.updates = ups
        self.up_list.clear()
        debs = {p.package: p for p in self.programs if p.kind == "deb"}
        flats = {p.package: p for p in self.programs if p.kind == "flatpak"}
        rows = [(debs[n], v) for n, v, _ in ups["deb"] if n in debs]
        rows += [(flats[a], v) for a, v, _ in ups["flatpak"] if a in flats]
        total = self._n_updates()
        parts = total - len(rows)
        for p, v in sorted(rows, key=lambda x: x[0].name.lower()):
            where = "  (Flathub)" if p.kind == "flatpak" else ""
            self.up_list.addItem(QListWidgetItem(_icon(p.icon), f"{p.name}   {p.version} → {v}{where}"))
        if parts:
            self.up_list.addItem(QListWidgetItem(QIcon.fromTheme("package-x-generic"), f"시스템 부품 {parts}개"))
        now = time.strftime("%H:%M")
        if total:
            self.up_info.setText(f"업데이트 {total}개 (프로그램 {len(rows)}개, 시스템 부품 {parts}개) — {now} 확인")
        else:
            self.up_info.setText(f"모두 최신이에요. — {now} 확인")
        if ups.get("error"):
            self.up_info.setText(self.up_info.text() + f"\n※ 일반 프로그램 업데이트 확인 실패: {ups['error']}")
        self.update_btn.setEnabled(bool(total))

    def update_all(self):
        total = self._n_updates()
        if not total:
            return
        if QMessageBox.question(self, TITLE, f"업데이트 {total}개를 설치할까요?\n관리자 암호를 물어봐요.") \
                != QMessageBox.StandardButton.Yes:
            return
        self.busy("업데이트하는 중… (몇 분 걸릴 수 있어요)")
        self.start(update_all_job, self.updates, ok=self._updated)

    def _updated(self, n):
        self.idle()
        self.reload()
        self.updates = {}
        self.up_list.clear()
        self.update_btn.setEnabled(False)
        self.up_info.setText(f"업데이트 {n}개를 설치했어요. 몇몇은 컴퓨터를 다시 시작해야 적용돼요.")
        QMessageBox.information(self, TITLE, f"업데이트 {n}개를 설치했어요.")

    # 공통: 작업 진행
    def start(self, fn, *args, ok):
        # 결과는 반드시 화면(Window)의 메서드로 받는다 → 화면 쪽 스레드에서 처리됨
        thread = QThread(self)
        job = Job(fn, *args, ok=ok)
        job.moveToThread(thread)
        thread.started.connect(job.run)
        job.progress.connect(self.on_progress)
        job.done.connect(self.on_done)
        job.failed.connect(self.on_failed)
        for sig in (job.done, job.failed):
            sig.connect(thread.quit)
        thread.finished.connect(self.on_thread_finished)
        self._threads.append((thread, job))
        thread.start()

    def on_done(self, job, result):
        job.ok(result)

    def on_thread_finished(self):
        self._threads = [(t, j) for t, j in self._threads if t.isRunning()]
        self.on_select()

    def busy(self, msg: str):
        self.status.setText(msg)
        self.bar.setRange(0, 0)
        self.bar.setVisible(True)
        for b in (self.remove_btn, self.check_btn, self.update_btn):
            b.setEnabled(False)

    def idle(self):
        self.bar.setVisible(False)
        self.status.setText("")
        self.check_btn.setEnabled(True)
        self.update_btn.setEnabled(bool(self._n_updates()))
        self.on_select()

    def on_progress(self, pct: int, label: str):
        if pct >= 0:
            self.bar.setRange(0, 100)
            self.bar.setValue(pct)
        self.status.setText(f"{label}…")

    def on_failed(self, msg: str):
        self.idle()
        QMessageBox.warning(self, TITLE, f"작업을 마치지 못했어요.\n\n{msg}")


def main():
    ap = argparse.ArgumentParser(description=TITLE)
    ap.add_argument("--updates", action="store_true", help="업데이트 탭을 열고 바로 확인")
    ap.add_argument("--remove", metavar="PACKAGE", help="이 프로그램을 골라 제거 확인 창 띄우기")
    ap.add_argument("--screenshot", metavar="PNG", help=argparse.SUPPRESS)   # 개발 확인용: 창 그림을 저장하고 끝냄
    ap.add_argument("--tab", type=int, default=0, help=argparse.SUPPRESS)
    args = ap.parse_args()
    app = QApplication(sys.argv)
    app.setApplicationName("manito-programs")
    app.setApplicationDisplayName(TITLE)
    app.setDesktopFileName("manito-programs")
    w = Window(args.updates, args.remove)
    w.show()
    if args.screenshot:
        from PyQt6.QtCore import QTimer
        w.tabs.setCurrentIndex(args.tab)

        def shot():
            w.grab().save(args.screenshot)
            app.quit()
        QTimer.singleShot(1500 if not args.updates else 25000, shot)
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
