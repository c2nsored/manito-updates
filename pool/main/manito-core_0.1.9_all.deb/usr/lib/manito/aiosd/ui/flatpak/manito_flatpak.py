#!/usr/bin/env python3
"""MANITO Flatpak 설치 창 — .flatpak / .flatpakref 파일을 더블클릭하면 열린다.
판단·명령: aios/platform/linux_flatpak_install.py (테스트 있음). 화면: PyQt6 (프로그램 관리 창과 같은 이유로 원칙 8 예외).
사용: manito-flatpak 파일.flatpak
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parent.parent.parent))

from PyQt6.QtCore import QObject, QThread, pyqtSignal  # noqa: E402
from PyQt6.QtGui import QIcon  # noqa: E402
from PyQt6.QtWidgets import (  # noqa: E402
    QApplication, QDialog, QHBoxLayout, QLabel, QMessageBox, QProgressBar, QPushButton, QVBoxLayout,
)

from aios.platform import linux_flatpak_install as fi  # noqa: E402

TITLE = "앱 설치"


def _installed_user_apps() -> set[str]:
    r = subprocess.run(["flatpak", "list", "--user", "--app", "--columns=application"], capture_output=True, text=True)
    return {l.strip() for l in r.stdout.splitlines() if l.strip()}


class Worker(QObject):
    done = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, f: fi.FlatpakFile):
        super().__init__()
        self.f = f

    def run(self):
        env = dict(os.environ, LANG="C", LC_ALL="C")
        try:
            before = _installed_user_apps()
            subprocess.run(fi.flathub_remote_command(), capture_output=True, env=env)
            r = subprocess.run(fi.install_command(self.f), capture_output=True, text=True, env=env)
            if r.returncode != 0:
                msg = (r.stderr.strip().splitlines() or ["설치 실패"])[-1]
                if "already installed" in msg:
                    msg = "이미 설치되어 있어요."
                raise RuntimeError(msg)
            __import__("aios.platform.linux", fromlist=["rebuild_menu"]).rebuild_menu()
            self.done.emit(fi.new_apps(before, _installed_user_apps()))
        except FileNotFoundError:
            self.failed.emit("Flatpak이 설치되어 있지 않아요.")
        except Exception as e:   # noqa: BLE001
            self.failed.emit(str(e))


class Dialog(QDialog):
    def __init__(self, f: fi.FlatpakFile):
        super().__init__()
        self.f = f
        self.setWindowTitle(TITLE)
        self.setWindowIcon(QIcon.fromTheme("system-software-install"))
        self.setMinimumWidth(480)
        text = f"<b>{f.name}</b>을(를) 설치할까요?<br><br>"
        if f.kind == "ref":
            text += f"받아 오는 곳: {f.source}<br>"
            if not f.trusted:
                text += ("<b style='color:#c0392b'>⚠ Flathub 공식 저장소가 아닌 곳이에요. "
                         "믿을 수 있는 곳에서 받은 파일일 때만 설치하세요.</b><br>")
        text += ("<span style='color:gray'>나만 쓰도록 설치해요 (관리자 암호 필요 없음). "
                 "처음엔 실행에 필요한 공통 부품도 함께 받아서 몇 분 걸릴 수 있어요.</span>")
        self.msg = QLabel(text)
        self.msg.setWordWrap(True)
        self.bar = QProgressBar()
        self.bar.setRange(0, 0)
        self.bar.setVisible(False)
        self.ok = QPushButton(QIcon.fromTheme("run-install"), "설치")
        self.ok.setDefault(True)
        self.ok.clicked.connect(self.install)
        self.cancel = QPushButton("취소")
        self.cancel.clicked.connect(self.reject)
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(self.cancel)
        row.addWidget(self.ok)
        lay = QVBoxLayout(self)
        lay.addWidget(self.msg)
        lay.addWidget(self.bar)
        lay.addLayout(row)

    def install(self):
        self.ok.setEnabled(False)
        self.cancel.setEnabled(False)
        self.bar.setVisible(True)
        self.msg.setText(f"{self.f.name} 설치하는 중… (처음엔 몇 분 걸릴 수 있어요)")
        self.thread = QThread(self)
        self.worker = Worker(self.f)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.done.connect(self.on_done)
        self.worker.failed.connect(self.on_failed)
        for s in (self.worker.done, self.worker.failed):
            s.connect(self.thread.quit)
        self.thread.start()

    def on_done(self, apps):
        self.bar.setVisible(False)
        QMessageBox.information(self, TITLE, f"<b>{self.f.name}</b> 설치를 마쳤어요.<br><br>"
                                "시작 메뉴에서 찾아 실행하세요. 지우거나 업데이트하려면 '프로그램 관리'에서 할 수 있어요.")
        self.accept()

    def on_failed(self, text):
        self.bar.setVisible(False)
        QMessageBox.warning(self, TITLE, f"설치하지 못했어요.\n\n{text}")
        self.reject()


def main():
    app = QApplication(sys.argv)
    app.setApplicationDisplayName(TITLE)
    app.setDesktopFileName("manito-flatpak")
    if len(sys.argv) < 2:
        QMessageBox.warning(None, TITLE, "설치할 파일이 없어요.")
        sys.exit(2)
    try:
        f = fi.inspect(Path(sys.argv[1]).expanduser())
    except (OSError, ValueError) as e:
        QMessageBox.warning(None, TITLE, f"설치할 수 없는 파일이에요.\n\n{e}")
        sys.exit(1)
    d = Dialog(f)
    d.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
