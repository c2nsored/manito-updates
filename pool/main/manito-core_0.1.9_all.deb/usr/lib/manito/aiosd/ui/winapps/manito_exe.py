#!/usr/bin/env python3
"""MANITO 윈도우 프로그램 실행기 — .exe/.msi를 더블클릭하면 열리는 창.

사용자는 Wine을 몰라도 된다: 설치 파일이면 이 프로그램 전용 공간을 만들고(한국어 글꼴·입력 준비)
설치를 진행한 뒤, 시작 메뉴에 생긴 바로가기를 알려 준다. 이미 설치된 프로그램 공간 안의 .exe면 그냥 실행.
판단·경로: aios/platform/linux_winapps.py (테스트 있음). 화면: PyQt6 (프로그램 관리 창과 같은 이유로 원칙 8 예외).

사용: manito-exe 파일.exe
"""
from __future__ import annotations

import subprocess
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parent.parent.parent))

from PyQt6.QtCore import QObject, Qt, QThread, pyqtSignal  # noqa: E402
from PyQt6.QtGui import QIcon  # noqa: E402
from PyQt6.QtWidgets import (  # noqa: E402
    QApplication, QDialog, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QProgressBar, QPushButton, QVBoxLayout,
)

from aios.platform import linux_winapps as wa  # noqa: E402

TITLE = "윈도우 프로그램"


def run_wine(args: list[str], prefix: Path, quiet_boot: bool = False, wait: bool = True):
    env = wa.wine_env(prefix, quiet_boot=quiet_boot)
    if wait:
        return subprocess.run(args, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                              stderr=subprocess.DEVNULL).returncode
    subprocess.Popen(args, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     start_new_session=True)
    return 0


class Installer(QObject):
    step = pyqtSignal(str)
    done = pyqtSignal(object)     # 바로가기 목록
    failed = pyqtSignal(str)

    def __init__(self, app: wa.WinApp, installer: Path):
        super().__init__()
        self.app, self.installer = app, installer

    def run(self):
        try:
            prefix = wa.root() / self.app.slug
            prefix.mkdir(parents=True, exist_ok=True)
            self.step.emit("윈도우 프로그램을 돌릴 공간을 만드는 중… (처음 한 번, 1~2분)")
            run_wine(["wineboot", "-i"], prefix, quiet_boot=True)
            self.step.emit("한국어 글꼴을 맞추는 중…")
            with tempfile.NamedTemporaryFile("w", suffix=".reg", delete=False, encoding="utf-8") as f:
                f.write(wa.font_reg())
                reg = f.name
            run_wine(["wine", "regedit", "/S", reg], prefix)
            Path(reg).unlink(missing_ok=True)
            wa.add_app(self.app)       # 설치 도중에 꺼져도 프로그램 관리 창에서 지울 수 있게 먼저 기록
            verbs = wa.fixes_for(self.app.slug)
            if verbs:
                self.step.emit(f"{self.app.name}에 필요한 윈도우 부품을 Microsoft에서 받아 넣는 중… (처음엔 몇 분)")
                run_wine(wa.winetricks_command(verbs), prefix)
            self.step.emit(f"{self.app.name} 설치 창을 띄웠어요. 설치 창의 안내대로 진행해 주세요.")
            run_wine(wa.install_command(self.installer), prefix)
            self.step.emit("설치 마무리 확인 중…")
            links = []
            for _ in range(20):        # 바로가기는 설치 창이 닫힌 뒤 조금 늦게 생길 수 있음
                links = wa.shortcuts(prefix)
                if links:
                    break
                time.sleep(1)
            if links:
                links = wa.adopt_shortcuts(self.app.slug) or links   # 'Wine' 하위 폴더 없이 시작 메뉴에 바로
            __import__("aios.platform.linux", fromlist=["rebuild_menu"]).rebuild_menu()
            self.done.emit(links)
        except FileNotFoundError:
            self.failed.emit("윈도우 프로그램 실행 도구(Wine)가 설치되어 있지 않아요.")
        except Exception as e:   # noqa: BLE001
            self.failed.emit(str(e))


class Dialog(QDialog):
    def __init__(self, path: Path):
        super().__init__()
        self.path = path
        self.app = wa.new_app(path.name)
        self.setWindowTitle(TITLE)
        self.setWindowIcon(QIcon.fromTheme("wine", QIcon.fromTheme("application-x-ms-dos-executable")))
        self.setMinimumWidth(460)
        self.msg = QLabel(f"<b>{path.name}</b><br><br>윈도우용 프로그램이에요. 마니또에 설치할까요?<br>"
                          "<span style='color:gray'>대부분의 프로그램은 잘 돌아가지만, 일부는 리눅스에서 "
                          "제대로 동작하지 않을 수 있어요.</span>")
        self.msg.setWordWrap(True)
        why = wa.broken_reason(self.app.slug)
        if why:
            self.msg.setText(self.msg.text() + f"<br><br><b style='color:#c0392b'>⚠ {why}</b><br>"
                             "휴대폰 앱이나 윈도우에서 쓰는 것을 권해요. 그래도 시도해 볼 수는 있어요.")
        self.name = QLineEdit(self.app.name)
        name_row = QHBoxLayout()
        name_row.addWidget(QLabel("이름:"))
        name_row.addWidget(self.name, 1)
        self.bar = QProgressBar()
        self.bar.setRange(0, 0)
        self.bar.setVisible(False)
        self.install_btn = QPushButton(QIcon.fromTheme("run-install"), "설치")
        self.install_btn.setDefault(True)
        self.install_btn.clicked.connect(self.install)
        self.cancel_btn = QPushButton("취소")
        self.cancel_btn.clicked.connect(self.reject)
        btns = QHBoxLayout()
        btns.addStretch(1)
        btns.addWidget(self.cancel_btn)
        btns.addWidget(self.install_btn)
        lay = QVBoxLayout(self)
        lay.addWidget(self.msg)
        lay.addLayout(name_row)
        lay.addWidget(self.bar)
        lay.addLayout(btns)
        self.thread = None

    def install(self):
        self.app.name = self.name.text().strip() or self.app.name
        self.name.setEnabled(False)
        self.install_btn.setEnabled(False)
        self.cancel_btn.setEnabled(False)
        self.bar.setVisible(True)
        self.thread = QThread(self)
        self.worker = Installer(self.app, self.path)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.step.connect(self.on_step)
        self.worker.done.connect(self.on_done)
        self.worker.failed.connect(self.on_failed)
        for sig in (self.worker.done, self.worker.failed):
            sig.connect(self.thread.quit)
        self.thread.start()

    def on_step(self, text: str):
        self.msg.setText(text)

    def on_done(self, links):
        self.bar.setVisible(False)
        if links:
            names = ", ".join(sorted({wa.desktop_field(l, "Name") or l.stem for l in links}))
            QMessageBox.information(self, TITLE, f"<b>{self.app.name}</b> 설치를 마쳤어요.<br><br>"
                                    f"시작 메뉴에서 <b>{names}</b>을(를) 찾아 실행하세요.<br>"
                                    "지우려면 '프로그램 관리'에서 지울 수 있어요.")
        else:
            QMessageBox.warning(self, TITLE, f"설치 창은 닫혔지만 {self.app.name}의 시작 메뉴 바로가기를 찾지 못했어요.<br><br>"
                                "설치를 취소했거나, 이 프로그램이 리눅스에서 제대로 설치되지 않았을 수 있어요.<br>"
                                "필요 없으면 '프로그램 관리'에서 지울 수 있어요.")
        self.accept()

    def on_failed(self, text: str):
        self.bar.setVisible(False)
        QMessageBox.warning(self, TITLE, f"설치하지 못했어요.\n\n{text}")
        self.reject()


def main():
    if len(sys.argv) < 2:
        print("사용: manito-exe 파일.exe", file=sys.stderr)
        sys.exit(2)
    path = Path(sys.argv[1]).expanduser()
    app = QApplication(sys.argv)
    app.setApplicationDisplayName(TITLE)
    app.setDesktopFileName("manito-exe")
    if not path.is_file():
        QMessageBox.warning(None, TITLE, f"파일을 찾을 수 없어요: {path}")
        sys.exit(1)
    prefix = wa.prefix_of(path)
    if prefix:                                   # 이미 설치된 프로그램의 .exe → 그 공간에서 바로 실행
        run_wine(["wine", str(path)], prefix, wait=False)
        sys.exit(0)
    d = Dialog(path)
    d.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, False)
    d.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
