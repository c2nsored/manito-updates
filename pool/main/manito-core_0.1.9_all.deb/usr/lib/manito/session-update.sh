#!/bin/sh
# 로그인할 때 한 번 실행 (/etc/xdg/autostart/manito-session-update.desktop)
# MANITO가 업데이트되었으면:
#   1) AI 서비스(aiosd)를 새 버전으로 다시 시작
#   2) 화면 배치(위·아래 막대, 바탕화면 위젯)가 새로 나왔으면 알림으로 물어보고, "적용"을 누르면 새 배치로 바꾼다
#      (사용자가 막대를 바꿨을 수 있으니 묻지 않고 바꾸지 않는다)
STATE="${XDG_STATE_HOME:-$HOME/.local/state}/manito"
mkdir -p "$STATE"
# 기록: ~/.local/state/manito/session-update.log (최근 200줄만 유지)
LOG="$STATE/session-update.log"
[ -f "$LOG" ] && tail -n 200 "$LOG" > "$LOG.tmp" && mv "$LOG.tmp" "$LOG"
exec >>"$LOG" 2>&1
echo "── $(date '+%F %T') 로그인"
set -x
cur=$(cat /usr/share/manito/version 2>/dev/null)
old=$(cat "$STATE/version" 2>/dev/null)
lcur=$(cat /usr/share/manito/layout-version 2>/dev/null)
lold=$(cat "$STATE/layout-version" 2>/dev/null)

if [ -n "$cur" ] && [ "$cur" != "$old" ]; then
  systemctl --user daemon-reload 2>/dev/null
  systemctl --user restart aiosd.service 2>/dev/null
  echo "$cur" > "$STATE/version"
  if [ -n "$old" ]; then
    notify-send -a "마니또" -i manito "MANITO가 업데이트되었어요" "$old → $cur" 2>/dev/null
  fi
fi

if [ -z "$lold" ]; then
  # 처음 로그인: 방금 새 배치로 만들어졌으므로 기록만
  echo "$lcur" > "$STATE/layout-version"
elif [ -n "$lcur" ] && [ "$lcur" != "$lold" ]; then
  answer=$(notify-send -a "마니또" -i manito -t 0 --wait \
           --action=apply="새 배치 적용" --action=later="나중에" \
           "새 화면 배치가 나왔어요" \
           "위·아래 막대와 바탕화면을 새 MANITO 배치로 바꿀까요? 직접 바꾼 막대 설정은 처음 상태로 돌아갑니다." 2>/dev/null)
  rc=$?
  if [ "$answer" = "apply" ]; then
    plasma-apply-lookandfeel --apply org.manito.desktop --resetLayout >/dev/null 2>&1
    echo "$lcur" > "$STATE/layout-version"
  elif [ "$answer" = "later" ]; then
    :   # 다음 로그인 때 다시 물어본다
  elif [ "$rc" -eq 0 ]; then
    # 버튼 없이 X로 닫음 = 지금 배치를 그대로 쓰겠다는 뜻으로 보고 이 번호는 다시 묻지 않는다
    # (실기기에서 버튼이 안 보여 닫기만 할 수 있었고, 그 결과 로그인마다 같은 알림이 떴음)
    echo "$lcur" > "$STATE/layout-version"
  fi   # 알림을 못 띄움(rc≠0)·로그아웃으로 끊김 → 다음 로그인 때 다시
fi
exit 0
