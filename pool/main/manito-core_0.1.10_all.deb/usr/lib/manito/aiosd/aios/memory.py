"""장기 기억 저장소 (SQLite).

AI 모델이 꺼져도, 시스템을 재시작해도 대화·승인 기록·작업 상태가 남는다.
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time
import uuid
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY,
    title TEXT,
    created REAL NOT NULL,
    updated REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id TEXT NOT NULL REFERENCES conversations(id),
    role TEXT NOT NULL,            -- user / assistant / tool / system
    content TEXT NOT NULL,
    meta TEXT,                     -- JSON (어떤 도구·모델을 썼는지 등)
    created REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conversation_id, id);
CREATE TABLE IF NOT EXISTS approvals (
    id TEXT PRIMARY KEY,
    conversation_id TEXT,
    tool TEXT NOT NULL,
    args TEXT NOT NULL,            -- JSON
    risk TEXT NOT NULL,
    reason TEXT,
    status TEXT NOT NULL,          -- pending / approved / denied / cancelled
    created REAL NOT NULL,
    decided REAL
);
CREATE TABLE IF NOT EXISTS kv (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated REAL NOT NULL
);
"""


class Memory:
    def __init__(self, path: str | Path):
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._db = sqlite3.connect(self.path, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.executescript(SCHEMA)
        self._db.commit()

    def close(self):
        with self._lock:
            self._db.close()

    # ── 대화 ──
    def new_conversation(self, title: str = "") -> str:
        cid = uuid.uuid4().hex[:12]
        now = time.time()
        with self._lock:
            self._db.execute(
                "INSERT INTO conversations VALUES (?,?,?,?)", (cid, title, now, now)
            )
            self._db.commit()
        return cid

    def conversation_exists(self, cid: str) -> bool:
        with self._lock:
            r = self._db.execute("SELECT 1 FROM conversations WHERE id=?", (cid,)).fetchone()
        return r is not None

    def add_message(self, cid: str, role: str, content: str, meta: dict | None = None) -> int:
        now = time.time()
        with self._lock:
            cur = self._db.execute(
                "INSERT INTO messages(conversation_id, role, content, meta, created) VALUES (?,?,?,?,?)",
                (cid, role, content, json.dumps(meta, ensure_ascii=False) if meta else None, now),
            )
            self._db.execute("UPDATE conversations SET updated=? WHERE id=?", (now, cid))
            self._db.commit()
            return cur.lastrowid

    def messages(self, cid: str, limit: int | None = None) -> list[dict]:
        q = "SELECT id, role, content, meta, created FROM messages WHERE conversation_id=? ORDER BY id DESC"
        params: tuple = (cid,)
        if limit:
            q += " LIMIT ?"
            params = (cid, limit)
        with self._lock:
            rows = self._db.execute(q, params).fetchall()
        out = []
        for r in reversed(rows):
            out.append({
                "id": r["id"],
                "role": r["role"],
                "content": r["content"],
                "meta": json.loads(r["meta"]) if r["meta"] else None,
                "created": r["created"],
            })
        return out

    def message(self, cid: str, mid: int) -> dict | None:
        with self._lock:
            r = self._db.execute(
                "SELECT id, role, content, created FROM messages WHERE conversation_id=? AND id=?", (cid, mid)
            ).fetchone()
        return dict(r) if r else None

    def delete_messages_from(self, cid: str, mid: int) -> int:
        """대화에서 mid번 메시지와 그 뒤 메시지를 모두 지운다 (다시 생성·편집해서 다시 보내기).

        지워진 메시지 이후에 생긴, 아직 처리 안 된 승인 요청도 취소한다 (보이지 않는 승인이 남지 않게)."""
        with self._lock:
            r = self._db.execute(
                "SELECT created FROM messages WHERE conversation_id=? AND id=?", (cid, mid)
            ).fetchone()
            if not r:
                return 0
            cur = self._db.execute("DELETE FROM messages WHERE conversation_id=? AND id>=?", (cid, mid))
            self._db.execute(
                "UPDATE approvals SET status='cancelled', decided=? "
                "WHERE conversation_id=? AND status='pending' AND created>=?",
                (time.time(), cid, r["created"]),
            )
            self._db.commit()
            return cur.rowcount

    def conversations(self, limit: int = 50) -> list[dict]:
        with self._lock:
            rows = self._db.execute(
                "SELECT id, title, created, updated FROM conversations ORDER BY updated DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [dict(r) for r in rows]

    def search_messages(self, text: str, limit: int = 20) -> list[dict]:
        """단순 문자열 검색 (Phase 3에서 의미 기반 검색으로 확장 예정)."""
        with self._lock:
            rows = self._db.execute(
                "SELECT conversation_id, role, content, created FROM messages "
                "WHERE content LIKE ? ORDER BY id DESC LIMIT ?",
                (f"%{text}%", limit),
            ).fetchall()
        return [dict(r) for r in rows]

    # ── 승인 ──
    def add_approval(self, cid: str | None, tool: str, args: dict, risk: str, reason: str) -> str:
        aid = uuid.uuid4().hex[:12]
        with self._lock:
            self._db.execute(
                "INSERT INTO approvals VALUES (?,?,?,?,?,?,?,?,?)",
                (aid, cid, tool, json.dumps(args, ensure_ascii=False), risk, reason,
                 "pending", time.time(), None),
            )
            self._db.commit()
        return aid

    def get_approval(self, aid: str) -> dict | None:
        with self._lock:
            r = self._db.execute("SELECT * FROM approvals WHERE id=?", (aid,)).fetchone()
        if not r:
            return None
        d = dict(r)
        d["args"] = json.loads(d["args"])
        return d

    def pending_approvals(self) -> list[dict]:
        with self._lock:
            rows = self._db.execute(
                "SELECT * FROM approvals WHERE status='pending' ORDER BY created"
            ).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["args"] = json.loads(d["args"])
            out.append(d)
        return out

    def decide_approval(self, aid: str, status: str) -> bool:
        """pending 상태일 때만 바꾼다. 바뀌었으면 True."""
        with self._lock:
            cur = self._db.execute(
                "UPDATE approvals SET status=?, decided=? WHERE id=? AND status='pending'",
                (status, time.time(), aid),
            )
            self._db.commit()
            return cur.rowcount == 1

    def cancel_all_approvals(self) -> int:
        with self._lock:
            cur = self._db.execute(
                "UPDATE approvals SET status='cancelled', decided=? WHERE status='pending'",
                (time.time(),),
            )
            self._db.commit()
            return cur.rowcount

    # ── 상태 저장 (작업 상태, 게임 모드 등) ──
    def set_state(self, key: str, value) -> None:
        with self._lock:
            self._db.execute(
                "INSERT INTO kv VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated=excluded.updated",
                (key, json.dumps(value, ensure_ascii=False), time.time()),
            )
            self._db.commit()

    def get_state(self, key: str, default=None):
        with self._lock:
            r = self._db.execute("SELECT value FROM kv WHERE key=?", (key,)).fetchone()
        return json.loads(r["value"]) if r else default
