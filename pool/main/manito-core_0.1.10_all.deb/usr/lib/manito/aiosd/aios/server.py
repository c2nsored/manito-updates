"""aiosd HTTP API + 채팅 화면 제공.

127.0.0.1 전용. 다른 웹사이트가 브라우저를 통해 이 API를 호출하지 못하도록 Host/Origin을 검사한다.
"""
from __future__ import annotations

import json
import logging
import re
import threading
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from .agent import BadReplace
from .core import AIOS
from .tools.system import collect_status

log = logging.getLogger("aios.server")
UI_DIR = Path(__file__).resolve().parent.parent / "ui"
MAX_BODY = 1_000_000


def make_handler(aios: AIOS, port: int):
    allowed_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
    allowed_origins = {f"http://{h}" for h in allowed_hosts}

    class Handler(BaseHTTPRequestHandler):
        server_version = "aiosd/0.1"

        def log_message(self, fmt, *args):
            log.info("%s - %s", self.address_string(), fmt % args)

        # ── 공통 ──
        def _guard(self) -> bool:
            if self.headers.get("Host", "") not in allowed_hosts:
                self._json({"error": "허용되지 않은 Host"}, HTTPStatus.FORBIDDEN)
                return False
            origin = self.headers.get("Origin")
            if origin and origin not in allowed_origins:
                self._json({"error": "허용되지 않은 Origin"}, HTTPStatus.FORBIDDEN)
                return False
            return True

        def _json(self, obj, status=HTTPStatus.OK):
            body = json.dumps(obj, ensure_ascii=False, default=str).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def _body(self) -> dict | None:
            if "application/json" not in self.headers.get("Content-Type", ""):
                self._json({"error": "Content-Type은 application/json 이어야 합니다"}, HTTPStatus.UNSUPPORTED_MEDIA_TYPE)
                return None
            n = int(self.headers.get("Content-Length") or 0)
            if n > MAX_BODY:
                self._json({"error": "요청이 너무 큽니다"}, HTTPStatus.REQUEST_ENTITY_TOO_LARGE)
                return None
            try:
                data = json.loads(self.rfile.read(n) or b"{}")
            except json.JSONDecodeError:
                self._json({"error": "JSON 형식 오류"}, HTTPStatus.BAD_REQUEST)
                return None
            if not isinstance(data, dict):
                self._json({"error": "JSON 객체가 필요합니다"}, HTTPStatus.BAD_REQUEST)
                return None
            return data

        # ── GET ──
        def do_GET(self):
            if not self._guard():
                return
            path = self.path.split("?", 1)[0]
            if path in ("/", "/index.html"):
                f = UI_DIR / "index.html"
                body = f.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Content-Security-Policy",
                                 "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'")
                self.end_headers()
                self.wfile.write(body)
            elif path == "/api/status":
                self._json(collect_status(aios.ctx))
            elif path == "/api/conversations":
                self._json(aios.memory.conversations())
            elif m := re.fullmatch(r"/api/conversations/([0-9a-f]{1,32})/messages", path):
                self._json(aios.memory.messages(m.group(1)))
            elif path == "/api/approvals":
                self._json(aios.memory.pending_approvals())
            elif path == "/api/tools":
                self._json([{"name": t.name, "description": t.description, "risk": t.risk,
                             "parameters": t.parameters} for t in aios.registry.all()])
            elif path == "/api/health":
                self._json({"ok": True})
            elif path == "/api/ai-state":
                self._json(aios.status.snapshot())   # 화면의 AI 오브가 주기적으로 읽어 감
            else:
                self._json({"error": "없는 주소"}, HTTPStatus.NOT_FOUND)

        # ── POST ──
        def do_POST(self):
            if not self._guard():
                return
            path = self.path.split("?", 1)[0]
            data = self._body()
            if data is None:
                return
            if path == "/api/chat":
                text = str(data.get("message", "")).strip()
                if not text:
                    return self._json({"error": "메시지가 비어 있습니다"}, HTTPStatus.BAD_REQUEST)
                rf = data.get("replace_from")
                if rf is not None and (not isinstance(rf, int) or isinstance(rf, bool)):
                    return self._json({"error": "replace_from은 메시지 번호(정수)여야 합니다"}, HTTPStatus.BAD_REQUEST)
                try:
                    self._json(aios.agent.handle(text, data.get("conversation_id"), replace_from=rf))
                except BadReplace as e:
                    self._json({"error": str(e)}, HTTPStatus.BAD_REQUEST)
            elif path == "/api/locked-chat":
                # 잠금·로그인 화면 입력칸: 허용된 몇 가지 명령만, 기록 저장 없음
                text = str(data.get("message", "")).strip()[:500]
                if not text:
                    return self._json({"error": "메시지가 비어 있습니다"}, HTTPStatus.BAD_REQUEST)
                self._json(aios.agent.handle_locked(text))
            elif m := re.fullmatch(r"/api/approvals/([0-9a-f]{1,32})", path):
                self._json(aios.agent.decide(m.group(1), bool(data.get("approve"))))
            elif m := re.fullmatch(r"/api/models/([\w.-]+)/(load|unload)", path):
                name, action = m.groups()
                if action == "unload":
                    self._json({"ok": aios.models.unload(name)})
                else:
                    from .models import ModelUnavailable
                    try:
                        aios.models.ensure(name)
                        self._json({"ok": True})
                    except ModelUnavailable as e:
                        self._json({"ok": False, "error": str(e)})
            elif path == "/api/game-mode":
                on = bool(data.get("on"))
                self._json({"game_mode": on, "unloaded": aios.models.set_game_mode(on)})
            elif path == "/api/emergency-stop":
                self._json(aios.emergency_stop())
            elif path == "/api/ai-state":
                # 다른 로컬 프로그램(백그라운드 작업 등)이 AI 상태를 알릴 때 사용
                try:
                    hold = data.get("hold")
                    aios.status.set(str(data.get("state", "")), float(hold) if hold is not None else None)
                except (ValueError, TypeError) as e:
                    return self._json({"error": str(e)}, HTTPStatus.BAD_REQUEST)
                self._json(aios.status.snapshot())
            else:
                self._json({"error": "없는 주소"}, HTTPStatus.NOT_FOUND)

    return Handler


def serve(aios: AIOS, host: str = "127.0.0.1", port: int = 8765) -> ThreadingHTTPServer:
    if host not in ("127.0.0.1", "localhost", "::1"):
        raise ValueError("보안을 위해 aiosd는 로컬 주소에서만 실행합니다")
    httpd = ThreadingHTTPServer((host, port), make_handler(aios, port))
    httpd.daemon_threads = True
    return httpd


def run_forever(aios: AIOS, host: str, port: int) -> None:
    httpd = serve(aios, host, port)
    aios.models.start_watcher()
    log.info("aiosd 시작: http://%s:%d", host, port)
    print(f"aiosd 실행 중 → 브라우저에서 http://{host}:{port} 를 여세요 (종료: Ctrl+C)", flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
        aios.close()


def serve_in_thread(aios: AIOS, port: int = 0) -> tuple[ThreadingHTTPServer, threading.Thread]:
    """테스트용: 백그라운드 스레드에서 서버 실행."""
    httpd = ThreadingHTTPServer(("127.0.0.1", port), None)  # type: ignore[arg-type]
    real_port = httpd.server_address[1]
    httpd.RequestHandlerClass = make_handler(aios, real_port)
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    return httpd, t
