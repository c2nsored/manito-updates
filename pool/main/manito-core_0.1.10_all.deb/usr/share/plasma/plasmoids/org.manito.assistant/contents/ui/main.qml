// MANITO 버튼 + 메신저 대화창 (위쪽 막대 왼쪽 끝).
// - 막대에는 작은 오브와 MANITO 글자. 누르거나 Meta+Space로 대화창이 열린다.
// - 대화창: 왼쪽은 지난 대화 목록(+ 새 대화), 오른쪽은 말풍선과 입력칸.
//   말풍선 아래 메뉴: AI 답 = 복사·다시 생성, 내 메시지 = 복사·편집(고쳐서 다시 보내기).
// - 오른쪽 위 '창으로 열기': 같은 대화창을 독립된 프로그램 창으로 띄움
//   (manito-chat.desktop → KDE 기본 도구 plasmawindowed가 이 위젯을 창으로 실행, 한 개만 뜸).
// - AI 서비스(aiosd, http://127.0.0.1:8765)의 대화 기록을 그대로 보여 주므로, 바탕화면 입력칸·알림 답장에서
//   나눈 대화도 여기에 함께 쌓인다. 서비스가 꺼져 있어도 바탕화면은 정상 동작 (설계 원칙 1).
import QtQuick
import QtQuick.Layouts
import QtQuick.Controls as QQC2
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.components as PlasmaComponents
import org.kde.kirigami as Kirigami
import org.kde.plasma.plasma5support as P5Support
import "file:///usr/share/manito/qml/Manito"

PlasmoidItem {
    id: root

    readonly property string api: "http://127.0.0.1:8765"
    readonly property var stateText: ({ idle: "대기 중", thinking: "생각 중…", working: "작업 중…",
                                        complete: "완료", error: "문제가 생겼어요", disabled: "AI 서비스 꺼짐" })
    property string conversationId: ""
    property bool busy: false
    property var pendingApprovals: ({})
    property int editingIndex: -1     // 편집 중인 내 메시지 (-1 = 없음)
    // 독립 창(plasmawindowed)으로 실행되면 막대(Horizontal)가 아니라 Application
    readonly property bool windowed: Plasmoid.formFactor === PlasmaCore.Types.Application

    ListModel { id: conversations }   // { cid, title, when }
    ListModel { id: messages }        // { who: "user"|"ai"|"note", text, approvalId, msgId(aiosd 번호, 모르면 -1) }
    ManitoAiLink { id: link; active: true; interval: 800 }

    Plasmoid.icon: "manito"
    toolTipMainText: "마니또"
    toolTipSubText: stateText[link.state] || ""
    preferredRepresentation: windowed ? fullRepresentation : compactRepresentation

    onExpandedChanged: if (root.expanded) refresh()
    Component.onCompleted: if (windowed) refresh()

    // 클립보드에 넣기 (QML에는 클립보드 함수가 없어 보이지 않는 글상자로 복사)
    TextEdit { id: clipHelper; visible: false }
    function copyText(t) { clipHelper.text = t; clipHelper.selectAll(); clipHelper.copy(); clipHelper.text = "" }

    // 독립 창 열기: kstart가 바로가기(manito-chat.desktop)를 실행 → 대화창이 plasmashell과 별개 프로그램으로 뜸
    P5Support.DataSource {
        id: launcher
        engine: "executable"
        onNewData: function (source) { disconnectSource(source) }
    }
    function openWindow() {
        launcher.connectSource("kstart --application manito-chat")
        root.expanded = false
    }

    // ── AI 서비스와 주고받기 ──
    function request(method, path, body, done) {
        var xhr = new XMLHttpRequest()
        xhr.onreadystatechange = function () {
            if (xhr.readyState !== XMLHttpRequest.DONE) return
            var out = null
            try { out = JSON.parse(xhr.responseText) } catch (e) {}
            done(xhr.status === 200 ? out : null)
        }
        xhr.open(method, api + path)
        if (body !== undefined) xhr.setRequestHeader("Content-Type", "application/json")
        xhr.send(body !== undefined ? JSON.stringify(body) : null)
    }

    function when(sec) {
        var d = new Date(sec * 1000), now = new Date()
        if (d.toDateString() === now.toDateString()) return Qt.formatTime(d, "hh:mm")
        var y = new Date(now); y.setDate(now.getDate() - 1)
        if (d.toDateString() === y.toDateString()) return "어제"
        return (d.getMonth() + 1) + "월 " + d.getDate() + "일"
    }

    function refresh(keep) {
        request("GET", "/api/approvals", undefined, function (list) {
            var p = {}
            for (var i = 0; list && i < list.length; i++) p[list[i].id] = true
            pendingApprovals = p
            request("GET", "/api/conversations", undefined, function (convs) {
                conversations.clear()
                for (var j = 0; convs && j < convs.length; j++)
                    conversations.append({ cid: convs[j].id, title: convs[j].title || "대화", when: when(convs[j].updated) })
                if (!conversationId && conversations.count > 0) conversationId = conversations.get(0).cid
                loadMessages(keep)
            })
        })
    }

    // keep: 지금 목록을 남겨 둔 채 새 내용으로 바꿈 (보낸 뒤 번호를 받아올 때 화면이 깜빡이지 않게)
    function loadMessages(keep) {
        if (!keep) { messages.clear(); editingIndex = -1 }
        if (!conversationId) return
        request("GET", "/api/conversations/" + conversationId + "/messages", undefined, function (list) {
            if (!list) return
            messages.clear()
            editingIndex = -1
            for (var i = 0; i < list.length; i++) {
                var m = list[i], aid = (m.meta && m.meta.approval_id) || ""
                messages.append({ who: m.role === "user" ? "user" : "ai", text: m.content,
                                  approvalId: pendingApprovals[aid] ? aid : "", msgId: m.id || -1 })
            }
        })
    }

    function newConversation() { conversationId = ""; messages.clear(); editingIndex = -1 }

    // replaceIndex: 이 자리의 내 메시지부터 뒤를 지우고 text로 다시 보냄 (다시 생성·편집). 보통은 -1.
    function send(text, replaceIndex) {
        text = text.trim()
        if (!text || busy) return
        var body = { message: text, conversation_id: conversationId || null }
        if (replaceIndex !== undefined && replaceIndex >= 0) {
            var mid = messages.get(replaceIndex).msgId
            if (mid < 0) return
            body.replace_from = mid
            messages.remove(replaceIndex, messages.count - replaceIndex)
        }
        editingIndex = -1
        messages.append({ who: "user", text: text, approvalId: "", msgId: -1 })
        busy = true
        request("POST", "/api/chat", body, function (out) {
            busy = false
            if (out) {
                conversationId = out.conversation_id || conversationId
                messages.append({ who: "ai", text: out.reply || "", approvalId: out.approval_id || "", msgId: -1 })
                refresh(true)   // 메시지 번호(다시 생성·편집에 필요)와 대화 목록을 다시 받아 옴
            } else {
                messages.append({ who: "note", approvalId: "", msgId: -1,
                                  text: "AI 서비스에 연결할 수 없어요. 잠시 뒤 다시 시도해 주세요." })
            }
        })
    }

    // AI 답 다시 생성: 바로 앞의 내 메시지를 같은 내용으로 다시 보냄
    function userIndexBefore(index) {
        for (var i = index - 1; i >= 0; i--)
            if (messages.get(i).who === "user") return i
        return -1
    }
    function regenerate(index) {
        var u = userIndexBefore(index)
        if (u >= 0) send(messages.get(u).text, u)
    }
    // 마지막 AI 답 자리 (목록이 바뀔 때마다 다시 계산 — 이 답에만 '다시 생성'이 보임)
    readonly property int lastAi: { messages.count; return lastAiIndex() }
    function lastAiIndex() {
        for (var i = messages.count - 1; i >= 0; i--)
            if (messages.get(i).who === "ai") return i
        return -1
    }

    function decide(index, approve) {
        var id = messages.get(index).approvalId
        messages.setProperty(index, "approvalId", "")
        request("POST", "/api/approvals/" + id, { approve: approve }, function (out) {
            // 코딩 모드에서는 실행 결과를 본 AI가 이어서 작업하고, 다음 허락을 또 물을 수 있다
            messages.append({ who: "ai", approvalId: (out && out.approval_id) || "", msgId: -1,
                              text: out ? out.reply : "처리하지 못했어요." })
            if (out) refresh(true)
        })
    }

    // ── 위쪽 막대의 MANITO 버튼 ──
    compactRepresentation: MouseArea {
        id: compact
        Layout.minimumWidth: btnRow.implicitWidth + Kirigami.Units.largeSpacing * 2
        Layout.preferredWidth: Layout.minimumWidth
        hoverEnabled: true
        onClicked: root.expanded = !root.expanded
        Accessible.name: "마니또 대화창 열기"
        Accessible.role: Accessible.Button

        Rectangle {
            anchors.fill: parent
            anchors.topMargin: 2; anchors.bottomMargin: 2
            radius: height / 2
            color: Qt.alpha(Kirigami.Theme.textColor, root.expanded ? 0.12 : (compact.containsMouse ? 0.07 : 0))
        }
        Row {
            id: btnRow
            anchors.centerIn: parent
            spacing: 2
            ManitoOrb {
                width: compact.height * 1.05; height: width
                anchors.verticalCenter: parent.verticalCenter
                aiState: root.busy && link.state === "idle" ? "thinking" : link.state
                dark: Kirigami.Theme.textColor.hslLightness > 0.5
            }
            ManitoWordmark {
                anchors.verticalCenter: parent.verticalCenter
                size: Math.max(10, Math.round(compact.height * 0.40))
                color: Kirigami.Theme.textColor
                width: implicitWidth; height: implicitHeight
            }
        }
    }

    // ── 메신저 대화창 ──
    fullRepresentation: Item {
        id: full
        Layout.preferredWidth: Kirigami.Units.gridUnit * 40
        Layout.preferredHeight: Kirigami.Units.gridUnit * 30
        // 독립 창은 처음 크기를 최소 크기로 정하므로 창일 때 더 크게
        Layout.minimumWidth: Kirigami.Units.gridUnit * (root.windowed ? 38 : 28)
        Layout.minimumHeight: Kirigami.Units.gridUnit * (root.windowed ? 30 : 18)

        readonly property color ink: Kirigami.Theme.textColor
        readonly property color hair: Qt.alpha(ink, 0.10)
        readonly property color accent: Kirigami.Theme.textColor.hslLightness > 0.5 ? "#C99478" : "#C98E70"

        Connections {
            target: root
            function onExpandedChanged() { if (root.expanded) input.forceActiveFocus() }
        }
        Component.onCompleted: if (root.windowed) input.forceActiveFocus()

        // 불투명 배경 (KDE 팝업 기본 배경은 반투명이라 뒤 창 글자가 비쳐 보임)
        Rectangle {
            anchors.fill: parent
            anchors.margins: -Kirigami.Units.smallSpacing
            radius: Kirigami.Units.cornerRadius * 2
            color: Kirigami.Theme.backgroundColor
        }

        // 왼쪽: 대화 목록
        Rectangle {
            id: side
            width: Kirigami.Units.gridUnit * 12
            height: parent.height
            color: Qt.alpha(full.ink, 0.03)
            radius: Kirigami.Units.cornerRadius * 2
            Rectangle { anchors.right: parent.right; width: 1; height: parent.height; color: full.hair }

            Item {
                id: sideHead
                x: Kirigami.Units.largeSpacing; width: parent.width - Kirigami.Units.largeSpacing * 2
                height: Kirigami.Units.gridUnit * 2.4
                Kirigami.Heading { level: 4; text: "대화"; anchors.verticalCenter: parent.verticalCenter }
                PlasmaComponents.ToolButton {
                    anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter
                    icon.name: "list-add"
                    PlasmaComponents.ToolTip.text: "새 대화"
                    PlasmaComponents.ToolTip.visible: hovered
                    onClicked: { root.newConversation(); input.forceActiveFocus() }
                }
            }
            ListView {
                anchors.top: sideHead.bottom; anchors.bottom: parent.bottom
                anchors.left: parent.left; anchors.right: parent.right
                anchors.margins: Kirigami.Units.smallSpacing
                clip: true
                spacing: 2
                model: conversations
                delegate: MouseArea {
                    required property string cid
                    required property string title
                    required property string when
                    width: ListView.view.width
                    height: Kirigami.Units.gridUnit * 2.8
                    hoverEnabled: true
                    onClicked: { root.conversationId = cid; root.loadMessages() }
                    Rectangle {
                        anchors.fill: parent
                        radius: Kirigami.Units.cornerRadius * 2
                        color: cid === root.conversationId ? Qt.alpha(full.accent, 0.18)
                                                           : (parent.containsMouse ? Qt.alpha(full.ink, 0.05) : "transparent")
                    }
                    Column {
                        x: Kirigami.Units.largeSpacing; anchors.verticalCenter: parent.verticalCenter
                        width: parent.width - Kirigami.Units.largeSpacing * 2
                        PlasmaComponents.Label { text: title; width: parent.width; elide: Text.ElideRight }
                        PlasmaComponents.Label { text: when; opacity: 0.55; font: Kirigami.Theme.smallFont }
                    }
                }
                PlasmaComponents.Label {
                    anchors.centerIn: parent
                    visible: conversations.count === 0
                    text: "아직 대화가 없어요"
                    opacity: 0.5
                }
            }
        }

        // 오른쪽: 대화 내용 (창일 때는 창 가장자리에 붙지 않게 여백)
        Item {
            anchors.left: side.right; anchors.leftMargin: Kirigami.Units.largeSpacing
            anchors.right: parent.right; anchors.rightMargin: root.windowed ? Kirigami.Units.largeSpacing : 0
            anchors.top: parent.top; anchors.topMargin: root.windowed ? Kirigami.Units.smallSpacing : 0
            anchors.bottom: parent.bottom; anchors.bottomMargin: root.windowed ? Kirigami.Units.largeSpacing : 0

            RowLayout {
                id: head
                width: parent.width
                spacing: Kirigami.Units.smallSpacing
                ManitoOrb {
                    Layout.preferredWidth: Kirigami.Units.gridUnit * 2.6
                    Layout.preferredHeight: Layout.preferredWidth
                    aiState: root.busy && link.state === "idle" ? "thinking" : link.state
                    dark: Kirigami.Theme.textColor.hslLightness > 0.5
                }
                ColumnLayout {
                    spacing: 0
                    Kirigami.Heading { level: 4; text: "마니또" }
                    PlasmaComponents.Label { text: root.stateText[link.state] || ""; opacity: 0.55; font: Kirigami.Theme.smallFont }
                }
                Item { Layout.fillWidth: true }
                PlasmaComponents.ToolButton {
                    visible: !root.windowed
                    icon.name: "window-new"
                    PlasmaComponents.ToolTip.text: "창으로 열기"
                    PlasmaComponents.ToolTip.visible: hovered
                    onClicked: root.openWindow()
                }
            }
            Rectangle { id: headLine; anchors.top: head.bottom; anchors.topMargin: Kirigami.Units.smallSpacing; width: parent.width; height: 1; color: full.hair }

            ListView {
                id: list
                anchors.top: headLine.bottom; anchors.topMargin: Kirigami.Units.largeSpacing
                anchors.bottom: inputBox.top; anchors.bottomMargin: Kirigami.Units.largeSpacing
                width: parent.width
                clip: true
                spacing: Kirigami.Units.largeSpacing
                model: messages
                onCountChanged: Qt.callLater(positionViewAtEnd)

                PlasmaComponents.Label {
                    parent: list
                    anchors.centerIn: parent
                    width: list.width * 0.8
                    visible: messages.count === 0
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.WordWrap
                    opacity: 0.55
                    text: link.state === "disabled" ? "AI 서비스가 아직 켜지지 않았어요."
                          : "무엇을 도와드릴까요?\n예) 엣지 켜줘 · 다운로드에서 pdf 찾아줘 · 시스템 상태 알려줘"
                }

                delegate: Item {
                    id: entry
                    required property int index
                    required property string who
                    required property string text
                    required property string approvalId
                    required property int msgId
                    readonly property bool mine: who === "user"
                    readonly property bool editing: root.editingIndex === index
                    // 메뉴: 마우스를 올리면 보이고, 마지막 AI 답은 늘 보임. 자리는 늘 잡아 둬서 글이 들썩이지 않게.
                    readonly property bool hasMenu: who !== "note" && !editing
                    readonly property bool canRegenerate: who === "ai" && msgId >= 0 && !root.busy
                                                          && index === root.lastAi && root.userIndexBefore(index) >= 0
                    readonly property bool canEdit: mine && msgId >= 0 && !root.busy
                    width: ListView.view.width
                    height: (editing ? editor.height : bubble.height)
                            + (buttons.visible ? buttons.height + Kirigami.Units.smallSpacing : 0)
                            + (hasMenu ? menu.height : 0)

                    HoverHandler { id: hover }

                    Rectangle {
                        id: bubble
                        visible: !entry.editing
                        anchors.right: entry.mine ? parent.right : undefined
                        width: Math.min(msg.implicitWidth, parent.width * 0.78 - Kirigami.Units.largeSpacing * 2) + Kirigami.Units.largeSpacing * 2
                        height: msg.implicitHeight + Kirigami.Units.smallSpacing * 3
                        radius: Kirigami.Units.gridUnit
                        color: entry.mine ? Qt.alpha(full.accent, 0.22) : Qt.alpha(full.ink, entry.who === "note" ? 0.03 : 0.06)
                        PlasmaComponents.Label {
                            id: msg
                            x: Kirigami.Units.largeSpacing
                            anchors.verticalCenter: parent.verticalCenter
                            width: Math.min(implicitWidth, entry.width * 0.78 - Kirigami.Units.largeSpacing * 2)
                            text: entry.text
                            wrapMode: Text.Wrap
                            textFormat: Text.PlainText
                            opacity: entry.who === "note" ? 0.7 : 1
                        }
                    }

                    // 편집: 말풍선 자리에 글상자. Enter = 다시 보내기, Shift+Enter = 줄바꿈, Esc = 취소
                    Rectangle {
                        id: editor
                        visible: entry.editing
                        anchors.right: parent.right
                        width: parent.width * 0.85
                        height: editArea.implicitHeight + editRow.height + Kirigami.Units.smallSpacing * 4
                        radius: Kirigami.Units.gridUnit
                        color: Qt.alpha(full.accent, 0.12)
                        border.width: 1
                        border.color: Qt.alpha(full.accent, 0.5)
                        PlasmaComponents.TextArea {
                            id: editArea
                            anchors.top: parent.top; anchors.topMargin: Kirigami.Units.smallSpacing
                            anchors.left: parent.left; anchors.right: parent.right
                            anchors.margins: Kirigami.Units.smallSpacing
                            wrapMode: TextEdit.Wrap
                            background: null
                            Keys.onPressed: function (event) {
                                if ((event.key === Qt.Key_Return || event.key === Qt.Key_Enter) && !(event.modifiers & Qt.ShiftModifier)) {
                                    event.accepted = true
                                    root.send(editArea.text, entry.index)
                                } else if (event.key === Qt.Key_Escape) {
                                    event.accepted = true
                                    root.editingIndex = -1
                                }
                            }
                        }
                        Row {
                            id: editRow
                            anchors.right: parent.right; anchors.rightMargin: Kirigami.Units.smallSpacing
                            anchors.bottom: parent.bottom; anchors.bottomMargin: Kirigami.Units.smallSpacing
                            spacing: Kirigami.Units.smallSpacing
                            PlasmaComponents.Label {
                                anchors.verticalCenter: parent.verticalCenter
                                visible: entry.index < messages.count - 2
                                text: "이 뒤의 대화는 지워져요"
                                opacity: 0.55
                                font: Kirigami.Theme.smallFont
                            }
                            PlasmaComponents.Button { text: "취소"; onClicked: root.editingIndex = -1 }
                            PlasmaComponents.Button {
                                text: "보내기"
                                enabled: editArea.text.trim() !== "" && !root.busy
                                onClicked: root.send(editArea.text, entry.index)
                            }
                        }
                    }
                    onEditingChanged: if (editing) { editArea.text = entry.text; editArea.forceActiveFocus(); editArea.cursorPosition = editArea.length }

                    Row {
                        id: buttons
                        visible: entry.approvalId !== ""
                        anchors.top: bubble.bottom
                        anchors.topMargin: Kirigami.Units.smallSpacing
                        spacing: Kirigami.Units.smallSpacing
                        PlasmaComponents.Button { text: "허락"; onClicked: root.decide(entry.index, true) }
                        PlasmaComponents.Button { text: "거절"; onClicked: root.decide(entry.index, false) }
                    }

                    // 말풍선 아래 메뉴
                    Row {
                        id: menu
                        visible: entry.hasMenu
                        opacity: hover.hovered || (entry.who === "ai" && entry.index === root.lastAi) || copied.running ? 1 : 0
                        Behavior on opacity { NumberAnimation { duration: 120 } }
                        anchors.top: buttons.visible ? buttons.bottom : bubble.bottom
                        anchors.right: entry.mine ? parent.right : undefined
                        x: entry.mine ? 0 : Kirigami.Units.smallSpacing
                        Timer { id: copied; interval: 1500 }
                        PlasmaComponents.ToolButton {
                            icon.name: copied.running ? "dialog-ok-apply" : "edit-copy"
                            display: QQC2.AbstractButton.IconOnly
                            text: copied.running ? "복사했어요" : "복사하기"
                            PlasmaComponents.ToolTip.text: text
                            PlasmaComponents.ToolTip.visible: hovered
                            onClicked: { root.copyText(entry.text); copied.restart() }
                        }
                        PlasmaComponents.ToolButton {
                            visible: entry.canRegenerate
                            icon.name: "view-refresh"
                            display: QQC2.AbstractButton.IconOnly
                            text: "다시 생성하기"
                            PlasmaComponents.ToolTip.text: text
                            PlasmaComponents.ToolTip.visible: hovered
                            onClicked: root.regenerate(entry.index)
                        }
                        PlasmaComponents.ToolButton {
                            visible: entry.canEdit
                            icon.name: "document-edit"
                            display: QQC2.AbstractButton.IconOnly
                            text: "편집하기"
                            PlasmaComponents.ToolTip.text: text
                            PlasmaComponents.ToolTip.visible: hovered
                            onClicked: root.editingIndex = entry.index
                        }
                    }
                }
            }

            Rectangle {
                id: inputBox
                anchors.bottom: parent.bottom
                width: parent.width
                height: Kirigami.Units.gridUnit * 2.4
                radius: height / 2
                color: "transparent"
                border.width: 1
                border.color: input.activeFocus ? Qt.alpha(full.accent, 0.6) : full.hair

                MouseArea { anchors.fill: parent; cursorShape: Qt.IBeamCursor; onClicked: input.forceActiveFocus() }
                TextInput {
                    id: input
                    anchors.left: parent.left; anchors.leftMargin: Kirigami.Units.gridUnit
                    anchors.right: sendBtn.left; anchors.rightMargin: Kirigami.Units.smallSpacing
                    anchors.verticalCenter: parent.verticalCenter
                    color: full.ink
                    font: Kirigami.Theme.defaultFont
                    clip: true
                    enabled: !root.busy
                    onAccepted: { root.send(text); text = "" }
                    Keys.onEscapePressed: if (!root.windowed) root.expanded = false
                    Accessible.role: Accessible.EditableText
                    Accessible.name: "마니또에게 말하기"
                    PlasmaComponents.Label {
                        anchors.fill: parent
                        verticalAlignment: Text.AlignVCenter
                        visible: input.text === ""
                        opacity: 0.5
                        text: root.busy ? "마니또가 생각하는 중…" : "마니또에게 말하기"
                    }
                }
                Rectangle {
                    id: sendBtn
                    anchors.right: parent.right; anchors.rightMargin: 5
                    anchors.verticalCenter: parent.verticalCenter
                    width: parent.height - 10; height: width; radius: width / 2
                    color: Qt.alpha(full.accent, input.text ? 0.35 : 0.15)
                    Kirigami.Icon { anchors.centerIn: parent; width: Kirigami.Units.iconSizes.small; height: width; source: "go-up" }
                    MouseArea { anchors.fill: parent; onClicked: { root.send(input.text); input.text = "" } }
                }
            }
        }
    }
}
